--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5 (Ubuntu 14.5-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.5 (Ubuntu 14.5-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: pt_billing_period; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.pt_billing_period VALUES (1000, 'MONTH', 'MONTHLY', 'Monthly billing period', 30);
INSERT INTO public.pt_billing_period VALUES (1002, 'BIMONTH', 'BIMONTHLY', 'Bimonthly billing period', 60);


--
-- Data for Name: pt_status; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.pt_status VALUES (1000, 'ACT', 'ACTIVE', 'Active status', true, true);
INSERT INTO public.pt_status VALUES (1001, 'CANC', 'CANCEL', 'Cancel status', true, true);
INSERT INTO public.pt_status VALUES (1002, 'SUSP', 'SUSPEND', 'Suspend status', false, true);
INSERT INTO public.pt_status VALUES (1003, 'DEBT', 'DEBT', 'Debt status', false, true);
INSERT INTO public.pt_status VALUES (1005, 'PEND', 'PENDING', 'Pending', false, true);


--
-- Data for Name: ct_bill_cycle_type; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.ct_bill_cycle_type VALUES (1001, 'CMBC20', 'CORRECTIVE MONTHLY CYCLE 20', 'Corrective monthly bill cycle 20 - bill period: day 20 to day 19', 1000, 20, 'FRC20', 1000, '2021-11-28 15:25:45.570271', 'ADMIN', NULL, NULL, true);
INSERT INTO public.ct_bill_cycle_type VALUES (1000, 'OMBC20', 'ORDINARY MONTHLY CYCLE 20', 'Ordinary monthly bill cycle 20 - bill period: day 20 to day 19', 1000, 20, 'FOC20', 1000, '2021-11-28 15:25:45.570271', 'ADMIN', NULL, NULL, false);


--
-- Data for Name: pt_entity_type; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.pt_entity_type VALUES (1000, 'PROD', 'PRODUCT', 'Product');
INSERT INTO public.pt_entity_type VALUES (1001, 'SERV', 'SERVICE', 'Service');
INSERT INTO public.pt_entity_type VALUES (1002, 'PROM', 'PROMOTION', 'Promotion');
INSERT INTO public.pt_entity_type VALUES (1003, 'FEE', 'FEE', 'Fee');
INSERT INTO public.pt_entity_type VALUES (1009, 'ACC', 'ACCOUNT', 'Account');
INSERT INTO public.pt_entity_type VALUES (1008, 'CUST', 'CUSTOMER', 'Customer');
INSERT INTO public.pt_entity_type VALUES (1004, 'CONS', 'CONSUMPTION', 'Consumption');


--
-- Data for Name: pt_payment_method; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.pt_payment_method VALUES (1000, 'CONTER', 'CONTER', 'Over the conter payment');
INSERT INTO public.pt_payment_method VALUES (1001, 'TRANSF', 'TRANSFER', 'Bank transfer payment');
INSERT INTO public.pt_payment_method VALUES (1002, 'DDEBIT', 'DIRECT DEBIT', 'Direct debit payment');


--
-- Data for Name: ct_account_type; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.ct_account_type VALUES (1002, 1009, 'DACC', 'DEBIT ACCOUNT', 'Account for direct debit payments', 1000, 1001, 1000, '2022-05-01 14:50:41.26', 'WRITEUSER', NULL, NULL, 1002);
INSERT INTO public.ct_account_type VALUES (1001, 1009, 'CACC', 'COUNTER ACCOUNT', 'Account for counter payments', 1000, 1001, 1000, '2022-02-04 20:57:25.3', 'WRITEUSER', NULL, NULL, 1000);
INSERT INTO public.ct_account_type VALUES (1000, 1009, 'TACC', 'TRANSFER ACCOUNT', 'Account for transfer payments', 1000, 1001, 1000, '2021-11-28 15:26:44.900399', 'ADMIN', NULL, NULL, 1001);


--
-- Data for Name: pt_consumption_class; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.pt_consumption_class VALUES (1000, 'CALL', 'CALL', 'Call consumptions');
INSERT INTO public.pt_consumption_class VALUES (1001, 'SMS', 'SHORT MESSAGES', 'SMS Consumptions');
INSERT INTO public.pt_consumption_class VALUES (1002, 'MMS', 'MULTIMEDIA MESSAGES', 'MMS Consumptions');
INSERT INTO public.pt_consumption_class VALUES (1003, 'DATA', 'DATA', 'Data Consumptions');


--
-- Data for Name: ct_consumption_type; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.ct_consumption_type VALUES (1005, 1004, 'ICALL02', 'INTERNATIONAL CALL 02', 'International call type 02 – America', 1000, '2021-11-26 19:40:02.657008', 'ADMIN', NULL, NULL, 1000);
INSERT INTO public.ct_consumption_type VALUES (1006, 1004, 'ICALL03', 'INTERNATIONAL CALL 03', 'International call type 03 – Asia', 1000, '2021-11-26 19:40:02.657008', 'ADMIN', NULL, NULL, 1000);
INSERT INTO public.ct_consumption_type VALUES (1007, 1004, 'ICALL04', 'INTERNATIONAL CALL 04', 'International call type 04 – Africa', 1000, '2021-11-26 19:40:02.657008', 'ADMIN', NULL, NULL, 1000);
INSERT INTO public.ct_consumption_type VALUES (1008, 1004, 'ICALL05', 'INTERNATIONAL CALL 05', 'International call type 05 – Oceanie', 1000, '2021-11-26 19:40:02.657008', 'ADMIN', NULL, NULL, 1000);
INSERT INTO public.ct_consumption_type VALUES (1000, 1004, 'LCALL01', 'LOCAL CALL 01', 'Local call type 01', 1000, '2021-11-26 19:40:02.657008', 'ADMIN', NULL, NULL, 1000);
INSERT INTO public.ct_consumption_type VALUES (1001, 1004, 'RCALL01', 'REGIONAL CALL 01', 'Regional call type 01', 1000, '2021-11-26 19:40:02.657008', 'ADMIN', NULL, NULL, 1000);
INSERT INTO public.ct_consumption_type VALUES (1002, 1004, 'NCALL01', 'NATIONAL CALL 01', 'National call type 01', 1000, '2021-11-26 19:40:02.657008', 'ADMIN', NULL, NULL, 1000);
INSERT INTO public.ct_consumption_type VALUES (1003, 1004, 'SCALL01', 'SPECIAL TARIFICATION CALL 01', 'Special Tarification type 01', 1000, '2021-11-26 19:40:02.657008', 'ADMIN', NULL, NULL, 1000);
INSERT INTO public.ct_consumption_type VALUES (1009, 1004, 'NSMS01', 'NATIONAL SMS 01', 'National SMS type 01', 1000, '2021-11-26 19:40:02.657008', 'ADMIN', NULL, NULL, 1001);
INSERT INTO public.ct_consumption_type VALUES (1010, 1004, 'NSMS02', 'NATIONAL SMS 02', 'National SMS type 02 – Premium', 1000, '2021-11-26 19:40:02.657008', 'ADMIN', NULL, NULL, 1001);
INSERT INTO public.ct_consumption_type VALUES (1011, 1004, 'ISMS01', 'INTERNATIONAL SMS 01', 'International SMS type 01 – Europe', 1000, '2021-11-26 19:40:02.657008', 'ADMIN', NULL, NULL, 1001);
INSERT INTO public.ct_consumption_type VALUES (1012, 1004, 'ISMS02', 'INTERNATIONAL SMS 02', 'International SMS type 02 – America', 1000, '2021-11-26 19:40:02.657008', 'ADMIN', NULL, NULL, 1001);
INSERT INTO public.ct_consumption_type VALUES (1013, 1004, 'ISMS03', 'INTERNATIONAL SMS 03', 'International SMS type 03 – Asia', 1000, '2021-11-26 19:40:02.657008', 'ADMIN', NULL, NULL, 1001);
INSERT INTO public.ct_consumption_type VALUES (1014, 1004, 'ISMS04', 'INTERNATIONAL SMS 04', 'International SMS type 04 – Africa', 1000, '2021-11-26 19:40:02.657008', 'ADMIN', NULL, NULL, 1001);
INSERT INTO public.ct_consumption_type VALUES (1015, 1004, 'ISMS05', 'INTERNATIONAL SMS 05', 'International SMS type 05 – Oceanie', 1000, '2021-11-26 19:40:02.657008', 'ADMIN', NULL, NULL, 1001);
INSERT INTO public.ct_consumption_type VALUES (1016, 1004, 'NMMS01', 'NATIONAL MMS 01', 'National MMS type 01', 1000, '2021-11-26 19:40:02.657008', 'ADMIN', NULL, NULL, 1002);
INSERT INTO public.ct_consumption_type VALUES (1017, 1004, 'IMMS01', 'INTERNATIONAL MMS 01', 'International MMS type 01', 1000, '2021-11-26 19:40:02.657008', 'ADMIN', NULL, NULL, 1002);
INSERT INTO public.ct_consumption_type VALUES (1018, 1004, 'NDATA01', 'NATIONAL DATA 01', 'National data 01', 1000, '2021-11-26 19:40:02.657008', 'ADMIN', NULL, NULL, 1003);
INSERT INTO public.ct_consumption_type VALUES (1019, 1004, 'IDATA01', 'INTERNATIONAL DATA 01', 'International data 01 – Europe', 1000, '2021-11-26 19:40:02.657008', 'ADMIN', NULL, NULL, 1003);
INSERT INTO public.ct_consumption_type VALUES (1020, 1004, 'IDATA02', 'INTERNATIONAL DATA 02', 'International data 02 – America', 1000, '2021-11-26 19:40:02.657008', 'ADMIN', NULL, NULL, 1003);
INSERT INTO public.ct_consumption_type VALUES (1021, 1004, 'IDATA03', 'INTERNATIONAL DATA 03', 'International data 03 – Asia', 1000, '2021-11-26 19:40:02.657008', 'ADMIN', NULL, NULL, 1003);
INSERT INTO public.ct_consumption_type VALUES (1022, 1004, 'IDATA04', 'INTERNATIONAL DATA 04', 'International data 04 – Africa', 1000, '2021-11-26 19:40:02.657008', 'ADMIN', NULL, NULL, 1003);
INSERT INTO public.ct_consumption_type VALUES (1023, 1004, 'IDATA05', 'INTERNATIONAL DATA 05', 'International data 05 – Oceania', 1000, '2021-11-26 19:40:02.657008', 'ADMIN', NULL, NULL, 1003);
INSERT INTO public.ct_consumption_type VALUES (1004, 1004, 'ICALL01', 'INTERNATIONAL CALL 01', 'International call type 01 – Europe', 1000, '2021-11-26 19:40:02.657008', 'ADMIN', NULL, NULL, 1000);


--
-- Data for Name: ct_customer_type; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.ct_customer_type VALUES (1000, 1008, 'DCUST', 'DEFAULT CUSTOMER', 'Default customer', 1000, '2022-02-02 20:23:09.170477', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_customer_type VALUES (1001, 1008, 'OCUST', 'OTHER CUSTOMER', 'Other customer', 1000, '2022-02-04 19:21:15.466', 'WRITEUSER', NULL, NULL);


--
-- Data for Name: idt_fee_type; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.idt_fee_type VALUES (1000);
INSERT INTO public.idt_fee_type VALUES (1001);
INSERT INTO public.idt_fee_type VALUES (1002);
INSERT INTO public.idt_fee_type VALUES (1003);
INSERT INTO public.idt_fee_type VALUES (1004);
INSERT INTO public.idt_fee_type VALUES (1005);
INSERT INTO public.idt_fee_type VALUES (1006);
INSERT INTO public.idt_fee_type VALUES (1007);
INSERT INTO public.idt_fee_type VALUES (1009);
INSERT INTO public.idt_fee_type VALUES (1010);
INSERT INTO public.idt_fee_type VALUES (1008);
INSERT INTO public.idt_fee_type VALUES (1011);
INSERT INTO public.idt_fee_type VALUES (1012);
INSERT INTO public.idt_fee_type VALUES (1013);
INSERT INTO public.idt_fee_type VALUES (1014);
INSERT INTO public.idt_fee_type VALUES (1016);
INSERT INTO public.idt_fee_type VALUES (1017);
INSERT INTO public.idt_fee_type VALUES (1019);
INSERT INTO public.idt_fee_type VALUES (1020);
INSERT INTO public.idt_fee_type VALUES (1021);
INSERT INTO public.idt_fee_type VALUES (1022);
INSERT INTO public.idt_fee_type VALUES (1023);
INSERT INTO public.idt_fee_type VALUES (1024);
INSERT INTO public.idt_fee_type VALUES (1025);
INSERT INTO public.idt_fee_type VALUES (1026);
INSERT INTO public.idt_fee_type VALUES (1027);
INSERT INTO public.idt_fee_type VALUES (1028);
INSERT INTO public.idt_fee_type VALUES (1029);
INSERT INTO public.idt_fee_type VALUES (1030);
INSERT INTO public.idt_fee_type VALUES (1031);
INSERT INTO public.idt_fee_type VALUES (1032);
INSERT INTO public.idt_fee_type VALUES (1033);
INSERT INTO public.idt_fee_type VALUES (1034);
INSERT INTO public.idt_fee_type VALUES (1035);
INSERT INTO public.idt_fee_type VALUES (1036);
INSERT INTO public.idt_fee_type VALUES (1037);
INSERT INTO public.idt_fee_type VALUES (1038);
INSERT INTO public.idt_fee_type VALUES (1039);
INSERT INTO public.idt_fee_type VALUES (1040);
INSERT INTO public.idt_fee_type VALUES (1041);
INSERT INTO public.idt_fee_type VALUES (1042);
INSERT INTO public.idt_fee_type VALUES (1061);
INSERT INTO public.idt_fee_type VALUES (1015);
INSERT INTO public.idt_fee_type VALUES (1070);
INSERT INTO public.idt_fee_type VALUES (1071);
INSERT INTO public.idt_fee_type VALUES (1072);
INSERT INTO public.idt_fee_type VALUES (1073);
INSERT INTO public.idt_fee_type VALUES (1074);
INSERT INTO public.idt_fee_type VALUES (1075);


--
-- Data for Name: pt_application_level; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.pt_application_level VALUES (1000, 'PROD', 'PRODUCT', 'Level of application: product');
INSERT INTO public.pt_application_level VALUES (1001, 'SERV', 'SERVICE', 'Level of application: service');
INSERT INTO public.pt_application_level VALUES (1028, 'LEVEL', 'LEVEL', 'Level - test');


--
-- Data for Name: ct_fee_type; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.ct_fee_type VALUES (1000, 1003, '1900-01-01', '9999-12-31', 'PFMO01', 'PFP01_MOB', 'Prorated Fee for Mobile Product', 1000, true, 25.0000, 1000, '2021-11-26 21:32:31.357189', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_fee_type VALUES (1001, 1003, '1900-01-01', '9999-12-31', 'NFMO01', 'NFP01_MOB', 'Non-prorated Fee for Mobile Product', 1000, false, 20.0000, 1000, '2021-11-26 21:32:31.357189', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_fee_type VALUES (1002, 1003, '1900-01-01', '9999-12-31', 'PFIN01', 'PFP01_INT', 'Prorated Fee for Internet Product', 1000, true, 55.0000, 1000, '2021-11-26 21:32:31.357189', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_fee_type VALUES (1003, 1003, '1900-01-01', '9999-12-31', 'NFIN01', 'NFP01_INT', 'Non-prorated Fee for Internet Product', 1000, false, 50.0000, 1000, '2021-11-26 21:32:31.357189', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_fee_type VALUES (1004, 1003, '1900-01-01', '9999-12-31', 'PFMI01', 'PFP01_MOIN', 'Prorated Fee for Mobile + Internet Product', 1000, true, 70.0000, 1000, '2021-11-26 21:32:31.357189', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_fee_type VALUES (1005, 1003, '1900-01-01', '9999-12-31', 'NFMI01', 'NFP01_MOIN', 'Non-prorated Fee for Mobile + Internet Product', 1000, false, 75.0000, 1000, '2021-11-26 21:32:31.357189', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_fee_type VALUES (1006, 1003, '1900-01-01', '9999-12-31', 'PFSI01', 'PFS01_SEC', 'Prorated Fee for Internet Secure Pack', 1001, true, 20.0000, 1000, '2021-11-26 21:32:31.357189', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_fee_type VALUES (1007, 1003, '1900-01-01', '9999-12-31', 'NFSI01', 'NFS01_SEC', 'Non-prorated Fee for Internet Secure Pack', 1001, false, 22.0000, 1000, '2021-11-26 21:32:31.357189', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_fee_type VALUES (1009, 1003, '1900-01-01', '9999-12-31', 'V50SMS', 'NV50SMS', 'Non-prorrate voucher 50 SMS for Mobile Service', 1001, false, 50.0000, 1000, '2021-11-26 21:32:31.357189', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_fee_type VALUES (1010, 1003, '1900-01-01', '9999-12-31', 'V1GB', 'NV1GB', 'Non-prorrate voucher 1GB for Mobile Service', 1001, false, 20.0000, 1000, '2021-11-26 21:32:31.357189', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_fee_type VALUES (1008, 1003, '1900-01-01', '9999-12-31', 'V200MI', 'NV200MI', 'Non-prorrate voucher 200 min for Mobile Service', 1001, false, 15.5000, 1000, '2021-11-26 21:32:31.357189', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_fee_type VALUES (1013, 1003, '1900-01-01', '9999-12-31', 'PRUEBA3', 'PRUEBA3', 'PRUEBA3', 1000, true, 18.0000, 1000, '2022-06-27 18:47:17.23', 'WRITEUSER', NULL, NULL);
INSERT INTO public.ct_fee_type VALUES (1011, 1003, '2000-01-01', '2015-12-31', 'PRUEBA', 'PRUEBA', 'prueba', 1000, true, 15.0000, 1000, '2022-08-17 21:18:39.056', 'WRITEUSER', '2022-08-17 21:15:53.36', 'WRITEUSER');
INSERT INTO public.ct_fee_type VALUES (1012, 1003, '1992-01-01', '1993-12-31', 'PRUEBA2', 'PRUEBA2', 'prueba2', 1000, true, 5.0000, 1000, '2022-07-11 17:58:03.556', 'WRITEUSER', '2022-07-11 17:58:14.855', 'WRITEUSER');
INSERT INTO public.ct_fee_type VALUES (1012, 1003, '1995-01-01', '1999-12-31', 'PRUEBA2', 'PRUEBA2', 'prueba2', 1000, true, 5.0000, 1000, '2022-07-11 17:58:03.556', 'WRITEUSER', '2022-07-12 19:06:56.65', 'WRITEUSER');
INSERT INTO public.ct_fee_type VALUES (1012, 1003, '2008-01-01', '2023-12-31', 'PRUEBA2', 'PRUEBA2', 'prueba2', 1000, true, 15.0000, 1000, '2022-06-29 18:02:20.448', 'WRITEUSER', '2022-07-21 13:12:53.564', 'WRITEUSER');
INSERT INTO public.ct_fee_type VALUES (1037, 1003, '1900-01-01', '9999-12-31', 'PRUEBA1', 'PRUEBA1', 'prueba1', 1000, true, 12.0000, 1000, '2022-07-29 13:41:27.301', 'WRITEUSER', NULL, NULL);
INSERT INTO public.ct_fee_type VALUES (1012, 1003, '2000-01-01', '2004-12-31', 'PRUEBA2', 'PRUEBA2', 'prueba2', 1000, true, 5.0000, 1000, '2022-07-08 20:18:54.284', 'WRITEUSER', '2022-07-08 20:17:49.039', 'WRITEUSER');
INSERT INTO public.ct_fee_type VALUES (1012, 1003, '1994-01-01', '1994-12-31', 'PRUEBA2', 'PRUEBA2', 'prueba2', 1000, true, 5.0000, 1000, '2022-06-30 14:24:22.309', 'WRITEUSER', '2022-07-12 19:07:18.333', 'WRITEUSER');
INSERT INTO public.ct_fee_type VALUES (1012, 1003, '2024-01-01', '9999-12-31', 'PRUEBA2', 'PRUEBA2', 'prueba2', 1000, true, 15.0000, 1001, '2022-06-29 18:02:20.448', 'WRITEUSER', '2022-06-30 14:01:02.446', 'WRITEUSER');
INSERT INTO public.ct_fee_type VALUES (1011, 1003, '2020-01-01', '9999-12-31', 'PRUEBA', 'PRUEBA', 'prueba', 1000, true, 15.0000, 1000, '2022-05-24 21:57:52.749', 'WRITEUSER', NULL, NULL);
INSERT INTO public.ct_fee_type VALUES (1015, 1003, '1900-01-01', '9999-12-31', 'PRUEBAN', 'PRUEBAN', 'PRUEBAN', 1000, true, 18.0000, 1000, '2022-06-27 18:47:17.23', 'WRITEUSER', NULL, NULL);
INSERT INTO public.ct_fee_type VALUES (1011, 1003, '2016-01-01', '2019-12-31', 'PRUEBA', 'PRUEBA', 'prueba', 1000, true, 15.0000, 1000, '2022-07-13 20:30:25.661', 'WRITEUSER', '2022-07-13 20:31:14.534', 'WRITEUSER');
INSERT INTO public.ct_fee_type VALUES (1012, 1003, '2005-01-01', '2005-12-31', 'PRUEBA2', 'PRUEBA2', 'prueba2', 1000, true, 15.0000, 1000, '2022-06-29 18:02:20.448', 'WRITEUSER', '2022-06-29 20:42:01.286', 'WRITEUSER');
INSERT INTO public.ct_fee_type VALUES (1012, 1003, '2006-01-01', '2006-12-31', 'PRUEBA2', 'PRUEBA2', 'prueba2', 1000, true, 15.0000, 1000, '2022-06-29 18:02:20.448', 'WRITEUSER', '2022-06-30 13:50:19.616', 'WRITEUSER');
INSERT INTO public.ct_fee_type VALUES (1012, 1003, '2007-01-01', '2007-12-31', 'PRUEBA2', 'PRUEBA2', 'prueba2', 1000, true, 25.0000, 1000, '2022-06-30 14:00:28.095', 'WRITEUSER', '2022-06-30 13:50:19.616', 'WRITEUSER');
INSERT INTO public.ct_fee_type VALUES (1075, 1003, '2010-01-01', '9999-12-31', 'AA', 'AA', 'AA', 1028, true, 44.0000, 1000, '2022-07-30 20:16:43.52', 'WRITEUSER', '2022-07-30 20:40:08.424', 'WRITEUSER');
INSERT INTO public.ct_fee_type VALUES (1075, 1003, '1900-01-01', '2009-12-31', 'AA', 'AA', 'AA', 1028, true, 44.0000, 1000, '2022-07-30 20:40:08.42', 'WRITEUSER', '2022-07-30 21:07:25.173', 'WRITEUSER');


--
-- Data for Name: ct_product_type; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.ct_product_type VALUES (1000, 1000, 'OMOB', 'MOBILE', 'Product for only mobile services', 1000, '2021-11-24 21:16:18.140133', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_product_type VALUES (1001, 1000, 'OINT', 'INTERNET', 'Product for only internet services', 1000, '2021-11-24 21:16:18.140133', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_product_type VALUES (1002, 1000, 'MOIN', 'MOB+INT', 'Product for mobile and internet services', 1000, '2021-11-24 21:16:18.140133', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_product_type VALUES (1004, 1000, 'PROD', 'PROD', 'Product', 1000, '2022-03-07 20:02:17.27', 'WRITEUSER', NULL, NULL);


--
-- Data for Name: ct_prod_fee_type; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.ct_prod_fee_type VALUES (1002, 1001, 1003, 1000, '2022-03-23 20:52:59.483', 'WRITEUSER', NULL, NULL);
INSERT INTO public.ct_prod_fee_type VALUES (1003, 1001, 1002, 1000, '2022-03-23 20:53:02.237', 'WRITEUSER', NULL, NULL);
INSERT INTO public.ct_prod_fee_type VALUES (1004, 1000, 1001, 1000, '2022-03-23 20:55:02.329', 'WRITEUSER', NULL, NULL);
INSERT INTO public.ct_prod_fee_type VALUES (1005, 1000, 1000, 1000, '2022-03-23 20:55:06.202', 'WRITEUSER', NULL, NULL);
INSERT INTO public.ct_prod_fee_type VALUES (1017, 1004, 1003, 1000, '2022-04-09 12:04:14.596', 'WRITEUSER', NULL, NULL);
INSERT INTO public.ct_prod_fee_type VALUES (1019, 1004, 1005, 1000, '2022-04-09 12:27:29.773', 'WRITEUSER', NULL, NULL);
INSERT INTO public.ct_prod_fee_type VALUES (1023, 1004, 1001, 1000, '2022-04-09 13:00:14.294', 'WRITEUSER', NULL, NULL);
INSERT INTO public.ct_prod_fee_type VALUES (1000, 1002, 1005, 1000, '2022-03-23 20:38:47.496', 'WRITEUSER', '2022-07-18 12:46:03.287', 'WRITEUSER');
INSERT INTO public.ct_prod_fee_type VALUES (1026, 1004, 1012, 1000, '2022-07-20 10:38:19.849', 'WRITEUSER', NULL, NULL);
INSERT INTO public.ct_prod_fee_type VALUES (1027, 1002, 1003, 1000, '2022-07-22 11:42:22.592', 'WRITEUSER', NULL, NULL);
INSERT INTO public.ct_prod_fee_type VALUES (1030, 1002, 1012, 1000, '2022-07-22 13:18:32.71', 'WRITEUSER', NULL, NULL);


--
-- Data for Name: ct_service_type; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.ct_service_type VALUES (1000, 1001, 'MOB1', 'MOBILE1', 'Mobile service 1', 1000, '2021-11-24 21:18:49.296391', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_service_type VALUES (1001, 1001, 'MOB2', 'MOBILE2', 'Mobile service 2', 1000, '2021-11-24 21:18:49.296391', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_service_type VALUES (1002, 1001, 'INT1', 'INTERNET1', 'Internet service 1', 1000, '2021-11-24 21:18:49.296391', 'ADMIN', NULL, NULL);


--
-- Data for Name: ct_prod_serv_type; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.ct_prod_serv_type VALUES (1000, 1000, 1000, 1000, '2021-11-28 16:08:29.405284', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_prod_serv_type VALUES (1001, 1000, 1001, 1000, '2021-11-28 16:08:29.405284', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_prod_serv_type VALUES (1003, 1002, 1000, 1000, '2021-11-28 16:08:29.405284', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_prod_serv_type VALUES (1004, 1002, 1001, 1000, '2021-11-28 16:08:29.405284', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_prod_serv_type VALUES (1005, 1002, 1002, 1000, '2021-11-28 16:08:29.405284', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_prod_serv_type VALUES (1002, 1001, 1002, 1000, '2021-11-28 16:08:29.405284', 'ADMIN', NULL, NULL);


--
-- Data for Name: idt_promotion_type; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.idt_promotion_type VALUES (1000);
INSERT INTO public.idt_promotion_type VALUES (1001);
INSERT INTO public.idt_promotion_type VALUES (1002);
INSERT INTO public.idt_promotion_type VALUES (1003);
INSERT INTO public.idt_promotion_type VALUES (1004);
INSERT INTO public.idt_promotion_type VALUES (1005);
INSERT INTO public.idt_promotion_type VALUES (1006);
INSERT INTO public.idt_promotion_type VALUES (1008);
INSERT INTO public.idt_promotion_type VALUES (1009);
INSERT INTO public.idt_promotion_type VALUES (1012);
INSERT INTO public.idt_promotion_type VALUES (1013);
INSERT INTO public.idt_promotion_type VALUES (1014);
INSERT INTO public.idt_promotion_type VALUES (1015);
INSERT INTO public.idt_promotion_type VALUES (1016);
INSERT INTO public.idt_promotion_type VALUES (1017);
INSERT INTO public.idt_promotion_type VALUES (1018);
INSERT INTO public.idt_promotion_type VALUES (1019);
INSERT INTO public.idt_promotion_type VALUES (1020);
INSERT INTO public.idt_promotion_type VALUES (1021);
INSERT INTO public.idt_promotion_type VALUES (1022);
INSERT INTO public.idt_promotion_type VALUES (1023);
INSERT INTO public.idt_promotion_type VALUES (1024);


--
-- Data for Name: ct_promo_consum_type_discount; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.ct_promo_consum_type_discount VALUES (1000, 1004, 1000, 1000, '2021-11-26 22:16:01.821656', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_promo_consum_type_discount VALUES (1001, 1004, 1001, 1000, '2021-11-26 22:16:01.821656', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_promo_consum_type_discount VALUES (1002, 1004, 1002, 1000, '2021-11-26 22:16:01.821656', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_promo_consum_type_discount VALUES (1003, 1005, 1009, 1000, '2021-11-26 22:16:01.821656', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_promo_consum_type_discount VALUES (1004, 1006, 1018, 1000, '2021-11-26 22:16:01.821656', 'ADMIN', NULL, NULL);


--
-- Data for Name: ct_promo_fee_type_discount; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.ct_promo_fee_type_discount VALUES (1000, 1000, 1000, 1000, 1000, '2021-11-26 22:11:00.708392', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_promo_fee_type_discount VALUES (1001, 1000, 1001, 1000, 1000, '2021-11-26 22:11:00.708392', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_promo_fee_type_discount VALUES (1002, 1001, 1002, 1000, 1000, '2021-11-26 22:11:00.708392', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_promo_fee_type_discount VALUES (1003, 1001, 1003, 1000, 1000, '2021-11-26 22:11:00.708392', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_promo_fee_type_discount VALUES (1004, 1002, 1004, 1000, 1000, '2021-11-26 22:11:00.708392', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_promo_fee_type_discount VALUES (1005, 1002, 1005, 1000, 1000, '2021-11-26 22:11:00.708392', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_promo_fee_type_discount VALUES (1006, 1003, 1006, 1001, 1000, '2021-11-26 22:11:00.708392', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_promo_fee_type_discount VALUES (1007, 1003, 1007, 1001, 1000, '2021-11-26 22:11:00.708392', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_promo_fee_type_discount VALUES (1009, 1006, 1010, 1001, 1000, '2022-04-15 15:04:27.485', 'WRITEUSER', NULL, NULL);
INSERT INTO public.ct_promo_fee_type_discount VALUES (1011, 1004, 1008, 1001, 1000, '2022-04-15 15:05:18.071', 'WRITEUSER', NULL, NULL);
INSERT INTO public.ct_promo_fee_type_discount VALUES (1012, 1005, 1009, 1001, 1000, '2022-04-15 15:05:34.374', 'WRITEUSER', NULL, NULL);


--
-- Data for Name: ct_promo_prod_type; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.ct_promo_prod_type VALUES (1000, 1000, 1000, 1000, '2021-11-26 20:30:47.584313', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_promo_prod_type VALUES (1001, 1001, 1001, 1000, '2021-11-26 20:30:47.584313', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_promo_prod_type VALUES (1004, 1001, 1004, 1000, '2022-04-09 14:19:06.653', 'WRITEUSER', NULL, NULL);
INSERT INTO public.ct_promo_prod_type VALUES (1006, 1000, 1004, 1000, '2022-04-09 14:19:17.885', 'WRITEUSER', NULL, NULL);
INSERT INTO public.ct_promo_prod_type VALUES (1007, 1001, 1002, 1000, '2022-07-22 19:37:12.469', 'WRITEUSER', NULL, NULL);


--
-- Data for Name: ct_promo_serv_type; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.ct_promo_serv_type VALUES (1000, 1003, 1002, 1000, '2021-11-26 21:58:01.140807', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_promo_serv_type VALUES (1001, 1004, 1000, 1000, '2021-11-26 21:58:01.140807', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_promo_serv_type VALUES (1002, 1004, 1001, 1000, '2021-11-26 21:58:01.140807', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_promo_serv_type VALUES (1003, 1005, 1000, 1000, '2021-11-26 21:58:01.140807', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_promo_serv_type VALUES (1004, 1005, 1001, 1000, '2021-11-26 21:58:01.140807', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_promo_serv_type VALUES (1005, 1006, 1000, 1000, '2021-11-26 21:58:01.140807', 'ADMIN', NULL, NULL);


--
-- Data for Name: pt_discount_type; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.pt_discount_type VALUES (1000, 'PERC', 'PERCENTAGE', 'Percentage discount (for fees)');
INSERT INTO public.pt_discount_type VALUES (1001, 'MIN', 'MINUTES', 'Minutes discount (for calls)');
INSERT INTO public.pt_discount_type VALUES (1002, 'MB', 'MEGABYTES', 'Megabytes discount (for data mobile)');
INSERT INTO public.pt_discount_type VALUES (1003, 'UNIT', 'UNITS', 'Units of the charge discount (for SMS or others)');


--
-- Data for Name: ct_promotion_type; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.ct_promotion_type VALUES (1000, 1002, '1900-01-01', '9999-12-31', 'WPMO01', 'WP01_MOB', 'Welcome Promotion for Mobile Product', 1000, 1000, 50.0000, 1000, '2021-11-25 21:40:49.438854', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_promotion_type VALUES (1001, 1002, '1900-01-01', '9999-12-31', 'WPIN01', 'WP01_INT', 'Welcome Promotion for Internet Product', 1000, 1000, 40.0000, 1000, '2021-11-25 21:40:49.438854', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_promotion_type VALUES (1002, 1002, '1900-01-01', '9999-12-31', 'WPMI01', 'WP01_MOIN', 'Welcome Promotion for Mobile + Internet Product', 1000, 1000, 60.0000, 1000, '2021-11-25 21:40:49.438854', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_promotion_type VALUES (1003, 1002, '1900-01-01', '9999-12-31', 'WSIN01', 'WS01_INT', 'Promotion for secure pack', 1001, 1000, 25.0000, 1000, '2021-11-25 21:40:49.438854', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_promotion_type VALUES (1004, 1002, '1900-01-01', '9999-12-31', '200MIN', '200MIN_MOB', '200 min free for Mobile Service', 1001, 1001, 200.0000, 1000, '2021-11-25 21:40:49.438854', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_promotion_type VALUES (1005, 1002, '1900-01-01', '9999-12-31', '50SMS', '50SMS_MOB', '50 SMS free for Mobile Service', 1001, 1003, 20.0000, 1000, '2021-11-25 21:40:49.438854', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_promotion_type VALUES (1006, 1002, '1900-01-01', '9999-12-31', '1GB', '1GB_MOB', '1GB free for Mobile Service', 1001, 1002, 1000.0000, 1000, '2021-11-25 21:40:49.438854', 'ADMIN', NULL, NULL);
INSERT INTO public.ct_promotion_type VALUES (1014, 1002, '1900-01-01', '1999-12-31', 'PROMO1', 'PROMO1', 'p', 1000, 1002, 500.0000, 1000, '2022-07-29 13:13:29.889', 'WRITEUSER', '2022-08-01 18:27:08.229', 'WRITEUSER');
INSERT INTO public.ct_promotion_type VALUES (1014, 1002, '2000-01-01', '2010-12-31', 'PROMO1', 'PROMO1', 'p', 1000, 1002, 500.0000, 1000, '2022-08-01 18:27:08.258', 'WRITEUSER', '2022-07-30 11:31:17.134', 'WRITEUSER');
INSERT INTO public.ct_promotion_type VALUES (1014, 1002, '2011-01-01', '2019-12-31', 'PROMO1', 'PROMO1', 'p', 1000, 1002, 500.0000, 1000, '2022-08-01 18:33:00.163', 'WRITEUSER', '2022-08-01 18:27:08.261', 'WRITEUSER');
INSERT INTO public.ct_promotion_type VALUES (1014, 1002, '2020-01-01', '9999-12-31', 'PROMO1', 'PROMO1', 'p', 1000, 1002, 500.0000, 1000, '2022-07-29 13:13:29.889', 'WRITEUSER', '2022-08-01 18:33:09.049', 'WRITEUSER');


--
-- Data for Name: ct_serv_fee_type; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.ct_serv_fee_type VALUES (1000, 1002, 1007, 1000, '2022-04-15 13:20:07.331', 'WRITEUSER', NULL, NULL);
INSERT INTO public.ct_serv_fee_type VALUES (1001, 1002, 1006, 1000, '2022-04-15 13:20:27.324', 'WRITEUSER', NULL, NULL);
INSERT INTO public.ct_serv_fee_type VALUES (1002, 1000, 1010, 1000, '2022-04-15 13:20:53.094', 'WRITEUSER', NULL, NULL);
INSERT INTO public.ct_serv_fee_type VALUES (1003, 1000, 1008, 1000, '2022-04-15 13:21:03.083', 'WRITEUSER', NULL, NULL);
INSERT INTO public.ct_serv_fee_type VALUES (1005, 1000, 1009, 1000, '2022-04-15 13:21:20.575', 'WRITEUSER', NULL, NULL);
INSERT INTO public.ct_serv_fee_type VALUES (1006, 1001, 1008, 1000, '2022-04-15 13:22:53.264', 'WRITEUSER', NULL, NULL);
INSERT INTO public.ct_serv_fee_type VALUES (1007, 1001, 1009, 1000, '2022-04-15 13:23:01.803', 'WRITEUSER', NULL, NULL);


--
-- Data for Name: idt_account; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.idt_account VALUES (1003);
INSERT INTO public.idt_account VALUES (1004);
INSERT INTO public.idt_account VALUES (1005);
INSERT INTO public.idt_account VALUES (1006);
INSERT INTO public.idt_account VALUES (1007);
INSERT INTO public.idt_account VALUES (1008);
INSERT INTO public.idt_account VALUES (1009);
INSERT INTO public.idt_account VALUES (1010);


--
-- Data for Name: idt_customer; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.idt_customer VALUES (1001);
INSERT INTO public.idt_customer VALUES (1002);


--
-- Data for Name: idt_fee; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--



--
-- Data for Name: idt_product; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.idt_product VALUES (1002);
INSERT INTO public.idt_product VALUES (1003);
INSERT INTO public.idt_product VALUES (1004);


--
-- Data for Name: idt_product_fee; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--



--
-- Data for Name: idt_product_promotion; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--



--
-- Data for Name: idt_product_service; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--



--
-- Data for Name: idt_promotion; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--



--
-- Data for Name: idt_service; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--



--
-- Data for Name: idt_service_fee; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--



--
-- Data for Name: idt_service_promotion; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--



--
-- Data for Name: it_contract; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.it_contract VALUES (1002, 'CMS1002', NULL, NULL, NULL, '2022-08-10 00:00:00', 'WRITEUSER', NULL, NULL);
INSERT INTO public.it_contract VALUES (1003, 'CMS1003', NULL, NULL, NULL, '2022-08-11 00:00:00', 'WRITEUSER', NULL, NULL);
INSERT INTO public.it_contract VALUES (1004, 'CMS1004', NULL, NULL, NULL, '2022-08-11 00:00:00', 'WRITEUSER', NULL, NULL);
INSERT INTO public.it_contract VALUES (1005, 'CMS1005', NULL, NULL, NULL, '2022-08-11 00:00:00', 'WRITEUSER', NULL, NULL);
INSERT INTO public.it_contract VALUES (1006, 'CMS1006', NULL, NULL, NULL, '2022-08-11 00:00:00', 'WRITEUSER', NULL, NULL);
INSERT INTO public.it_contract VALUES (1007, 'CMS1007', NULL, NULL, NULL, '2022-08-11 00:00:00', 'WRITEUSER', NULL, NULL);
INSERT INTO public.it_contract VALUES (1008, 'CMS1008', NULL, NULL, NULL, '2022-08-12 00:00:00', 'WRITEUSER', NULL, NULL);
INSERT INTO public.it_contract VALUES (1009, 'CMS1009', NULL, NULL, NULL, '2022-08-12 10:57:31.642', 'WRITEUSER', NULL, NULL);


--
-- Data for Name: it_account; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.it_account VALUES (1003, 1001, '1900-01-01', '9999-12-31', 'ACC01', 1002, 'CMS1002', 1005, 'Amparo', 'Macias', 'Frias', 1000, '15092863X', NULL, NULL, 'Plazuela Real, 78', 'Encina De San Silvestre', 'Salamanca', 'España', '37125', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-08-11 20:07:37.243', 'WRITEUSER', NULL, NULL);
INSERT INTO public.it_account VALUES (1004, 1001, '1900-01-01', '9999-12-31', 'ACC02', 1002, 'CMS1003', 1005, 'Amparo', 'Macias', 'Frias', 1000, '15092863X', NULL, NULL, 'Plazuela Real, 78', 'Encina De San Silvestre', 'Salamanca', 'España', '37125', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-08-11 20:42:12.727', 'WRITEUSER', NULL, NULL);
INSERT INTO public.it_account VALUES (1006, 1001, '1900-01-01', '9999-12-31', 'ACC03', 1002, 'CMS1004', 1005, 'Amparo', 'Macias', 'Frias', 1000, '15092863X', NULL, NULL, 'Plazuela Real, 78', 'Encina De San Silvestre', 'Salamanca', 'España', '37125', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-08-11 21:13:29.563', 'WRITEUSER', NULL, NULL);
INSERT INTO public.it_account VALUES (1007, 1002, '1900-01-01', '9999-12-31', 'ACC01', 1001, 'CMS1004', 1005, 'Angel', 'Real', 'Cuevas', 1000, '30211780S', '668579362', 'mu858k0i@scientist.com', 'Glorieta Madrid, 18', 'Gilbuena', 'Ávila', 'España', '05935', 'ES44', '2089', '7884', '32', '9745596764', NULL, NULL, '2022-08-11 21:20:24.734', 'WRITEUSER', NULL, NULL);
INSERT INTO public.it_account VALUES (1008, 1002, '1900-01-01', '9999-12-31', 'ACC02', 1001, 'CMS1005', 1005, 'Angel', 'Real', 'Cuevas', 1000, '30211780S', '668579362', 'mu858k0i@scientist.com', 'Glorieta Madrid, 18', 'Gilbuena', 'Ávila', 'España', '05935', 'ES44', '2089', '7884', '32', '9745596764', NULL, NULL, '2022-08-11 21:30:22.778', 'WRITEUSER', NULL, NULL);
INSERT INTO public.it_account VALUES (1009, 1002, '1900-01-01', '9999-12-31', 'ACC03', 1001, 'CMS1006', 1005, 'Angel', 'Real', 'Cuevas', 1000, '30211780S', '668579362', 'mu858k0i@scientist.com', 'Glorieta Madrid, 18', 'Gilbuena', 'Ávila', 'España', '05935', 'ES44', '2089', '7884', '32', '9745596764', NULL, NULL, '2022-08-11 21:42:02.841', 'WRITEUSER', NULL, NULL);
INSERT INTO public.it_account VALUES (1010, 1001, '1900-01-01', '9999-12-31', 'ACC03', 1002, 'CMS1007', 1005, 'Amparo', 'Macias', 'Frias', 1000, '15092863X', NULL, NULL, 'Plazuela Real, 78', 'Encina De San Silvestre', 'Salamanca', 'España', '37125', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-08-11 21:57:29.756', 'WRITEUSER', NULL, NULL);


--
-- Data for Name: pt_identity_card_type; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.pt_identity_card_type VALUES (1001, 'NIE', 'NIE', 'Número de identificación del extranjero');
INSERT INTO public.pt_identity_card_type VALUES (1000, 'NIF', 'NIF', 'Número de identificación fiscal');
INSERT INTO public.pt_identity_card_type VALUES (1002, 'PAS', 'PASSPORT', 'Pasaporte');


--
-- Data for Name: it_customer; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.it_customer VALUES (1001, 1000, '1900-01-01', '1999-12-31', 1005, 'Angel', 'Real', 'Cuevas', 1000, '30211780S', '668579362', 'mu858k0i@scientist.com', 'Glorieta Madrid, 18', 'Gilbuena', 'Ávila', 'España', '05935', 'ES44', '2089', '7884', '32', '9745596764', NULL, NULL, '2022-07-29 10:35:48.757', 'WRITEUSER', '2022-07-29 10:43:32.018', 'WRITEUSER');
INSERT INTO public.it_customer VALUES (1001, 1000, '2000-01-01', '9999-12-31', 1005, 'Angel', 'Real', 'Cuevas', 1000, '30211780S', '668579362', 'mu858k0i@scientist.com', 'Glorieta Madrid, 18', 'Gilbuena', 'Ávila', 'España', '05935', 'ES44', '2089', '7884', '32', '9745596764', NULL, NULL, '2022-07-29 10:43:32.031', 'WRITEUSER', NULL, NULL);
INSERT INTO public.it_customer VALUES (1002, 1000, '2022-01-01', '9999-12-31', 1005, 'Amparo', 'Macias', 'Frias', 1000, '15092863X', NULL, NULL, 'Plazuela Real, 78', 'Encina De San Silvestre', 'Salamanca', 'España', '37125', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-07-29 11:58:20.611', 'WRITEUSER', '2022-08-19 19:12:09.187', 'WRITEUSER');


--
-- Data for Name: it_fee; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--



--
-- Data for Name: it_product; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.it_product VALUES (1002, 1002, 1003, 'MOIN', '1994-01-01', '1994-12-31', 1000, '1994-01-01 00:00:00', NULL, '2022-08-17 21:54:17.058', 'WRITEUSER', '2022-08-18 21:14:07.225', 'WRITEUSER');
INSERT INTO public.it_product VALUES (1002, 1002, 1003, 'MOIN', '1995-01-01', '1995-12-31', 1000, '1994-01-01 00:00:00', NULL, '2022-08-17 21:54:59.303', 'WRITEUSER', '2022-08-18 20:46:09.984', 'WRITEUSER');
INSERT INTO public.it_product VALUES (1002, 1002, 1003, 'MOIN', '1996-01-01', '1998-12-31', 1000, '1994-01-01 00:00:00', NULL, '2022-08-18 19:38:55.484', 'WRITEUSER', '2022-08-18 20:55:16.501', 'WRITEUSER');
INSERT INTO public.it_product VALUES (1002, 1002, 1003, 'MOIN', '1999-01-01', '1999-12-31', 1000, '1994-01-01 00:00:00', NULL, '2022-08-17 19:32:24.083', 'WRITEUSER', '2022-08-18 20:41:55.309', 'WRITEUSER');
INSERT INTO public.it_product VALUES (1002, 1002, 1003, 'MOIN', '2000-01-01', '9999-12-31', 1005, '1994-01-01 00:00:00', NULL, '2022-08-17 20:28:49.093', 'WRITEUSER', NULL, NULL);
INSERT INTO public.it_product VALUES (1003, 1001, 1008, 'OINT', '2020-01-01', '9999-12-31', 1000, NULL, NULL, '2022-08-18 19:38:59.391', 'WRITEUSER', '2022-08-18 19:57:08.893', 'WRITEUSER');


--
-- Data for Name: it_profiles; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.it_profiles VALUES (1000, 'DBADMIN', 'database administrator');
INSERT INTO public.it_profiles VALUES (1001, 'ADMIN', 'administrator permission');
INSERT INTO public.it_profiles VALUES (1003, 'READ', 'only read permission');
INSERT INTO public.it_profiles VALUES (1002, 'MODIFY', 'modify permission');


--
-- Data for Name: it_promotion; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--



--
-- Data for Name: it_service; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--



--
-- Data for Name: it_users; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.it_users VALUES (1001, 'Jasón', 'de Tesalia', 'jasontesalia@billingweb.com', '999111222', 'WRITEUSER', '8ccadb6bbbe72e945ee5bfc7030339dd', 1002, true);
INSERT INTO public.it_users VALUES (1002, 'Heracles', 'de Tebas', 'heraclestebas@billingweb.com', '999111333', 'READUSER', 'e0fef7bebcbb495c6c96f883d5f56c5d', 1003, true);
INSERT INTO public.it_users VALUES (1000, 'HERA', 'DEL OLIMPO', 'HERAOLIMPO@BILLINGWEB.COM', '999111111', 'ADMIN', '73acd9a5972130b75066c82595a1fae3', 1001, true);
INSERT INTO public.it_users VALUES (1005, 'QUIRÓN', 'DE TRACIA', 'QUIRONTRACIA@BILLINGWEB.COM', '999111444', 'ADMIN2', '63db3feba0befbb1d61a7e38ae0bf069', 1000, true);


--
-- Data for Name: mt_application_menu; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.mt_application_menu VALUES (1000, NULL, true, 1, 1, 'PARAMETERS', 'Parameter data', 'ADMIN|READ|MODIFY', 'NULL');
INSERT INTO public.mt_application_menu VALUES (1001, 1000, false, 2, 1, 'Entity Types', 'Types of entities', 'ADMIN|READ|MODIFY', 'entity_type.xhtml');
INSERT INTO public.mt_application_menu VALUES (1007, 1006, false, 2, 1, 'Bill Cycle Type', 'Types of the distinct billing cycles in the system', 'ADMIN|READ|MODIFY', 'bill_cycle_type.xhtml');
INSERT INTO public.mt_application_menu VALUES (1009, 1006, false, 2, 3, 'Account Type', 'Types of the distint accounts for the system', 'ADMIN|READ|MODIFY', 'account_type.xhtml');
INSERT INTO public.mt_application_menu VALUES (1010, 1006, false, 2, 4, 'Fee Type', 'Types of fee in the system catalog', 'ADMIN|READ|MODIFY', 'fee_type.xhtml');
INSERT INTO public.mt_application_menu VALUES (1011, 1006, false, 2, 5, 'Consumption Type', 'Types of consumption for the service types', 'ADMIN|READ|MODIFY', 'consumption_type.xhtml');
INSERT INTO public.mt_application_menu VALUES (1012, 1006, true, 2, 6, 'Product Type', 'Types of products and relations', 'ADMIN|READ|MODIFY', 'NULL');
INSERT INTO public.mt_application_menu VALUES (1013, 1012, false, 3, 1, 'Product Type Defintion', 'Types of product in the system catalog', 'ADMIN|READ|MODIFY', 'product_type.xhtml');
INSERT INTO public.mt_application_menu VALUES (1015, 1012, false, 3, 3, 'Product Service Type', 'Relation betwen products and service types', 'ADMIN|READ|MODIFY', 'product_service_type.xhtml');
INSERT INTO public.mt_application_menu VALUES (1017, 1006, true, 2, 7, 'Service Type', 'Types of service and relations', 'ADMIN|READ|MODIFY', 'NULL');
INSERT INTO public.mt_application_menu VALUES (1018, 1017, false, 3, 1, 'Service Type Definition', 'Types of service in the system catalog', 'ADMIN|READ|MODIFY', 'service_type.xhtml');
INSERT INTO public.mt_application_menu VALUES (1019, 1017, false, 3, 2, 'Service Fee Type', 'Relation between service types and fee types that can be applied to this services', 'ADMIN|READ|MODIFY', 'service_fee_type.xhtml');
INSERT INTO public.mt_application_menu VALUES (1021, 1006, true, 2, 8, 'Promotion Type', 'Types of Promotion types and relations', 'ADMIN|READ|MODIFY', 'NULL');
INSERT INTO public.mt_application_menu VALUES (1022, 1021, false, 3, 1, 'Promotion Type Definition', 'Types of Promotion in the system', 'ADMIN|READ|MODIFY', 'promotion_type.xhtml');
INSERT INTO public.mt_application_menu VALUES (1008, 1006, false, 2, 2, 'Customer Type', 'Types of the distinct customers for the system', 'ADMIN|READ|MODIFY', 'customer_type.xhtml');
INSERT INTO public.mt_application_menu VALUES (1014, 1012, false, 3, 2, 'Product Fee Type', 'Relation between product types and fee types that can be applied to this products', 'ADMIN|READ|MODIFY', 'product_fee_type.xhtml');
INSERT INTO public.mt_application_menu VALUES (1016, 1012, false, 3, 4, 'Product Promotion Type', 'Relation betwen product types and promotion types that can be applied to this products', 'ADMIN|READ|MODIFY', 'product_promotion_type.xhtml');
INSERT INTO public.mt_application_menu VALUES (1020, 1017, false, 3, 3, 'Service Promotion Type', 'Relation betwen service types and promotion types that can be applied to this services', 'ADMIN|READ|MODIFY', 'service_promotion_type.xhtml');
INSERT INTO public.mt_application_menu VALUES (1023, 1021, false, 3, 2, 'Promotion Fee Type Discount', 'Relation between promotion types and fee types that can discount', 'ADMIN|READ|MODIFY', 'promotion_fee_type_disc.xhtml');
INSERT INTO public.mt_application_menu VALUES (1024, 1021, false, 3, 3, 'Promotion Consumption Type Discount', 'Relation between promotion types and consumption types that can discount', 'ADMIN|READ|MODIFY', 'promotion_consum_type_disc.xhtml');
INSERT INTO public.mt_application_menu VALUES (1025, 1000, false, 2, 2, 'Consumption Classes', 'Classes of consumptions', 'ADMIN|READ|MODIFY', 'consumption_class.xhtml');
INSERT INTO public.mt_application_menu VALUES (1002, 1000, false, 2, 3, 'Status', 'Status code', 'ADMIN|READ|MODIFY', 'status.xhtml');
INSERT INTO public.mt_application_menu VALUES (1003, 1000, false, 2, 4, 'Application Level', 'Application level for fees, promotions, etc', 'ADMIN|READ|MODIFY', 'application_level.xhtml');
INSERT INTO public.mt_application_menu VALUES (1004, 1000, false, 2, 5, 'Discount Type', 'Types of discounts (percentagel, units, …)', 'ADMIN|READ|MODIFY', 'discount_type.xhtml');
INSERT INTO public.mt_application_menu VALUES (1028, 1000, false, 2, 6, 'Payment Method', 'Methods to pay', 'ADMIN|READ|MODIFY', 'payment_method.xhtml');
INSERT INTO public.mt_application_menu VALUES (1027, 1000, false, 2, 8, 'Tax Type', 'Types of taxes', 'ADMIN|READ|MODIFY', 'tax_type.xhtml');
INSERT INTO public.mt_application_menu VALUES (1005, 1000, false, 2, 7, 'Billing Period', 'Diferents periodo billing for the billing process', 'ADMIN|READ|MODIFY', 'billing_period.xhtml');
INSERT INTO public.mt_application_menu VALUES (1030, 1000, false, 2, 8, 'Identity Card Type', 'Types of the distinct identity card for clients', 'ADMIN|READ|MODIFY', 'identity_card_type.xhtml');
INSERT INTO public.mt_application_menu VALUES (1006, NULL, true, 1, 2, 'CATALOG', 'Catalog of the system', 'ADMIN|READ|MODIFY', 'NULL');
INSERT INTO public.mt_application_menu VALUES (1032, NULL, true, 1, 3, 'CONTRACT', 'Contract data', 'ADMIN|READ|MODIFY', 'NULL');
INSERT INTO public.mt_application_menu VALUES (1033, 1032, false, 2, 1, 'Customer', 'Customer Management', 'ADMIN|READ|MODIFY', 'customer.xhtml');
INSERT INTO public.mt_application_menu VALUES (1034, 1032, false, 2, 2, 'Contract', 'Contract Management', 'ADMIN|READ|MODIFY', 'contract.xhtml');
INSERT INTO public.mt_application_menu VALUES (1035, 1032, false, 2, 3, 'Account', 'Account Management', 'ADMIN|READ|MODIFY', 'account.xhtml');
INSERT INTO public.mt_application_menu VALUES (1036, 1032, true, 2, 4, 'Product', 'Product Management', 'ADMIN|READ|MODIFY', 'NULL');
INSERT INTO public.mt_application_menu VALUES (1037, 1036, false, 3, 1, 'Product Instance', 'Instances of Product in the system', 'ADMIN|READ|MODIFY', 'product.xhtml');


--
-- Data for Name: pt_tax_type; Type: TABLE DATA; Schema: public; Owner: comasw_admin
--

INSERT INTO public.pt_tax_type VALUES (1002, 'IPSI_G', 'IPSI_GENERAL', 'Impuesto sobre la Producción, los Servicios y la Importación (IPSI) - Ceuta y Melilla - 8%', 8.0000);
INSERT INTO public.pt_tax_type VALUES (1000, 'IVA_G', 'IVA_GENERAL', 'Impuesto sobre el Valor Añadido (IVA) - Peninsula y Baleares - 21%', 21.0000);
INSERT INTO public.pt_tax_type VALUES (1001, 'IGIC_G', 'IGIC_GENERAL', 'Impuesto General Indirecto Canario (IGIC) - 7%', 7.0000);


--
-- Name: seq_account_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_account_id', 1010, true);


--
-- Name: seq_account_type_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_account_type_id', 1005, true);


--
-- Name: seq_application_level_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_application_level_id', 1030, true);


--
-- Name: seq_application_menu_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_application_menu_id', 1037, true);


--
-- Name: seq_bill_cycle_type_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_bill_cycle_type_id', 1003, true);


--
-- Name: seq_billing_period_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_billing_period_id', 1003, true);


--
-- Name: seq_consumption_class_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_consumption_class_id', 1007, true);


--
-- Name: seq_consumption_type; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_consumption_type', 1035, true);


--
-- Name: seq_contract_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_contract_id', 1009, true);


--
-- Name: seq_customer_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_customer_id', 1002, true);


--
-- Name: seq_customer_type_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_customer_type_id', 1002, true);


--
-- Name: seq_discount_type_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_discount_type_id', 1004, true);


--
-- Name: seq_entity_type_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_entity_type_id', 1015, true);


--
-- Name: seq_fee_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_fee_id', 1000, false);


--
-- Name: seq_fee_type_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_fee_type_id', 1077, true);


--
-- Name: seq_identity_card_type_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_identity_card_type_id', 1002, true);


--
-- Name: seq_payment_method_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_payment_method_id', 1003, true);


--
-- Name: seq_prod_fee_type_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_prod_fee_type_id', 1030, true);


--
-- Name: seq_prod_serv_type_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_prod_serv_type_id', 1040, true);


--
-- Name: seq_product_fee_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_product_fee_id', 1000, false);


--
-- Name: seq_product_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_product_id', 1004, true);


--
-- Name: seq_product_promotion_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_product_promotion_id', 1000, false);


--
-- Name: seq_product_service_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_product_service_id', 1000, false);


--
-- Name: seq_product_type_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_product_type_id', 1005, true);


--
-- Name: seq_profile_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_profile_id', 1003, true);


--
-- Name: seq_promo_consum_type_disc_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_promo_consum_type_disc_id', 1004, true);


--
-- Name: seq_promo_fee_type_disc_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_promo_fee_type_disc_id', 1020, true);


--
-- Name: seq_promo_prod_type_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_promo_prod_type_id', 1007, true);


--
-- Name: seq_promo_serv_type_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_promo_serv_type_id', 1007, true);


--
-- Name: seq_promotion_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_promotion_id', 1000, false);


--
-- Name: seq_promotion_type_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_promotion_type_id', 1024, true);


--
-- Name: seq_serv_fee_type_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_serv_fee_type_id', 1007, true);


--
-- Name: seq_service_fee_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_service_fee_id', 1000, false);


--
-- Name: seq_service_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_service_id', 1000, false);


--
-- Name: seq_service_promotion_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_service_promotion_id', 1000, false);


--
-- Name: seq_service_type_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_service_type_id', 1004, true);


--
-- Name: seq_status_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_status_id', 1005, true);


--
-- Name: seq_tax_type_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_tax_type_id', 1003, true);


--
-- Name: seq_user_id; Type: SEQUENCE SET; Schema: public; Owner: comasw_admin
--

SELECT pg_catalog.setval('public.seq_user_id', 1005, true);


--
-- PostgreSQL database dump complete
--

