--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5 (Ubuntu 14.5-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.5 (Ubuntu 14.5-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: tf_account_validate_parent_status(); Type: FUNCTION; Schema: public; Owner: comasw_admin
--

CREATE FUNCTION public.tf_account_validate_parent_status() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	DECLARE
	  parent_status_id Integer;
	  cancelled Integer;
	BEGIN
	  
	  SELECT status_id
            INTO parent_status_id
	     FROM public.it_customer
            where( (customer_id = NEW.customer_id
                AND (NEW.start_date, NEW.end_date) overlaps (start_date, end_date)));

      IF NOT FOUND 
	     THEN
	       RAISE EXCEPTION 'The customer with id % not exists for these dates', new.customer_id;
	     ELSE
	       SELECT 1
	         INTO cancelled
	         FROM public.pt_status
            WHERE status_id = parent_status_id 
              AND code = 'CANC';	       
	       
	       IF NOT FOUND 
	         THEN
	           RETURN NEW;	        
	         ELSE
	           RAISE EXCEPTION 'The customer with id % has cancelled for the gived dates', new.customer_id;
	         END IF;           
	  END IF;
	END;
 $$;


ALTER FUNCTION public.tf_account_validate_parent_status() OWNER TO comasw_admin;

--
-- Name: tf_add_account_validation(); Type: FUNCTION; Schema: public; Owner: comasw_admin
--

CREATE FUNCTION public.tf_add_account_validation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	declare
      data_exists INTEGER;
	BEGIN
	  SELECT 1
	  INTO data_exists
	     FROM public.it_account
            where( (account_id = NEW.account_id
                AND (NEW.start_date, NEW.end_date) overlaps (start_date, end_date)) or 
                (code = NEW.code
                AND (NEW.start_date, NEW.end_date) overlaps (start_date, end_date)));

      IF NOT FOUND 
	     THEN
	       RETURN NEW;
	     else
           RAISE EXCEPTION 'The account with this code (%) or account_id (%) exists for these dates', new.code, new.account_id;
	  END IF;
	END;
 $$;


ALTER FUNCTION public.tf_add_account_validation() OWNER TO comasw_admin;

--
-- Name: tf_add_customer_validation(); Type: FUNCTION; Schema: public; Owner: comasw_admin
--

CREATE FUNCTION public.tf_add_customer_validation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	declare
      data_exists INTEGER;
	BEGIN
	  SELECT 1
	  INTO data_exists
	     FROM public.it_customer
            where (customer_id = NEW.customer_id
                AND (NEW.start_date, NEW.end_date) overlaps (start_date, end_date)) ;

      IF NOT FOUND 
	     THEN
	       RETURN NEW;
	     else
           RAISE EXCEPTION 'The customer with this code (%) or customer_id (%) exists for these dates', new.code, new.customer_id;
	  END IF;
	END;
 $$;


ALTER FUNCTION public.tf_add_customer_validation() OWNER TO comasw_admin;

--
-- Name: tf_add_fee_type_validation(); Type: FUNCTION; Schema: public; Owner: comasw_admin
--

CREATE FUNCTION public.tf_add_fee_type_validation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	DECLARE
	  data_exists INTEGER;
	BEGIN
	  SELECT 1
            INTO data_exists
	     FROM public.ct_fee_type
            where code = NEW.code
                AND (NEW.start_date, NEW.end_date) overlaps (start_date, end_date)
                ;

      IF NOT FOUND 
	     THEN
	       RETURN NEW;
	     ELSE
           RAISE EXCEPTION 'A fee type with this code (%) or fee_id (%) exists for these dates', new.code, new.fee_id;
	  END IF;
	END;
 $$;


ALTER FUNCTION public.tf_add_fee_type_validation() OWNER TO comasw_admin;

--
-- Name: tf_add_fee_validation(); Type: FUNCTION; Schema: public; Owner: comasw_admin
--

CREATE FUNCTION public.tf_add_fee_validation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	DECLARE
	  data_exists INTEGER;
	BEGIN
	  SELECT 1
            INTO data_exists
	     FROM public.it_fee
            where((fee_id = NEW.fee_id
                AND (NEW.start_date, NEW.end_date) overlaps (start_date, end_date)) or 
                (code = NEW.code
                AND (NEW.start_date, NEW.end_date) overlaps (start_date, end_date)))
                AND NEW.parent_instance_id = parent_instance_id 
                AND NEW.application_level_id = application_level_id
                AND NEW.status_id = status_id and 
                status_id != (select st2.status_id from status_id st2 where st2.code = 'CANC');

      IF NOT FOUND 
	     THEN
	       RETURN NEW;
	     ELSE
           RAISE EXCEPTION 'An active fee with this code (%) or fee_id (%) exists for these dates', new.code, new.fee_id;
	  END IF;
	END;
 $$;


ALTER FUNCTION public.tf_add_fee_validation() OWNER TO comasw_admin;

--
-- Name: tf_add_product_validation(); Type: FUNCTION; Schema: public; Owner: comasw_admin
--

CREATE FUNCTION public.tf_add_product_validation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	DECLARE
	  data_exists INTEGER;
	BEGIN
	  SELECT 1
            INTO data_exists
	     FROM public.it_product
            where( (product_id = NEW.product_id
                AND (NEW.start_date, NEW.end_date) overlaps (start_date, end_date)) or 
                (code = NEW.code
                AND (NEW.start_date, NEW.end_date) overlaps (start_date, end_date)));

      IF NOT FOUND 
	     THEN
	       RETURN NEW;
	     ELSE
           RAISE EXCEPTION 'The product type with this code (%) or product_id (%) exists for these dates', new.code, new.product_id;
	  END IF;
	END;
 $$;


ALTER FUNCTION public.tf_add_product_validation() OWNER TO comasw_admin;

--
-- Name: tf_add_promotion_type_validation(); Type: FUNCTION; Schema: public; Owner: comasw_admin
--

CREATE FUNCTION public.tf_add_promotion_type_validation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	DECLARE
	  data_exists INTEGER;
	BEGIN
	  SELECT 1
            INTO data_exists
	     FROM public.ct_promotion_type
            where code = NEW.code
                AND (NEW.start_date, NEW.end_date) overlaps (start_date, end_date);

      IF NOT FOUND 
	     THEN
	       RETURN NEW;
	     ELSE
           RAISE EXCEPTION 'An active promotion with this code (%) or promotion_id (%) exists for these dates', new.code, new.promotion_id;
	  END IF;
	END;
 $$;


ALTER FUNCTION public.tf_add_promotion_type_validation() OWNER TO comasw_admin;

--
-- Name: tf_add_promotion_validation(); Type: FUNCTION; Schema: public; Owner: comasw_admin
--

CREATE FUNCTION public.tf_add_promotion_validation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	DECLARE
	  data_exists INTEGER;
	BEGIN
	  SELECT 1
            INTO data_exists
	     FROM public.it_promotion
            where((promotion_id = NEW.promotion_id
                AND (NEW.start_date, NEW.end_date) overlaps (start_date, end_date)) or 
                (code = NEW.code
                AND (NEW.start_date, NEW.end_date) overlaps (start_date, end_date)))
                AND NEW.parent_instance_id = parent_instance_id 
                AND NEW.application_level_id = application_level_id
                AND NEW.status_id = status_id and 
                status_id != (select st2.status_id from status_id st2 where st2.code = 'CANC');

      IF NOT FOUND 
	     THEN
	       RETURN NEW;
	     ELSE
           RAISE EXCEPTION 'An active promotion with this code (%) or promotion_id (%) exists for these dates', new.code, new.promotion_id;
	  END IF;
	END;
 $$;


ALTER FUNCTION public.tf_add_promotion_validation() OWNER TO comasw_admin;

--
-- Name: tf_add_service_validation(); Type: FUNCTION; Schema: public; Owner: comasw_admin
--

CREATE FUNCTION public.tf_add_service_validation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	DECLARE
	  data_exists INTEGER;
	BEGIN
	  SELECT 1
            INTO data_exists
	     FROM public.it_service
            where ((service_id = NEW.service_id
                AND (NEW.start_date, NEW.end_date) overlaps (start_date, end_date)) or 
                (code_number = NEW.code_number
                AND (NEW.start_date, NEW.end_date) overlaps (start_date, end_date)))
                AND NEW.status_id = status_id and 
                status_id != (select st2.status_id from status_id st2 where st2.code = 'CANC');

      IF NOT FOUND 
	     THEN
	       RETURN NEW;
	     ELSE
           RAISE EXCEPTION 'An active service with this code_number (%) or service_id (%) exists for these dates', new.code_number, new.service_id;
	  END IF;
	END;
 $$;


ALTER FUNCTION public.tf_add_service_validation() OWNER TO comasw_admin;

--
-- Name: tf_create_contract_nr(); Type: FUNCTION; Schema: public; Owner: comasw_admin
--

CREATE FUNCTION public.tf_create_contract_nr() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	BEGIN	 
	     
	    new.CONTRACT_number = CONCAT('CMS', NEW.CONTRACT_ID::text);
         RETURN NEW; 
	  
	END;
 $$;


ALTER FUNCTION public.tf_create_contract_nr() OWNER TO comasw_admin;

--
-- Name: tf_create_fee_inherit_data(); Type: FUNCTION; Schema: public; Owner: comasw_admin
--

CREATE FUNCTION public.tf_create_fee_inherit_data() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	DECLARE
	  type_code Varchar(10);	 
	  type_prorrate BOOLEAN;
	  type_price NUMERIC(10,4);
	  
	BEGIN
	
        SELECT CODE,              
               PRORATE,
	           PRICE 
	    into type_code,	   
	    type_prorrate,
	    type_price
          FROM CT_FEE_TYPE
         WHERE NEW.FEE_TYPE_ID = FEE_TYPE_ID
           AND NEW.START_DATE BETWEEN START_DATE AND END_DATE;
     
         IF NOT FOUND 
	       THEN
	         RAISE EXCEPTION 'Not exists the fee type with id % for this dates', new.fee_type_id;
         END IF;
    
    
         IF (NEW.CODE IS NULL)
           THEN
             NEW.CODE = type_code;
         END IF;
    
         IF (NEW.PRORATE IS NULL)
           THEN 
             NEW.PRORATE = type_prorrate;
         END IF;
     
        IF (NEW.PRICE IS NULL)
           THEN 
             NEW.PRICE = type_price;
         END IF;     
     
         RETURN NEW;
    
	END;
 $$;


ALTER FUNCTION public.tf_create_fee_inherit_data() OWNER TO comasw_admin;

--
-- Name: tf_create_product_code(); Type: FUNCTION; Schema: public; Owner: comasw_admin
--

CREATE FUNCTION public.tf_create_product_code() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	DECLARE
	  typeCode Varchar(10);
	BEGIN
	  
	  if (new.code is null)
	      then
	        select code
	           into typeCode
            from ct_product_type 
              where product_type_id = new.product_type_id;
        
        IF NOT FOUND 
	     THEN
	        RAISE EXCEPTION 'Not exists the product type with id %', new.product_type_id;
         ELSE
	       NEW.CODE = typeCode;          
	     END IF;      
       end if;       
        return new;
	END;
 $$;


ALTER FUNCTION public.tf_create_product_code() OWNER TO comasw_admin;

--
-- Name: tf_create_promotion_inherit_data(); Type: FUNCTION; Schema: public; Owner: comasw_admin
--

CREATE FUNCTION public.tf_create_promotion_inherit_data() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	DECLARE
	  code Varchar(10);
	  APPLICATION_LEVEL_ID INT4;
	  DISCOUNT_TYPE_ID INT4;
	  DISCOUNT_VALUE NUMERIC(10,4);
	BEGIN
	
        SELECT CODE,
               APPLICATION_LEVEL_ID,
               DISCOUNT_TYPE_ID,
	           DISCOUNT_VALUE 
          FROM CT_PROMOTION_TYPE
         WHERE NEW.PROMOTION_TYPE_ID = PROMOTION_TYPE_ID
           AND NEW.START_DATE BETWEEN START_DATE AND END_DATE;
     
         IF NOT FOUND 
	       THEN
	         RAISE EXCEPTION 'Not exists the promotion type with id % for this dates', new.promotion_type_id;
         END IF;
    
    
         NEW.APPLICATION_LEVEL_ID = APPLICATION_LEVEL_ID;
         NEW.DISCOUNT_TYPE_ID = DISCOUNT_TYPE_ID;
    
         IF (NEW.CODE IS NULL)
           THEN
             NEW.CODE = CODE;
         END IF;
    
         IF (NEW.DISCOUNT_VALUE IS NULL)
           THEN 
             NEW.DISCOUNT_VALUE = DISCOUNT_VALUE;
         END IF;
     
         RETURN NEW;
    
	END;
 $$;


ALTER FUNCTION public.tf_create_promotion_inherit_data() OWNER TO comasw_admin;

--
-- Name: tf_create_service_code(); Type: FUNCTION; Schema: public; Owner: comasw_admin
--

CREATE FUNCTION public.tf_create_service_code() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	DECLARE
	  typeCode Varchar(10);
	BEGIN
	  
	  if (new.code is null)
	      then
	        select code
	           into typeCode
            from ct_service_type 
              where service_type_id = new.service_type_id;
        
        IF NOT FOUND 
	     THEN
	        RAISE EXCEPTION 'Not exists the service type with id %', new.service_type_id;
         ELSE
	       NEW.CODE = typeCode;          
	     END IF;      
       end if;       
        
      return new;
	END;
 $$;


ALTER FUNCTION public.tf_create_service_code() OWNER TO comasw_admin;

--
-- Name: tf_fee_validate_parent_status(); Type: FUNCTION; Schema: public; Owner: comasw_admin
--

CREATE FUNCTION public.tf_fee_validate_parent_status() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	DECLARE
      application_level_code varchar(10);
	  result boolean;
	BEGIN
	  
	  SELECT AL.CODE
	    INTO application_level_code
	    FROM CT_FEE_TYPE PT
       INNER JOIN PT_APPLICATION_LEVEL AL
          ON PT.APPLICATION_LEVEL_ID = AL.APPLICATION_LEVEL_ID
        WHERE PT.FEE_TYPE_ID = NEW.FEE_TYPE_ID
        AND NEW.START_DATE BETWEEN PT.START_DATE AND PT.END_DATE;
	  
	   IF NOT FOUND 
	     THEN
	       RAISE EXCEPTION 'The fee type with id % not exists for this dates', new.fee_type_id;
	   END IF;
	   
	   CASE WHEN upper(application_level_code) = 'PROD'
	      THEN 
	         result = tf_is_product_active (new.parent_instance_id, new.start_date, new.end_date );
	         if (result = false)
	           then RAISE EXCEPTION 'Not exists a active product with id % for these dates ', new.parent_instance_id;
	         end if;
	      ELSE
	         CASE WHEN upper(application_level_code) = 'SERV'
	           THEN
	             result = tf_is_service_active(new.parent_instance_id, new.start_date, new.end_date );
	             if (result = false)
	               then RAISE EXCEPTION 'Not exists a active service with id % for these dates ', new.parent_instance_id;
	             end if	   ;          
	           ELSE
                 RAISE EXCEPTION 'Unespected application level code (%) for fee id %', application_level_code, new.fee_id;
	         END CASE;
       END CASE;
      
      return new;
	  
	END;
 $$;


ALTER FUNCTION public.tf_fee_validate_parent_status() OWNER TO comasw_admin;

--
-- Name: tf_is_product_active(integer, date, date); Type: FUNCTION; Schema: public; Owner: comasw_admin
--

CREATE FUNCTION public.tf_is_product_active(var_product_id integer, var_start_date date, var_end_date date) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
  DECLARE
	data_exists integer;	
  BEGIN
    
	
	SELECT 1
      INTO data_exists
	  FROM it_product t
     WHERE t.product_id = var_product_id
       AND (var_start_date, var_end_date) overlaps (t.start_date, t.end_date)
       AND NOT EXISTS 
           (SELECT 1 
              FROM it_product t2
             INNER JOIN pt_status st                 
                ON st.status_id = t2.status_id
               AND st.code = 'CANC'
             WHERE t2.product_id = t.product_id);

	IF NOT FOUND 
	  THEN
	    return false;
      ELSE
        return true;
	END IF;	   
	  
  END;
 $$;


ALTER FUNCTION public.tf_is_product_active(var_product_id integer, var_start_date date, var_end_date date) OWNER TO comasw_admin;

--
-- Name: tf_is_service_active(integer, date, date); Type: FUNCTION; Schema: public; Owner: comasw_admin
--

CREATE FUNCTION public.tf_is_service_active(var_service_id integer, var_start_date date, var_end_date date) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
  DECLARE
	data_exists integer;	
  BEGIN
    
	
	SELECT 1
      INTO data_exists
	  FROM it_service t
     WHERE t.service_id = var_service_id
       AND (var_start_date, var_end_date) overlaps (t.start_date, t.end_date)
       AND NOT EXISTS 
           (SELECT 1 
              FROM it_service t2
             INNER JOIN pt_status st                 
                ON st.status_id = t2.status_id
               AND st.code = 'CANC'
             WHERE t2.service_id = t.service_id);

	IF NOT FOUND 
	  THEN
	    return false;
      ELSE
        return true;
	END IF;	   
	  
  END;
 $$;


ALTER FUNCTION public.tf_is_service_active(var_service_id integer, var_start_date date, var_end_date date) OWNER TO comasw_admin;

--
-- Name: tf_product_active_date_changed(); Type: FUNCTION; Schema: public; Owner: comasw_admin
--

CREATE FUNCTION public.tf_product_active_date_changed() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	
	begin
	  if (new.active_date <> old.active_date)	  
	   then 
	     update public.it_product p 
	       set p.active_date = new.active_date
	       where p.product_id  = new.product_id;
	 end if;
		
	 RETURN NEW;	 
	END;
 $$;


ALTER FUNCTION public.tf_product_active_date_changed() OWNER TO comasw_admin;

--
-- Name: tf_product_cancelled_date_changed(); Type: FUNCTION; Schema: public; Owner: comasw_admin
--

CREATE FUNCTION public.tf_product_cancelled_date_changed() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	
	begin
	  if ((new.cancelled_date is not null ) and (new.cancelled_date <> old.cancelled_date))	  
	   then 
	     update public.it_product p 
	       set p.cancelled_date = new.cancelled_date
	       where p.product_id  = new.product_id;
	 end if;
		
	 RETURN NEW;	 
	END;
 $$;


ALTER FUNCTION public.tf_product_cancelled_date_changed() OWNER TO comasw_admin;

--
-- Name: tf_product_cancelled_row(); Type: FUNCTION; Schema: public; Owner: comasw_admin
--

CREATE FUNCTION public.tf_product_cancelled_row() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	DECLARE
	  cancelledStatusId INTEGER;
	begin
	  select status_id 
	    into cancelledStatusId
	  from public.pt_status s
	  where s."instance" = true
	  and code = 'CANC';
	 
	 if (new.status_id = cancelledStatusId)
	   then 
	     update public.it_product p 
	       set p.status_id = new.status_id
	       where p.product_id  = new.product_id
	       and p.start_date >= new.start_date ;
	 end if;
		
	 RETURN NEW;	 
	END;
 $$;


ALTER FUNCTION public.tf_product_cancelled_row() OWNER TO comasw_admin;

--
-- Name: tf_product_validate_parent_status(); Type: FUNCTION; Schema: public; Owner: comasw_admin
--

CREATE FUNCTION public.tf_product_validate_parent_status() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	DECLARE
	  parent_status_id Integer;
	  cancelled Integer;
	BEGIN
	  
	  SELECT status_id
            INTO parent_status_id
	     FROM public.it_account
            where( (account_id = NEW.account_id
                AND (NEW.start_date, NEW.end_date) overlaps (start_date, end_date)));

      IF NOT FOUND 
	     THEN
	       RAISE EXCEPTION 'The account with id % not exists for these dates', new.account_id;
	     ELSE
	       SELECT 1
	         INTO cancelled
	         FROM public.pt_status
            WHERE status_id = parent_status_id 
              AND code = 'CANC';	       
	       
	       IF NOT FOUND 
	         THEN
	           RETURN NEW;	        
	         ELSE
	           RAISE EXCEPTION 'The account with id % has cancelled for the gived dates', new.account_id;
	         END IF;           
	  END IF;
	END;
 $$;


ALTER FUNCTION public.tf_product_validate_parent_status() OWNER TO comasw_admin;

--
-- Name: tf_promotion_validate_parent_status(); Type: FUNCTION; Schema: public; Owner: comasw_admin
--

CREATE FUNCTION public.tf_promotion_validate_parent_status() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	DECLARE
      application_level_code varchar(10);
	  parent_status_id Integer;
	  cancelled Integer;
	BEGIN
	  
	  SELECT PT.CODE
	    INTO application_level_code
	    FROM CT_PROMOTION_TYPE PT
       INNER JOIN PT_APPLICATION_TYPE AT
          ON PT.APPLICATION_LEVEL_ID = AT.APPLICATION_LEVEL_ID
        WHERE PT.PROMOTION_TYPE_ID = NEW.PROMOTION_TYPE_ID
        AND NEW.START_DATE BETWEEN PT.START_DATE AND PT.END_DATE;
	  
	   IF NOT FOUND 
	     THEN
	       RAISE EXCEPTION 'The promotion type with id % not exists for this dates', new.promotion_type_id;
	   END IF;
	   
	   CASE WHEN application_level_code = 'PROD'
	      THEN 
	         execute function tf_validate_parent_product_status;
	      ELSE
	         CASE WHEN application_level_code = 'SERV'
	           THEN
	             execute function tf_validate_parent_service_status;
	           ELSE
                 RAISE EXCEPTION 'Unespected application level code (%) for promotion id %', application_level_code, new.promotion_id;
	         END CASE;
       END CASE;
	  
	END;
 $$;


ALTER FUNCTION public.tf_promotion_validate_parent_status() OWNER TO comasw_admin;

--
-- Name: tf_service_validate_parent_status(); Type: FUNCTION; Schema: public; Owner: comasw_admin
--

CREATE FUNCTION public.tf_service_validate_parent_status() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	DECLARE
	  parent_status_id Integer;
	  cancelled Integer;
	BEGIN
	  
	  SELECT status_id
            INTO parent_status_id
	     FROM public.it_product
            where( (product_id = NEW.product_id
                AND (NEW.start_date, NEW.end_date) overlaps (start_date, end_date)));

      IF NOT FOUND 
	     THEN
	       RAISE EXCEPTION 'The product with id % not exists for these dates', new.product_id;
	     ELSE
	       SELECT 1
	         INTO cancelled
	         FROM public.pt_status
            WHERE status_id = parent_status_id 
              AND code = 'CANC';	       
	       
	       IF NOT FOUND 
	         THEN
	           RETURN NEW;	        
	         ELSE
	           RAISE EXCEPTION 'The product with id % has cancelled for the gived dates', new.product_id;
	         END IF;           
	  END IF;
	END;
 $$;


ALTER FUNCTION public.tf_service_validate_parent_status() OWNER TO comasw_admin;

--
-- Name: tf_validate_parent_product_status(); Type: FUNCTION; Schema: public; Owner: comasw_admin
--

CREATE FUNCTION public.tf_validate_parent_product_status() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	DECLARE
	  parent_status_id Integer;
	  cancelled Integer;
	BEGIN
	  
	  SELECT status_id
            INTO parent_status_id
	     FROM public.it_product p 	  
            where (product_id = NEW.parent_instance_id);
               

      IF NOT FOUND 
	     THEN
	       RAISE EXCEPTION 'The parent product with id % not exists', new.product_id;
	     ELSE
	       SELECT 1
	         INTO cancelled
	         FROM public.pt_status
            WHERE status_id = parent_status_id 
              AND code = 'CANC';	       
	       
	       IF NOT FOUND 
	         THEN
	           RETURN NEW;	        
	         ELSE
	           RAISE EXCEPTION 'The product with id % is cancelled', new.product_id;
	         END IF;           
	  END IF;
	END;
 $$;


ALTER FUNCTION public.tf_validate_parent_product_status() OWNER TO comasw_admin;

--
-- Name: tf_validate_parent_service_status(); Type: FUNCTION; Schema: public; Owner: comasw_admin
--

CREATE FUNCTION public.tf_validate_parent_service_status() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	DECLARE
	  parent_status_id Integer;
	  cancelled Integer;
	BEGIN
	  
	  SELECT status_id
            INTO parent_status_id
	     FROM public.it_service p 	  
            where (service_id = NEW.parent_instance_id);
               

      IF NOT FOUND 
	     THEN
	       RAISE EXCEPTION 'The parent service with id % not exists', new.product_id;
	     ELSE
	       SELECT 1
	         INTO cancelled
	         FROM public.pt_status
            WHERE status_id = parent_status_id 
              AND code = 'CANC';	       
	       
	       IF NOT FOUND 
	         THEN
	           RETURN NEW;	        
	         ELSE
	           RAISE EXCEPTION 'The service with id % is cancelled', new.product_id;
	         END IF;           
	  END IF;
	END;
 $$;


ALTER FUNCTION public.tf_validate_parent_service_status() OWNER TO comasw_admin;

--
-- Name: tf_validate_parent_status(); Type: FUNCTION; Schema: public; Owner: comasw_admin
--

CREATE FUNCTION public.tf_validate_parent_status() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	DECLARE
	  parent_status_id Integer;
	  cancelled Integer;
	BEGIN
	  
	  SELECT status_id
            INTO parent_status_id
	     FROM public.it_product
            where( (product_id = NEW.product_id
                AND (NEW.start_date, NEW.end_date) overlaps (start_date, end_date)));

      IF NOT FOUND 
	     THEN
	       RAISE EXCEPTION 'The product with id % not exists for these dates', new.product_id;
	     ELSE
	       SELECT 1
	         INTO cancelled
	         FROM public.pt_status
            WHERE status_id = parent_status_id 
              AND code = 'CANC';	       
	       
	       IF NOT FOUND 
	         THEN
	           RETURN NEW;	        
	         ELSE
	           RAISE EXCEPTION 'The product_id with id % has cancelled for the gived dates', new.product_id;
	         END IF;           
	  END IF;
	END;
 $$;


ALTER FUNCTION public.tf_validate_parent_status() OWNER TO comasw_admin;

--
-- Name: seq_account_type_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_account_type_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_account_type_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_account_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_account_type_id IS 'sequence for field account_type_id in table ct_account_type';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ct_account_type; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.ct_account_type (
    account_type_id integer DEFAULT nextval('public.seq_account_type_id'::regclass) NOT NULL,
    entity_type_id integer DEFAULT 1009 NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(500) NOT NULL,
    ordinary_bill_cycle_type_id integer NOT NULL,
    corrective_bill_cycle_type_id integer NOT NULL,
    status_id integer DEFAULT 1000 NOT NULL,
    input_date timestamp without time zone DEFAULT (('now'::text)::timestamp(0) with time zone)::timestamp without time zone NOT NULL,
    input_user character varying(10) NOT NULL,
    modif_date timestamp without time zone,
    modif_user character varying(10),
    payment_method_id integer NOT NULL
);


ALTER TABLE public.ct_account_type OWNER TO comasw_admin;

--
-- Name: TABLE ct_account_type; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.ct_account_type IS 'Table that stores the account types of the catalog for the application';


--
-- Name: COLUMN ct_account_type.account_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_account_type.account_type_id IS 'Internal identifier of the account type';


--
-- Name: COLUMN ct_account_type.entity_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_account_type.entity_type_id IS 'Entity_id for the account type';


--
-- Name: COLUMN ct_account_type.code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_account_type.code IS 'Code of the account type';


--
-- Name: COLUMN ct_account_type.name; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_account_type.name IS 'Name of the account type';


--
-- Name: COLUMN ct_account_type.description; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_account_type.description IS 'Description for the account type';


--
-- Name: COLUMN ct_account_type.ordinary_bill_cycle_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_account_type.ordinary_bill_cycle_type_id IS 'Ordinary cycle type id for the ordinary billing of the account';


--
-- Name: COLUMN ct_account_type.corrective_bill_cycle_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_account_type.corrective_bill_cycle_type_id IS 'Bill cycle type id for the ordinary billing of the account';


--
-- Name: COLUMN ct_account_type.status_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_account_type.status_id IS 'Status id for the account type';


--
-- Name: COLUMN ct_account_type.input_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_account_type.input_date IS 'Date on which the record was created';


--
-- Name: COLUMN ct_account_type.input_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_account_type.input_user IS 'User who was modified the record';


--
-- Name: COLUMN ct_account_type.modif_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_account_type.modif_date IS 'Date of the last modification of the record';


--
-- Name: COLUMN ct_account_type.modif_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_account_type.modif_user IS 'User who was modified the record';


--
-- Name: COLUMN ct_account_type.payment_method_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_account_type.payment_method_id IS 'Payment method associated with the account type';


--
-- Name: seq_bill_cycle_type_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_bill_cycle_type_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_bill_cycle_type_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_bill_cycle_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_bill_cycle_type_id IS 'sequence for field bill_cycle_type_id in table ct_bill_cycle_type';


--
-- Name: ct_bill_cycle_type; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.ct_bill_cycle_type (
    bill_cycle_type_id integer DEFAULT nextval('public.seq_bill_cycle_type_id'::regclass) NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(500) NOT NULL,
    billing_period_id integer NOT NULL,
    bill_cycle_day numeric(2,0) NOT NULL,
    bill_cycle_codenum character varying(10) NOT NULL,
    status_id integer DEFAULT 1000 NOT NULL,
    input_date timestamp without time zone DEFAULT (('now'::text)::timestamp(0) with time zone)::timestamp without time zone NOT NULL,
    input_user character varying(10) NOT NULL,
    modif_date timestamp without time zone,
    modif_user character varying(10),
    corrective boolean NOT NULL
);


ALTER TABLE public.ct_bill_cycle_type OWNER TO comasw_admin;

--
-- Name: TABLE ct_bill_cycle_type; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.ct_bill_cycle_type IS 'Table that stores the bill cycle type of the application';


--
-- Name: COLUMN ct_bill_cycle_type.bill_cycle_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_bill_cycle_type.bill_cycle_type_id IS 'Internal identifier of the bill cycle type';


--
-- Name: COLUMN ct_bill_cycle_type.code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_bill_cycle_type.code IS 'Code of the bill cycle type';


--
-- Name: COLUMN ct_bill_cycle_type.name; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_bill_cycle_type.name IS 'Name of the bill cycle type';


--
-- Name: COLUMN ct_bill_cycle_type.description; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_bill_cycle_type.description IS 'Description for the bill cycle type';


--
-- Name: COLUMN ct_bill_cycle_type.billing_period_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_bill_cycle_type.billing_period_id IS 'Billing period for the bill cycle type';


--
-- Name: COLUMN ct_bill_cycle_type.bill_cycle_codenum; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_bill_cycle_type.bill_cycle_codenum IS 'Billing numbering code with which the invoice number is composed';


--
-- Name: COLUMN ct_bill_cycle_type.corrective; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_bill_cycle_type.corrective IS 'Flag for corrective cycle (true: corrective cycle, false: ordinary cycle)';


--
-- Name: seq_consumption_type; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_consumption_type
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_consumption_type OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_consumption_type; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_consumption_type IS 'sequence for field consumption_type_id in table ct_consumption_type';


--
-- Name: ct_consumption_type; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.ct_consumption_type (
    consumption_type_id integer DEFAULT nextval('public.seq_consumption_type'::regclass) NOT NULL,
    entity_type_id integer DEFAULT 1004 NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(500) NOT NULL,
    status_id integer DEFAULT 1000 NOT NULL,
    input_date timestamp without time zone DEFAULT (('now'::text)::timestamp(0) with time zone)::timestamp without time zone NOT NULL,
    input_user character varying(10) NOT NULL,
    modif_date timestamp without time zone,
    modif_user character varying(10),
    consumption_class_id integer NOT NULL
);


ALTER TABLE public.ct_consumption_type OWNER TO comasw_admin;

--
-- Name: TABLE ct_consumption_type; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.ct_consumption_type IS 'Table that stores the consumption types of the catalog for the application';


--
-- Name: COLUMN ct_consumption_type.consumption_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_consumption_type.consumption_type_id IS 'Internal identifier of the consumption type';


--
-- Name: COLUMN ct_consumption_type.entity_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_consumption_type.entity_type_id IS 'Entity_id for the consumption type';


--
-- Name: COLUMN ct_consumption_type.code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_consumption_type.code IS 'Code of the consumption type';


--
-- Name: COLUMN ct_consumption_type.name; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_consumption_type.name IS 'Name of the consumption type';


--
-- Name: COLUMN ct_consumption_type.description; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_consumption_type.description IS 'Description for the consumption type';


--
-- Name: COLUMN ct_consumption_type.status_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_consumption_type.status_id IS 'Status id for the consumption type';


--
-- Name: COLUMN ct_consumption_type.input_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_consumption_type.input_date IS 'Date on which the record was created';


--
-- Name: COLUMN ct_consumption_type.input_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_consumption_type.input_user IS 'User who was modified the record';


--
-- Name: COLUMN ct_consumption_type.modif_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_consumption_type.modif_date IS 'Date of the last modification of the record';


--
-- Name: COLUMN ct_consumption_type.consumption_class_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_consumption_type.consumption_class_id IS 'Consumption class for the consumption type';


--
-- Name: seq_customer_type_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_customer_type_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_customer_type_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_customer_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_customer_type_id IS 'sequence for field customer_type_id in table ct_customer_type';


--
-- Name: ct_customer_type; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.ct_customer_type (
    customer_type_id integer DEFAULT nextval('public.seq_customer_type_id'::regclass) NOT NULL,
    entity_type_id integer DEFAULT 1008 NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(500) NOT NULL,
    status_id integer DEFAULT 1000 NOT NULL,
    input_date timestamp without time zone DEFAULT (('now'::text)::timestamp(0) with time zone)::timestamp without time zone NOT NULL,
    input_user character varying(10) NOT NULL,
    modif_date timestamp without time zone,
    modif_user character varying(10)
);


ALTER TABLE public.ct_customer_type OWNER TO comasw_admin;

--
-- Name: TABLE ct_customer_type; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.ct_customer_type IS 'Table that stores the customer types of the catalog for the application';


--
-- Name: COLUMN ct_customer_type.customer_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_customer_type.customer_type_id IS 'Internal identifier of the customer type';


--
-- Name: COLUMN ct_customer_type.entity_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_customer_type.entity_type_id IS 'Entity_id for the customer type';


--
-- Name: COLUMN ct_customer_type.code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_customer_type.code IS 'Code of the customer type';


--
-- Name: COLUMN ct_customer_type.name; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_customer_type.name IS 'Name of the customer type';


--
-- Name: COLUMN ct_customer_type.description; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_customer_type.description IS 'Description for the customer type';


--
-- Name: COLUMN ct_customer_type.status_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_customer_type.status_id IS 'Status id for the customer type';


--
-- Name: COLUMN ct_customer_type.input_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_customer_type.input_date IS 'Date on which the record was created';


--
-- Name: COLUMN ct_customer_type.input_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_customer_type.input_user IS 'User who was modified the record';


--
-- Name: COLUMN ct_customer_type.modif_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_customer_type.modif_date IS 'Date of the last modification of the record';


--
-- Name: ct_fee_type; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.ct_fee_type (
    fee_type_id integer NOT NULL,
    entity_type_id integer DEFAULT 1003 NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(500) NOT NULL,
    application_level_id integer NOT NULL,
    prorate boolean DEFAULT false NOT NULL,
    price numeric(10,4) NOT NULL,
    status_id integer DEFAULT 1000 NOT NULL,
    input_date timestamp without time zone DEFAULT (('now'::text)::timestamp(0) with time zone)::timestamp without time zone NOT NULL,
    input_user character varying(10) NOT NULL,
    modif_date timestamp without time zone,
    modif_user character varying(10)
);


ALTER TABLE public.ct_fee_type OWNER TO comasw_admin;

--
-- Name: TABLE ct_fee_type; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.ct_fee_type IS 'Table that stores the fee types of the catalog for the application';


--
-- Name: COLUMN ct_fee_type.fee_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_fee_type.fee_type_id IS 'Internal identifier of the fee type';


--
-- Name: COLUMN ct_fee_type.entity_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_fee_type.entity_type_id IS 'Entity_id for the fee type';


--
-- Name: COLUMN ct_fee_type.start_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_fee_type.start_date IS 'Start_date for the fee type';


--
-- Name: COLUMN ct_fee_type.end_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_fee_type.end_date IS 'End_date for the fee type';


--
-- Name: COLUMN ct_fee_type.code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_fee_type.code IS 'Code of the fee type';


--
-- Name: COLUMN ct_fee_type.name; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_fee_type.name IS 'Name of the fee type';


--
-- Name: COLUMN ct_fee_type.description; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_fee_type.description IS 'Description for the fee type';


--
-- Name: COLUMN ct_fee_type.application_level_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_fee_type.application_level_id IS 'Application level id for the fee type';


--
-- Name: COLUMN ct_fee_type.prorate; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_fee_type.prorate IS 'Flag for prorate (true: prorated fee)';


--
-- Name: COLUMN ct_fee_type.price; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_fee_type.price IS 'Price for the fee type';


--
-- Name: COLUMN ct_fee_type.status_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_fee_type.status_id IS 'Status id for the fee type';


--
-- Name: COLUMN ct_fee_type.input_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_fee_type.input_date IS 'Date on which the record was created';


--
-- Name: COLUMN ct_fee_type.input_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_fee_type.input_user IS 'User who was created the record';


--
-- Name: COLUMN ct_fee_type.modif_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_fee_type.modif_date IS 'Date of the last modification of the record';


--
-- Name: COLUMN ct_fee_type.modif_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_fee_type.modif_user IS 'User who was modified the record';


--
-- Name: seq_prod_fee_type_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_prod_fee_type_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_prod_fee_type_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_prod_fee_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_prod_fee_type_id IS 'sequence for field prod_fee_type_id in table ct_prod_fee_type';


--
-- Name: ct_prod_fee_type; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.ct_prod_fee_type (
    prod_fee_type_id integer DEFAULT nextval('public.seq_prod_fee_type_id'::regclass) NOT NULL,
    product_type_id integer NOT NULL,
    fee_type_id integer NOT NULL,
    status_id integer DEFAULT 1000 NOT NULL,
    input_date timestamp without time zone DEFAULT (('now'::text)::timestamp(0) with time zone)::timestamp without time zone NOT NULL,
    input_user character varying(10) NOT NULL,
    modif_date timestamp without time zone,
    modif_user character varying(10)
);


ALTER TABLE public.ct_prod_fee_type OWNER TO comasw_admin;

--
-- Name: TABLE ct_prod_fee_type; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.ct_prod_fee_type IS 'Table that stores the fee product relation types of the catalog for the application';


--
-- Name: COLUMN ct_prod_fee_type.prod_fee_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_prod_fee_type.prod_fee_type_id IS 'Internal identifier of the product-fee relation type';


--
-- Name: COLUMN ct_prod_fee_type.product_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_prod_fee_type.product_type_id IS 'Product_type_id for the product-fee relation';


--
-- Name: COLUMN ct_prod_fee_type.fee_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_prod_fee_type.fee_type_id IS 'Service_type_id for the product-fee relation';


--
-- Name: COLUMN ct_prod_fee_type.status_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_prod_fee_type.status_id IS 'Status id for the product-fee relation type';


--
-- Name: COLUMN ct_prod_fee_type.input_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_prod_fee_type.input_date IS 'Date on which the record was created';


--
-- Name: COLUMN ct_prod_fee_type.input_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_prod_fee_type.input_user IS 'User who was modified the record';


--
-- Name: COLUMN ct_prod_fee_type.modif_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_prod_fee_type.modif_date IS 'Date of the last modification of the record';


--
-- Name: seq_prod_serv_type_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_prod_serv_type_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_prod_serv_type_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_prod_serv_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_prod_serv_type_id IS 'sequence for field prod_serv_type_id in table ct_prod_serv_type';


--
-- Name: ct_prod_serv_type; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.ct_prod_serv_type (
    prod_serv_type_id integer DEFAULT nextval('public.seq_prod_serv_type_id'::regclass) NOT NULL,
    product_type_id integer NOT NULL,
    service_type_id integer NOT NULL,
    status_id integer DEFAULT 1000 NOT NULL,
    input_date timestamp without time zone DEFAULT (('now'::text)::timestamp(0) with time zone)::timestamp without time zone NOT NULL,
    input_user character varying(10) NOT NULL,
    modif_date timestamp without time zone,
    modif_user character varying(10)
);


ALTER TABLE public.ct_prod_serv_type OWNER TO comasw_admin;

--
-- Name: TABLE ct_prod_serv_type; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.ct_prod_serv_type IS 'Table that stores the promotion product relation types of the catalog for the application';


--
-- Name: COLUMN ct_prod_serv_type.prod_serv_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_prod_serv_type.prod_serv_type_id IS 'Internal identifier of the product-service relation type';


--
-- Name: COLUMN ct_prod_serv_type.product_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_prod_serv_type.product_type_id IS 'Product_type_id for the product-service relation';


--
-- Name: COLUMN ct_prod_serv_type.service_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_prod_serv_type.service_type_id IS 'Service_type_id for the product-service relation';


--
-- Name: COLUMN ct_prod_serv_type.status_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_prod_serv_type.status_id IS 'Status id for the product-service relation type';


--
-- Name: COLUMN ct_prod_serv_type.input_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_prod_serv_type.input_date IS 'Date on which the record was created';


--
-- Name: COLUMN ct_prod_serv_type.input_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_prod_serv_type.input_user IS 'User who was modified the record';


--
-- Name: COLUMN ct_prod_serv_type.modif_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_prod_serv_type.modif_date IS 'Date of the last modification of the record';


--
-- Name: seq_product_type_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_product_type_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_product_type_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_product_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_product_type_id IS 'sequence for field product_type_id in table ct_product_type';


--
-- Name: ct_product_type; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.ct_product_type (
    product_type_id integer DEFAULT nextval('public.seq_product_type_id'::regclass) NOT NULL,
    entity_type_id integer DEFAULT 1000 NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(500) NOT NULL,
    status_id integer DEFAULT 1000 NOT NULL,
    input_date timestamp without time zone DEFAULT (('now'::text)::timestamp(0) with time zone)::timestamp without time zone NOT NULL,
    input_user character varying(10) NOT NULL,
    modif_date timestamp without time zone,
    modif_user character varying(10)
);


ALTER TABLE public.ct_product_type OWNER TO comasw_admin;

--
-- Name: TABLE ct_product_type; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.ct_product_type IS 'Table that stores the product types of the catalog for the application';


--
-- Name: COLUMN ct_product_type.product_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_product_type.product_type_id IS 'Internal identifier of the product type';


--
-- Name: COLUMN ct_product_type.entity_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_product_type.entity_type_id IS 'Entity_id for the product type';


--
-- Name: COLUMN ct_product_type.code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_product_type.code IS 'Code of the product type';


--
-- Name: COLUMN ct_product_type.name; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_product_type.name IS 'Name of the product type';


--
-- Name: COLUMN ct_product_type.description; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_product_type.description IS 'Description for the product type';


--
-- Name: COLUMN ct_product_type.status_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_product_type.status_id IS 'Status id for the product type';


--
-- Name: COLUMN ct_product_type.input_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_product_type.input_date IS 'Date on which the record was created';


--
-- Name: COLUMN ct_product_type.input_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_product_type.input_user IS 'User who was modified the record';


--
-- Name: COLUMN ct_product_type.modif_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_product_type.modif_date IS 'Date of the last modification of the record';


--
-- Name: seq_promo_consum_type_disc_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_promo_consum_type_disc_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_promo_consum_type_disc_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_promo_consum_type_disc_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_promo_consum_type_disc_id IS 'sequence for field promo_consum_type_discount_id in table ct_promo_consum_discount_type';


--
-- Name: ct_promo_consum_type_discount; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.ct_promo_consum_type_discount (
    promo_consum_type_discount_id integer DEFAULT nextval('public.seq_promo_consum_type_disc_id'::regclass) NOT NULL,
    promotion_type_id integer NOT NULL,
    consumption_type_id integer NOT NULL,
    status_id integer DEFAULT 1000 NOT NULL,
    input_date timestamp without time zone DEFAULT (('now'::text)::timestamp(0) with time zone)::timestamp without time zone NOT NULL,
    input_user character varying(10) NOT NULL,
    modif_date timestamp without time zone,
    modif_user character varying(10)
);


ALTER TABLE public.ct_promo_consum_type_discount OWNER TO comasw_admin;

--
-- Name: TABLE ct_promo_consum_type_discount; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.ct_promo_consum_type_discount IS 'Table that stores the promotion fee discount relation types of the catalog for the application';


--
-- Name: COLUMN ct_promo_consum_type_discount.promo_consum_type_discount_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promo_consum_type_discount.promo_consum_type_discount_id IS 'Internal identifier of the promotion-consumption discount relation type';


--
-- Name: COLUMN ct_promo_consum_type_discount.promotion_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promo_consum_type_discount.promotion_type_id IS 'Promotion_type_id for the promotion-consumption discount relation';


--
-- Name: COLUMN ct_promo_consum_type_discount.consumption_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promo_consum_type_discount.consumption_type_id IS 'Consumption_type_id for the promotion-consumption discount relation';


--
-- Name: COLUMN ct_promo_consum_type_discount.status_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promo_consum_type_discount.status_id IS 'Status id for the promotion-consumption discount relation type';


--
-- Name: COLUMN ct_promo_consum_type_discount.input_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promo_consum_type_discount.input_date IS 'Date on which the record was created';


--
-- Name: COLUMN ct_promo_consum_type_discount.input_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promo_consum_type_discount.input_user IS 'User who was modified the record';


--
-- Name: COLUMN ct_promo_consum_type_discount.modif_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promo_consum_type_discount.modif_date IS 'Date of the last modification of the record';


--
-- Name: seq_promo_fee_type_disc_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_promo_fee_type_disc_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_promo_fee_type_disc_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_promo_fee_type_disc_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_promo_fee_type_disc_id IS 'sequence for field promo_fee_type_discount_id in table ct_promo_fee_type_discount';


--
-- Name: ct_promo_fee_type_discount; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.ct_promo_fee_type_discount (
    promo_fee_type_discount_id integer DEFAULT nextval('public.seq_promo_fee_type_disc_id'::regclass) NOT NULL,
    promotion_type_id integer NOT NULL,
    fee_type_id integer NOT NULL,
    application_level_id integer NOT NULL,
    status_id integer DEFAULT 1000 NOT NULL,
    input_date timestamp without time zone DEFAULT (('now'::text)::timestamp(0) with time zone)::timestamp without time zone NOT NULL,
    input_user character varying(10) NOT NULL,
    modif_date timestamp without time zone,
    modif_user character varying(10)
);


ALTER TABLE public.ct_promo_fee_type_discount OWNER TO comasw_admin;

--
-- Name: TABLE ct_promo_fee_type_discount; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.ct_promo_fee_type_discount IS 'Table that stores the promotion fee discount relation types of the catalog for the application';


--
-- Name: COLUMN ct_promo_fee_type_discount.promo_fee_type_discount_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promo_fee_type_discount.promo_fee_type_discount_id IS 'Internal identifier of the promotion-fee discount relation type';


--
-- Name: COLUMN ct_promo_fee_type_discount.promotion_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promo_fee_type_discount.promotion_type_id IS 'Promotion_type_id for the promotion-fee discount relation';


--
-- Name: COLUMN ct_promo_fee_type_discount.fee_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promo_fee_type_discount.fee_type_id IS 'Fee_type_id for the promotion-fee discount relation';


--
-- Name: COLUMN ct_promo_fee_type_discount.application_level_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promo_fee_type_discount.application_level_id IS 'Application_level_id for the promotion-fee discount relation';


--
-- Name: COLUMN ct_promo_fee_type_discount.status_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promo_fee_type_discount.status_id IS 'Status id for the promotion-fee discount relation type';


--
-- Name: COLUMN ct_promo_fee_type_discount.input_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promo_fee_type_discount.input_date IS 'Date on which the record was created';


--
-- Name: COLUMN ct_promo_fee_type_discount.input_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promo_fee_type_discount.input_user IS 'User who was modified the record';


--
-- Name: COLUMN ct_promo_fee_type_discount.modif_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promo_fee_type_discount.modif_date IS 'Date of the last modification of the record';


--
-- Name: seq_promo_prod_type_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_promo_prod_type_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_promo_prod_type_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_promo_prod_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_promo_prod_type_id IS 'sequence for field promo_prod_type_id in table ct_promo_prod_type';


--
-- Name: ct_promo_prod_type; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.ct_promo_prod_type (
    promo_prod_type_id integer DEFAULT nextval('public.seq_promo_prod_type_id'::regclass) NOT NULL,
    promotion_type_id integer NOT NULL,
    product_type_id integer NOT NULL,
    status_id integer DEFAULT 1000 NOT NULL,
    input_date timestamp without time zone DEFAULT (('now'::text)::timestamp(0) with time zone)::timestamp without time zone NOT NULL,
    input_user character varying(10) NOT NULL,
    modif_date timestamp without time zone,
    modif_user character varying(10)
);


ALTER TABLE public.ct_promo_prod_type OWNER TO comasw_admin;

--
-- Name: TABLE ct_promo_prod_type; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.ct_promo_prod_type IS 'Table that stores the promotion product relation types of the catalog for the application';


--
-- Name: COLUMN ct_promo_prod_type.promo_prod_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promo_prod_type.promo_prod_type_id IS 'Internal identifier of the promotion-product relation type';


--
-- Name: COLUMN ct_promo_prod_type.promotion_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promo_prod_type.promotion_type_id IS 'Promotion_type_id for the promotion-product relation';


--
-- Name: COLUMN ct_promo_prod_type.product_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promo_prod_type.product_type_id IS 'Product_type_id for the promotion-product relation';


--
-- Name: COLUMN ct_promo_prod_type.status_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promo_prod_type.status_id IS 'Status id for the promotion-product relation type';


--
-- Name: COLUMN ct_promo_prod_type.input_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promo_prod_type.input_date IS 'Date on which the record was created';


--
-- Name: COLUMN ct_promo_prod_type.input_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promo_prod_type.input_user IS 'User who was modified the record';


--
-- Name: COLUMN ct_promo_prod_type.modif_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promo_prod_type.modif_date IS 'Date of the last modification of the record';


--
-- Name: seq_promo_serv_type_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_promo_serv_type_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_promo_serv_type_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_promo_serv_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_promo_serv_type_id IS 'sequence for field promo_serv_type_id in table ct_promo_serv_type';


--
-- Name: ct_promo_serv_type; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.ct_promo_serv_type (
    promo_serv_type_id integer DEFAULT nextval('public.seq_promo_serv_type_id'::regclass) NOT NULL,
    promotion_type_id integer NOT NULL,
    service_type_id integer NOT NULL,
    status_id integer DEFAULT 1000 NOT NULL,
    input_date timestamp without time zone DEFAULT (('now'::text)::timestamp(0) with time zone)::timestamp without time zone NOT NULL,
    input_user character varying(10) NOT NULL,
    modif_date timestamp without time zone,
    modif_user character varying(10)
);


ALTER TABLE public.ct_promo_serv_type OWNER TO comasw_admin;

--
-- Name: TABLE ct_promo_serv_type; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.ct_promo_serv_type IS 'Table that stores the promotion service relation types of the catalog for the application';


--
-- Name: COLUMN ct_promo_serv_type.promo_serv_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promo_serv_type.promo_serv_type_id IS 'Internal identifier of the promotion-service relation type';


--
-- Name: COLUMN ct_promo_serv_type.promotion_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promo_serv_type.promotion_type_id IS 'Promotion_type_id for the promotion-service relation';


--
-- Name: COLUMN ct_promo_serv_type.service_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promo_serv_type.service_type_id IS 'Service_type_id for the promotion-service relation';


--
-- Name: COLUMN ct_promo_serv_type.status_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promo_serv_type.status_id IS 'Status id for the promotion-service relation type';


--
-- Name: COLUMN ct_promo_serv_type.input_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promo_serv_type.input_date IS 'Date on which the record was created';


--
-- Name: COLUMN ct_promo_serv_type.input_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promo_serv_type.input_user IS 'User who was modified the record';


--
-- Name: COLUMN ct_promo_serv_type.modif_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promo_serv_type.modif_date IS 'Date of the last modification of the record';


--
-- Name: ct_promotion_type; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.ct_promotion_type (
    promotion_type_id integer NOT NULL,
    entity_type_id integer DEFAULT 1002 NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(500) NOT NULL,
    application_level_id integer NOT NULL,
    discount_type_id integer NOT NULL,
    discount_value numeric(10,4) NOT NULL,
    status_id integer DEFAULT 1000 NOT NULL,
    input_date timestamp without time zone DEFAULT (('now'::text)::timestamp(0) with time zone)::timestamp without time zone NOT NULL,
    input_user character varying(10) NOT NULL,
    modif_date timestamp without time zone,
    modif_user character varying(10)
);


ALTER TABLE public.ct_promotion_type OWNER TO comasw_admin;

--
-- Name: COLUMN ct_promotion_type.promotion_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promotion_type.promotion_type_id IS 'Internal identifier of the promotion type';


--
-- Name: COLUMN ct_promotion_type.entity_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promotion_type.entity_type_id IS 'Entity_id for the promotion type';


--
-- Name: COLUMN ct_promotion_type.start_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promotion_type.start_date IS 'Start_date for the promotion type';


--
-- Name: COLUMN ct_promotion_type.end_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promotion_type.end_date IS 'End_date for the promotion type';


--
-- Name: COLUMN ct_promotion_type.code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promotion_type.code IS 'Code of the promotion type';


--
-- Name: COLUMN ct_promotion_type.name; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promotion_type.name IS 'Name of the promotion type';


--
-- Name: COLUMN ct_promotion_type.description; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promotion_type.description IS 'Description for the promotion type';


--
-- Name: COLUMN ct_promotion_type.application_level_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promotion_type.application_level_id IS 'Application level id for the promotion type';


--
-- Name: COLUMN ct_promotion_type.discount_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promotion_type.discount_type_id IS 'Discount Type id for the promotion type';


--
-- Name: COLUMN ct_promotion_type.discount_value; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promotion_type.discount_value IS 'Discount value for the promotion type';


--
-- Name: COLUMN ct_promotion_type.status_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promotion_type.status_id IS 'Status id for the promotion type';


--
-- Name: COLUMN ct_promotion_type.input_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promotion_type.input_date IS 'Date on which the record was created';


--
-- Name: COLUMN ct_promotion_type.input_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promotion_type.input_user IS 'User who was created the record';


--
-- Name: COLUMN ct_promotion_type.modif_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promotion_type.modif_date IS 'Date on which the record was modified (last modified)';


--
-- Name: COLUMN ct_promotion_type.modif_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_promotion_type.modif_user IS 'User who was modified the record';


--
-- Name: seq_serv_fee_type_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_serv_fee_type_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_serv_fee_type_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_serv_fee_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_serv_fee_type_id IS 'sequence for field serv_fee_type_id in table ct_serv_fee_type';


--
-- Name: ct_serv_fee_type; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.ct_serv_fee_type (
    serv_fee_type_id integer DEFAULT nextval('public.seq_serv_fee_type_id'::regclass) NOT NULL,
    service_type_id integer NOT NULL,
    fee_type_id integer NOT NULL,
    status_id integer DEFAULT 1000 NOT NULL,
    input_date timestamp without time zone DEFAULT (('now'::text)::timestamp(0) with time zone)::timestamp without time zone NOT NULL,
    input_user character varying(10) NOT NULL,
    modif_date timestamp without time zone,
    modif_user character varying(10)
);


ALTER TABLE public.ct_serv_fee_type OWNER TO comasw_admin;

--
-- Name: TABLE ct_serv_fee_type; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.ct_serv_fee_type IS 'Table that stores the fee service relation types of the catalog for the application';


--
-- Name: COLUMN ct_serv_fee_type.serv_fee_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_serv_fee_type.serv_fee_type_id IS 'Internal identifier of the service-fee relation type';


--
-- Name: COLUMN ct_serv_fee_type.service_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_serv_fee_type.service_type_id IS 'Product_type_id for the service-fee relation';


--
-- Name: COLUMN ct_serv_fee_type.fee_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_serv_fee_type.fee_type_id IS 'Service_type_id for the service-fee relation';


--
-- Name: COLUMN ct_serv_fee_type.status_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_serv_fee_type.status_id IS 'Status id for the service-fee relation type';


--
-- Name: COLUMN ct_serv_fee_type.input_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_serv_fee_type.input_date IS 'Date on which the record was created';


--
-- Name: COLUMN ct_serv_fee_type.input_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_serv_fee_type.input_user IS 'User who was modified the record';


--
-- Name: COLUMN ct_serv_fee_type.modif_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_serv_fee_type.modif_date IS 'Date of the last modification of the record';


--
-- Name: seq_service_type_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_service_type_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_service_type_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_service_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_service_type_id IS 'sequence for field service_type_id in table ct_service_type';


--
-- Name: ct_service_type; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.ct_service_type (
    service_type_id integer DEFAULT nextval('public.seq_service_type_id'::regclass) NOT NULL,
    entity_type_id integer DEFAULT 1001 NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(500) NOT NULL,
    status_id integer DEFAULT 1000 NOT NULL,
    input_date timestamp without time zone DEFAULT (('now'::text)::timestamp(0) with time zone)::timestamp without time zone NOT NULL,
    input_user character varying(10) NOT NULL,
    modif_date timestamp without time zone,
    modif_user character varying(10)
);


ALTER TABLE public.ct_service_type OWNER TO comasw_admin;

--
-- Name: TABLE ct_service_type; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.ct_service_type IS 'Table that stores the service types of the catalog for the application';


--
-- Name: COLUMN ct_service_type.service_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_service_type.service_type_id IS 'Internal identifier of the service type';


--
-- Name: COLUMN ct_service_type.entity_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_service_type.entity_type_id IS 'Entity_id for the service type';


--
-- Name: COLUMN ct_service_type.code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_service_type.code IS 'Code of the service type';


--
-- Name: COLUMN ct_service_type.name; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_service_type.name IS 'Name of the service type';


--
-- Name: COLUMN ct_service_type.description; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_service_type.description IS 'Description for the service type';


--
-- Name: COLUMN ct_service_type.status_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_service_type.status_id IS 'Status id for the service type';


--
-- Name: COLUMN ct_service_type.input_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_service_type.input_date IS 'Date on which the record was created';


--
-- Name: COLUMN ct_service_type.input_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_service_type.input_user IS 'User who was modified the record';


--
-- Name: COLUMN ct_service_type.modif_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.ct_service_type.modif_date IS 'Date of the last modification of the record';


--
-- Name: seq_account_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_account_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_account_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_account_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_account_id IS 'sequence for field account_id in table it_account';


--
-- Name: idt_account; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.idt_account (
    account_id integer DEFAULT nextval('public.seq_account_id'::regclass) NOT NULL
);


ALTER TABLE public.idt_account OWNER TO comasw_admin;

--
-- Name: TABLE idt_account; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.idt_account IS 'Table that stores the account instance ids referenced by account table';


--
-- Name: COLUMN idt_account.account_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.idt_account.account_id IS 'Internal identifier of the account instance';


--
-- Name: seq_customer_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_customer_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_customer_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_customer_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_customer_id IS 'sequence for field customer_id in table it_customer';


--
-- Name: idt_customer; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.idt_customer (
    customer_id integer DEFAULT nextval('public.seq_customer_id'::regclass) NOT NULL
);


ALTER TABLE public.idt_customer OWNER TO comasw_admin;

--
-- Name: TABLE idt_customer; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.idt_customer IS 'Table that stores the customer instance ids referenced by customer table';


--
-- Name: COLUMN idt_customer.customer_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.idt_customer.customer_id IS 'Internal identifier of the customer instance';


--
-- Name: seq_fee_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_fee_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_fee_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_fee_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_fee_id IS 'sequence for field fee_id in table idt_fee';


--
-- Name: idt_fee; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.idt_fee (
    fee_id integer DEFAULT nextval('public.seq_fee_id'::regclass) NOT NULL
);


ALTER TABLE public.idt_fee OWNER TO comasw_admin;

--
-- Name: TABLE idt_fee; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.idt_fee IS 'Table that stores the fee instance ids';


--
-- Name: COLUMN idt_fee.fee_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.idt_fee.fee_id IS 'Internal identifier of the fee instance';


--
-- Name: seq_fee_type_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_fee_type_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_fee_type_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_fee_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_fee_type_id IS 'sequence for field fee_type_id in table ct_fee_type';


--
-- Name: idt_fee_type; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.idt_fee_type (
    fee_type_id integer DEFAULT nextval('public.seq_fee_type_id'::regclass) NOT NULL
);


ALTER TABLE public.idt_fee_type OWNER TO comasw_admin;

--
-- Name: TABLE idt_fee_type; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.idt_fee_type IS 'Table that stores the fee_type_id for the fee types of the catalog for the application';


--
-- Name: COLUMN idt_fee_type.fee_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.idt_fee_type.fee_type_id IS 'Internal identifier of the fee type';


--
-- Name: seq_product_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_product_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_product_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_product_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_product_id IS 'sequence for field product_id in table it_product';


--
-- Name: idt_product; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.idt_product (
    product_id integer DEFAULT nextval('public.seq_product_id'::regclass) NOT NULL
);


ALTER TABLE public.idt_product OWNER TO comasw_admin;

--
-- Name: TABLE idt_product; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.idt_product IS 'Table that stores the product instance ids referenced by product table';


--
-- Name: COLUMN idt_product.product_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.idt_product.product_id IS 'Internal identifier of the product instance';


--
-- Name: seq_product_fee_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_product_fee_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_product_fee_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_product_fee_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_product_fee_id IS 'sequence for field product_fee_id in table it_product_fee';


--
-- Name: idt_product_fee; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.idt_product_fee (
    product_fee_id integer DEFAULT nextval('public.seq_product_fee_id'::regclass) NOT NULL
);


ALTER TABLE public.idt_product_fee OWNER TO comasw_admin;

--
-- Name: TABLE idt_product_fee; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.idt_product_fee IS 'Table that stores the product-fee instance relation ids referenced by product_fee table';


--
-- Name: COLUMN idt_product_fee.product_fee_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.idt_product_fee.product_fee_id IS 'Internal identifier of the product-fee instance relation';


--
-- Name: seq_product_promotion_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_product_promotion_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_product_promotion_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_product_promotion_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_product_promotion_id IS 'sequence for field product_promotion_id in table it_product_promotion';


--
-- Name: idt_product_promotion; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.idt_product_promotion (
    product_promotion_id integer DEFAULT nextval('public.seq_product_promotion_id'::regclass) NOT NULL
);


ALTER TABLE public.idt_product_promotion OWNER TO comasw_admin;

--
-- Name: TABLE idt_product_promotion; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.idt_product_promotion IS 'Table that stores the product-promotion instance relation ids referenced by product_promotion table';


--
-- Name: COLUMN idt_product_promotion.product_promotion_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.idt_product_promotion.product_promotion_id IS 'Internal identifier of the product-promotion instance relation';


--
-- Name: seq_product_service_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_product_service_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_product_service_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_product_service_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_product_service_id IS 'sequence for field product_service_id in table it_product_service';


--
-- Name: idt_product_service; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.idt_product_service (
    product_service_id integer DEFAULT nextval('public.seq_product_service_id'::regclass) NOT NULL
);


ALTER TABLE public.idt_product_service OWNER TO comasw_admin;

--
-- Name: TABLE idt_product_service; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.idt_product_service IS 'Table that stores the product-service instance relation ids referenced by product_service table';


--
-- Name: COLUMN idt_product_service.product_service_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.idt_product_service.product_service_id IS 'Internal identifier of the product-service instance relation';


--
-- Name: seq_promotion_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_promotion_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_promotion_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_promotion_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_promotion_id IS 'sequence for field promotion_id in table it_promotion';


--
-- Name: idt_promotion; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.idt_promotion (
    promotion_id integer DEFAULT nextval('public.seq_promotion_id'::regclass) NOT NULL
);


ALTER TABLE public.idt_promotion OWNER TO comasw_admin;

--
-- Name: TABLE idt_promotion; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.idt_promotion IS 'Table that stores the promotion instance ids referenced by promotion table';


--
-- Name: COLUMN idt_promotion.promotion_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.idt_promotion.promotion_id IS 'Internal identifier of the promotion instance';


--
-- Name: seq_promotion_type_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_promotion_type_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_promotion_type_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_promotion_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_promotion_type_id IS 'sequence for field promotion_type_id in table ct_promotion_type';


--
-- Name: idt_promotion_type; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.idt_promotion_type (
    promotion_type_id integer DEFAULT nextval('public.seq_promotion_type_id'::regclass) NOT NULL
);


ALTER TABLE public.idt_promotion_type OWNER TO comasw_admin;

--
-- Name: seq_service_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_service_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_service_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_service_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_service_id IS 'sequence for field service_id in table it_service';


--
-- Name: idt_service; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.idt_service (
    service_id integer DEFAULT nextval('public.seq_service_id'::regclass) NOT NULL
);


ALTER TABLE public.idt_service OWNER TO comasw_admin;

--
-- Name: TABLE idt_service; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.idt_service IS 'Table that stores the service instance ids referenced by service table';


--
-- Name: COLUMN idt_service.service_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.idt_service.service_id IS 'Internal identifier of the service instance';


--
-- Name: seq_service_fee_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_service_fee_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_service_fee_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_service_fee_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_service_fee_id IS 'sequence for field service_fee_id in table it_service_fee';


--
-- Name: idt_service_fee; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.idt_service_fee (
    service_fee_id integer DEFAULT nextval('public.seq_service_fee_id'::regclass) NOT NULL
);


ALTER TABLE public.idt_service_fee OWNER TO comasw_admin;

--
-- Name: TABLE idt_service_fee; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.idt_service_fee IS 'Table that stores the service-fee instance relation ids referenced by service_fee table';


--
-- Name: COLUMN idt_service_fee.service_fee_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.idt_service_fee.service_fee_id IS 'Internal identifier of the service-fee instance relation';


--
-- Name: seq_service_promotion_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_service_promotion_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_service_promotion_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_service_promotion_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_service_promotion_id IS 'sequence for field service_promotion_id in table it_service_promotion';


--
-- Name: idt_service_promotion; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.idt_service_promotion (
    service_promotion_id integer DEFAULT nextval('public.seq_service_promotion_id'::regclass) NOT NULL
);


ALTER TABLE public.idt_service_promotion OWNER TO comasw_admin;

--
-- Name: TABLE idt_service_promotion; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.idt_service_promotion IS 'Table that stores the service-promotion instance relation ids referenced by service_promotion table';


--
-- Name: COLUMN idt_service_promotion.service_promotion_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.idt_service_promotion.service_promotion_id IS 'Internal identifier of the service-promotion instance relation';


--
-- Name: it_account; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.it_account (
    account_id integer NOT NULL,
    account_type_id integer NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    code character varying(10) NOT NULL,
    customer_id integer NOT NULL,
    contract_number character varying(10) NOT NULL,
    status_id integer NOT NULL,
    given_name character varying(50) NOT NULL,
    first_surname character varying(50) NOT NULL,
    second_surname character varying(50) NOT NULL,
    identity_card_type_id integer NOT NULL,
    identity_card character varying(10) NOT NULL,
    contact_phone character varying(13),
    e_mail character varying(50),
    address character varying(100) NOT NULL,
    city character varying(100) NOT NULL,
    state character varying(100) NOT NULL,
    country character varying(100) NOT NULL,
    post_code character varying(5) NOT NULL,
    iban character varying(4),
    bank_entity character varying(4),
    bank_branch character varying(4),
    bank_control_digit character varying(2),
    bank_account_number character varying(10),
    active_date timestamp without time zone,
    cancelled_date timestamp without time zone,
    input_date timestamp without time zone DEFAULT (('now'::text)::timestamp(0) with time zone)::timestamp without time zone NOT NULL,
    input_user character varying(10) NOT NULL,
    modif_date timestamp without time zone,
    modif_user character varying(10)
);


ALTER TABLE public.it_account OWNER TO comasw_admin;

--
-- Name: TABLE it_account; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.it_account IS 'Table that stores the account instance data';


--
-- Name: COLUMN it_account.account_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_account.account_id IS 'Internal identifier of the account instance';


--
-- Name: COLUMN it_account.account_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_account.account_type_id IS 'Internal identifier of the account type associates to this account instance';


--
-- Name: COLUMN it_account.start_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_account.start_date IS 'Start_date of the record';


--
-- Name: COLUMN it_account.end_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_account.end_date IS 'End date of the record';


--
-- Name: COLUMN it_account.code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_account.code IS 'Internal identifier of the account type associates to this account instance';


--
-- Name: COLUMN it_account.contract_number; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_account.contract_number IS 'Contract number associates to this account instance';


--
-- Name: COLUMN it_account.status_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_account.status_id IS 'Status_id of the account';


--
-- Name: COLUMN it_account.given_name; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_account.given_name IS 'Given name of the account';


--
-- Name: COLUMN it_account.first_surname; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_account.first_surname IS 'First surname of the account';


--
-- Name: COLUMN it_account.second_surname; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_account.second_surname IS 'Second surname of the account';


--
-- Name: COLUMN it_account.identity_card_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_account.identity_card_type_id IS 'Type id of the identit card number of the account';


--
-- Name: COLUMN it_account.identity_card; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_account.identity_card IS 'Identit card number of the account';


--
-- Name: COLUMN it_account.contact_phone; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_account.contact_phone IS 'Contact phone of the account';


--
-- Name: COLUMN it_account.e_mail; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_account.e_mail IS 'E-mail contact of the account';


--
-- Name: COLUMN it_account.address; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_account.address IS 'Addres of the account (street, bloc, floor, etc.)';


--
-- Name: COLUMN it_account.city; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_account.city IS 'City of the account';


--
-- Name: COLUMN it_account.state; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_account.state IS 'State of the account';


--
-- Name: COLUMN it_account.country; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_account.country IS 'Country of the account';


--
-- Name: COLUMN it_account.post_code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_account.post_code IS 'Post code of the account';


--
-- Name: COLUMN it_account.iban; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_account.iban IS 'IBAN of the account''s bank_account';


--
-- Name: COLUMN it_account.bank_entity; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_account.bank_entity IS 'Bank entity of the account''s bank_account';


--
-- Name: COLUMN it_account.bank_branch; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_account.bank_branch IS 'Bank branch of the account''s bank_account';


--
-- Name: COLUMN it_account.bank_control_digit; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_account.bank_control_digit IS 'Control digit of the account''s bank_account';


--
-- Name: COLUMN it_account.bank_account_number; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_account.bank_account_number IS 'Bank account number of the account''s bank_account';


--
-- Name: COLUMN it_account.active_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_account.active_date IS 'Date of the activation for account in the system';


--
-- Name: COLUMN it_account.cancelled_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_account.cancelled_date IS 'Date of the cancellation for account in the system';


--
-- Name: COLUMN it_account.input_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_account.input_date IS 'Date on which the record was created';


--
-- Name: COLUMN it_account.input_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_account.input_user IS 'User who was created the record';


--
-- Name: COLUMN it_account.modif_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_account.modif_date IS 'Date of the last modification of the record';


--
-- Name: COLUMN it_account.modif_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_account.modif_user IS 'User who was modified the record';


--
-- Name: seq_contract_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_contract_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_contract_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_contract_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_contract_id IS 'sequence for field contract_id in table it_contract';


--
-- Name: it_contract; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.it_contract (
    contract_id integer DEFAULT nextval('public.seq_contract_id'::regclass) NOT NULL,
    contract_number character varying(10),
    send_date date,
    signed_date timestamp without time zone,
    actived_date timestamp without time zone,
    input_date timestamp without time zone DEFAULT (('now'::text)::timestamp(0) with time zone)::timestamp without time zone NOT NULL,
    input_user character varying(10) NOT NULL,
    modif_date timestamp without time zone,
    modif_user character varying(10)
);


ALTER TABLE public.it_contract OWNER TO comasw_admin;

--
-- Name: TABLE it_contract; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.it_contract IS 'Table that stores the contract instance data';


--
-- Name: COLUMN it_contract.contract_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_contract.contract_id IS 'Internal identifier of the contract instance';


--
-- Name: COLUMN it_contract.contract_number; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_contract.contract_number IS 'Contract number of the contract_id';


--
-- Name: COLUMN it_contract.send_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_contract.send_date IS 'Send date of the contract';


--
-- Name: COLUMN it_contract.signed_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_contract.signed_date IS 'Signed date of the contract';


--
-- Name: COLUMN it_contract.actived_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_contract.actived_date IS 'Actived date of the contract';


--
-- Name: COLUMN it_contract.input_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_contract.input_date IS 'Date on which the record was created';


--
-- Name: COLUMN it_contract.input_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_contract.input_user IS 'User who was created the record';


--
-- Name: COLUMN it_contract.modif_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_contract.modif_date IS 'Date of the last modification of the record';


--
-- Name: COLUMN it_contract.modif_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_contract.modif_user IS 'User who was modified the record';


--
-- Name: it_customer; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.it_customer (
    customer_id integer NOT NULL,
    customer_type_id integer NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    status_id integer NOT NULL,
    given_name character varying(50) NOT NULL,
    first_surname character varying(50) NOT NULL,
    second_surname character varying(50),
    identity_card_type_id integer NOT NULL,
    identity_card character varying(10) NOT NULL,
    contact_phone character varying(13),
    e_mail character varying(50),
    address character varying(100) NOT NULL,
    city character varying(100) NOT NULL,
    state character varying(100) NOT NULL,
    country character varying(100) NOT NULL,
    post_code character varying(5) NOT NULL,
    iban character varying(4),
    bank_entity character varying(4),
    bank_branch character varying(4),
    bank_control_digit character varying(2),
    bank_account_number character varying(10),
    active_date timestamp without time zone,
    cancelled_date timestamp without time zone,
    input_date timestamp without time zone DEFAULT (('now'::text)::timestamp(0) with time zone)::timestamp without time zone NOT NULL,
    input_user character varying(10) NOT NULL,
    modif_date timestamp without time zone,
    modif_user character varying(10)
);


ALTER TABLE public.it_customer OWNER TO comasw_admin;

--
-- Name: TABLE it_customer; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.it_customer IS 'Table that stores the customer instance data';


--
-- Name: COLUMN it_customer.customer_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_customer.customer_id IS 'Internal identifier of the customer instance';


--
-- Name: COLUMN it_customer.customer_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_customer.customer_type_id IS 'Internal identifier of the customer type associates to this customer instance';


--
-- Name: COLUMN it_customer.start_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_customer.start_date IS 'Start_date of the record';


--
-- Name: COLUMN it_customer.end_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_customer.end_date IS 'End date of the record';


--
-- Name: COLUMN it_customer.status_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_customer.status_id IS 'Status_id of the customer';


--
-- Name: COLUMN it_customer.given_name; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_customer.given_name IS 'Given name of the customer';


--
-- Name: COLUMN it_customer.first_surname; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_customer.first_surname IS 'First surname of the customer';


--
-- Name: COLUMN it_customer.second_surname; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_customer.second_surname IS 'Second surname of the customer';


--
-- Name: COLUMN it_customer.identity_card_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_customer.identity_card_type_id IS 'Type id of the identit card number of the customer';


--
-- Name: COLUMN it_customer.identity_card; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_customer.identity_card IS 'Identity card number of the customer';


--
-- Name: COLUMN it_customer.contact_phone; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_customer.contact_phone IS 'Contact phone of the customer';


--
-- Name: COLUMN it_customer.e_mail; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_customer.e_mail IS 'E-mail contact of the customer';


--
-- Name: COLUMN it_customer.address; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_customer.address IS 'Addres of the customer (street, bloc, floor, etc.)';


--
-- Name: COLUMN it_customer.city; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_customer.city IS 'City of the customer';


--
-- Name: COLUMN it_customer.state; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_customer.state IS 'State of the customer';


--
-- Name: COLUMN it_customer.country; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_customer.country IS 'Country of the customer';


--
-- Name: COLUMN it_customer.post_code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_customer.post_code IS 'Post code of the customer';


--
-- Name: COLUMN it_customer.iban; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_customer.iban IS 'IBAN of the customer''s bank_account';


--
-- Name: COLUMN it_customer.bank_entity; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_customer.bank_entity IS 'Bank entity of the customer''s bank_account';


--
-- Name: COLUMN it_customer.bank_branch; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_customer.bank_branch IS 'Bank branch of the customer''s bank_account';


--
-- Name: COLUMN it_customer.bank_control_digit; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_customer.bank_control_digit IS 'Control digit of the customer''s bank_account';


--
-- Name: COLUMN it_customer.bank_account_number; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_customer.bank_account_number IS 'Bank account number of the customer''s bank_account';


--
-- Name: COLUMN it_customer.active_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_customer.active_date IS 'Date of the activation for customer in the system';


--
-- Name: COLUMN it_customer.cancelled_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_customer.cancelled_date IS 'Date of the cancellation for customer in the system';


--
-- Name: COLUMN it_customer.input_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_customer.input_date IS 'Date on which the record was created';


--
-- Name: COLUMN it_customer.input_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_customer.input_user IS 'User who was created the record';


--
-- Name: COLUMN it_customer.modif_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_customer.modif_date IS 'Date of the last modification of the record';


--
-- Name: COLUMN it_customer.modif_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_customer.modif_user IS 'User who was modified the record';


--
-- Name: it_fee; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.it_fee (
    fee_id integer NOT NULL,
    fee_type_id integer NOT NULL,
    parent_instance_id integer NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    code character varying(10),
    application_level_id integer,
    prorate boolean,
    price numeric(10,4),
    status_id integer NOT NULL,
    active_date timestamp without time zone,
    cancelled_date timestamp without time zone,
    input_date timestamp without time zone DEFAULT (('now'::text)::timestamp(0) with time zone)::timestamp without time zone NOT NULL,
    input_user character varying(10) NOT NULL,
    modif_date timestamp without time zone,
    modif_user character varying(10)
);


ALTER TABLE public.it_fee OWNER TO comasw_admin;

--
-- Name: TABLE it_fee; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.it_fee IS 'Table that stores the fee instance data';


--
-- Name: COLUMN it_fee.fee_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_fee.fee_id IS 'Internal identifier of the fee instance';


--
-- Name: COLUMN it_fee.fee_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_fee.fee_type_id IS 'Internal identifier of the fee type associates to this fee instance';


--
-- Name: COLUMN it_fee.parent_instance_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_fee.parent_instance_id IS 'Internal identifier of the product id associates to this fee instance';


--
-- Name: COLUMN it_fee.start_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_fee.start_date IS 'Start_date of the record';


--
-- Name: COLUMN it_fee.end_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_fee.end_date IS 'End date of the record';


--
-- Name: COLUMN it_fee.code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_fee.code IS 'Code associates to this fee instance';


--
-- Name: COLUMN it_fee.application_level_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_fee.application_level_id IS 'Application level associates to this fee instance';


--
-- Name: COLUMN it_fee.prorate; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_fee.prorate IS 'Flag that indicates if fee is prorated (true) or not (false) at the period ';


--
-- Name: COLUMN it_fee.price; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_fee.price IS 'Price for the fee at this period';


--
-- Name: COLUMN it_fee.status_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_fee.status_id IS 'Status of the fee at this period';


--
-- Name: COLUMN it_fee.active_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_fee.active_date IS 'Date of the activation for fee in the system';


--
-- Name: COLUMN it_fee.cancelled_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_fee.cancelled_date IS 'Date of the cancellation for fee in the system';


--
-- Name: COLUMN it_fee.input_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_fee.input_date IS 'Date on which the record was created';


--
-- Name: COLUMN it_fee.input_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_fee.input_user IS 'User who was created the record';


--
-- Name: COLUMN it_fee.modif_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_fee.modif_date IS 'Date of the last modification of the record';


--
-- Name: COLUMN it_fee.modif_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_fee.modif_user IS 'User who was modified the record';


--
-- Name: it_product; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.it_product (
    product_id integer NOT NULL,
    product_type_id integer NOT NULL,
    account_id integer NOT NULL,
    code character varying(10) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    status_id integer NOT NULL,
    active_date timestamp without time zone,
    cancelled_date timestamp without time zone,
    input_date timestamp without time zone DEFAULT (('now'::text)::timestamp(0) with time zone)::timestamp without time zone NOT NULL,
    input_user character varying(10) NOT NULL,
    modif_date timestamp without time zone,
    modif_user character varying(10)
);


ALTER TABLE public.it_product OWNER TO comasw_admin;

--
-- Name: TABLE it_product; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.it_product IS 'Table that stores the product instance data';


--
-- Name: COLUMN it_product.product_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_product.product_id IS 'Internal identifier of the product instance';


--
-- Name: COLUMN it_product.product_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_product.product_type_id IS 'Internal identifier of the product type associates to this product instance';


--
-- Name: COLUMN it_product.account_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_product.account_id IS 'Internal identifier of the account id associates to this product instance';


--
-- Name: COLUMN it_product.code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_product.code IS 'Code associates to this product instance';


--
-- Name: COLUMN it_product.start_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_product.start_date IS 'Start_date of the record';


--
-- Name: COLUMN it_product.end_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_product.end_date IS 'End date of the record';


--
-- Name: COLUMN it_product.active_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_product.active_date IS 'Date of the activation for product in the system';


--
-- Name: COLUMN it_product.cancelled_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_product.cancelled_date IS 'Date of the cancellation for product in the system';


--
-- Name: COLUMN it_product.input_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_product.input_date IS 'Date on which the record was created';


--
-- Name: COLUMN it_product.input_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_product.input_user IS 'User who was created the record';


--
-- Name: COLUMN it_product.modif_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_product.modif_date IS 'Date of the last modification of the record';


--
-- Name: COLUMN it_product.modif_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_product.modif_user IS 'User who was modified the record';


--
-- Name: seq_profile_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_profile_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_profile_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_profile_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_profile_id IS 'sequence for field profile_id in table it_profiles';


--
-- Name: it_profiles; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.it_profiles (
    profile_id integer DEFAULT nextval('public.seq_profile_id'::regclass) NOT NULL,
    profile_code character varying(10) NOT NULL,
    description character varying(500) NOT NULL
);


ALTER TABLE public.it_profiles OWNER TO comasw_admin;

--
-- Name: TABLE it_profiles; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.it_profiles IS 'Table that stores application profiles';


--
-- Name: COLUMN it_profiles.profile_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_profiles.profile_id IS 'InternaL identifier of the profile';


--
-- Name: COLUMN it_profiles.profile_code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_profiles.profile_code IS 'Code of the profile';


--
-- Name: COLUMN it_profiles.description; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_profiles.description IS 'Description for the profile';


--
-- Name: it_promotion; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.it_promotion (
    promotion_id integer NOT NULL,
    promotion_type_id integer NOT NULL,
    parent_instance_id integer NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    code character varying(10),
    application_level_id integer,
    discount_type_id integer,
    discount_value numeric(10,4),
    status_id integer NOT NULL,
    active_date timestamp without time zone,
    cancelled_date timestamp without time zone,
    input_date timestamp without time zone DEFAULT (('now'::text)::timestamp(0) with time zone)::timestamp without time zone NOT NULL,
    input_user character varying(10) NOT NULL,
    modif_date timestamp without time zone,
    modif_user character varying(10)
);


ALTER TABLE public.it_promotion OWNER TO comasw_admin;

--
-- Name: TABLE it_promotion; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.it_promotion IS 'Table that stores the promotion instance data';


--
-- Name: COLUMN it_promotion.promotion_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_promotion.promotion_id IS 'Internal identifier of the promotion instance';


--
-- Name: COLUMN it_promotion.promotion_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_promotion.promotion_type_id IS 'Internal identifier of the promotion type associates to this promotion instance';


--
-- Name: COLUMN it_promotion.parent_instance_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_promotion.parent_instance_id IS 'Internal identifier of the product id associates to this promotion instance';


--
-- Name: COLUMN it_promotion.start_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_promotion.start_date IS 'Start_date of the record';


--
-- Name: COLUMN it_promotion.end_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_promotion.end_date IS 'End date of the record';


--
-- Name: COLUMN it_promotion.code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_promotion.code IS 'Code associates to this promotion instance';


--
-- Name: COLUMN it_promotion.application_level_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_promotion.application_level_id IS 'Application level associates to this promotion instance';


--
-- Name: COLUMN it_promotion.discount_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_promotion.discount_type_id IS 'Discount type for the promotion ';


--
-- Name: COLUMN it_promotion.discount_value; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_promotion.discount_value IS 'Discount value for the promotion at this period';


--
-- Name: COLUMN it_promotion.status_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_promotion.status_id IS 'Status of the promotion at this period';


--
-- Name: COLUMN it_promotion.active_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_promotion.active_date IS 'Date of the activation for promotion in the system';


--
-- Name: COLUMN it_promotion.cancelled_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_promotion.cancelled_date IS 'Date of the cancellation for promotion in the system';


--
-- Name: COLUMN it_promotion.input_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_promotion.input_date IS 'Date on which the record was created';


--
-- Name: COLUMN it_promotion.input_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_promotion.input_user IS 'User who was created the record';


--
-- Name: COLUMN it_promotion.modif_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_promotion.modif_date IS 'Date of the last modification of the record';


--
-- Name: COLUMN it_promotion.modif_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_promotion.modif_user IS 'User who was modified the record';


--
-- Name: it_service; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.it_service (
    service_id integer NOT NULL,
    service_type_id integer NOT NULL,
    product_id integer NOT NULL,
    code character varying(10),
    service_number character varying(100) NOT NULL,
    general_1 character varying(100),
    general_2 character varying(100),
    general_3 character varying(100),
    start_date date NOT NULL,
    end_date date NOT NULL,
    status_id integer NOT NULL,
    active_date timestamp without time zone,
    cancelled_date timestamp without time zone,
    input_date timestamp without time zone DEFAULT (('now'::text)::timestamp(0) with time zone)::timestamp without time zone NOT NULL,
    input_user character varying(10) NOT NULL,
    modif_date timestamp without time zone,
    modif_user character varying(10)
);


ALTER TABLE public.it_service OWNER TO comasw_admin;

--
-- Name: TABLE it_service; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.it_service IS 'Table that stores the service instance data';


--
-- Name: COLUMN it_service.service_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_service.service_id IS 'Internal identifier of the service instance';


--
-- Name: COLUMN it_service.service_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_service.service_type_id IS 'Internal identifier of the service type associates to this service instance';


--
-- Name: COLUMN it_service.product_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_service.product_id IS 'Internal identifier of the product id associates to this service instance';


--
-- Name: COLUMN it_service.code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_service.code IS 'Code associates to this service instance';


--
-- Name: COLUMN it_service.service_number; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_service.service_number IS 'Code number associates to this service instance (e.g. telephon number)';


--
-- Name: COLUMN it_service.general_1; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_service.general_1 IS 'General information field for the service to extends information about it';


--
-- Name: COLUMN it_service.general_2; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_service.general_2 IS 'General information field for the service to extends information about it';


--
-- Name: COLUMN it_service.general_3; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_service.general_3 IS 'General information field for the service to extends information about it';


--
-- Name: COLUMN it_service.start_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_service.start_date IS 'Start_date of the record';


--
-- Name: COLUMN it_service.end_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_service.end_date IS 'End date of the record';


--
-- Name: COLUMN it_service.active_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_service.active_date IS 'Date of the activation for service in the system';


--
-- Name: COLUMN it_service.cancelled_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_service.cancelled_date IS 'Date of the cancellation for service in the system';


--
-- Name: COLUMN it_service.input_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_service.input_date IS 'Date on which the record was created';


--
-- Name: COLUMN it_service.input_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_service.input_user IS 'User who was created the record';


--
-- Name: COLUMN it_service.modif_date; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_service.modif_date IS 'Date of the last modification of the record';


--
-- Name: COLUMN it_service.modif_user; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_service.modif_user IS 'User who was modified the record';


--
-- Name: seq_user_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_user_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_user_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_user_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_user_id IS 'sequence for field user_id in table it_users';


--
-- Name: it_users; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.it_users (
    user_id integer DEFAULT nextval('public.seq_user_id'::regclass) NOT NULL,
    name character varying(50) NOT NULL,
    surname character varying(100) NOT NULL,
    email character varying(50) NOT NULL,
    phone_contact character varying(50),
    user_code character varying(10) NOT NULL,
    password character(32) NOT NULL,
    profile_id integer NOT NULL,
    active boolean NOT NULL
);


ALTER TABLE public.it_users OWNER TO comasw_admin;

--
-- Name: TABLE it_users; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.it_users IS 'Table that stores application users';


--
-- Name: COLUMN it_users.user_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_users.user_id IS 'InternaL identifier of the user';


--
-- Name: COLUMN it_users.name; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_users.name IS 'Name of the user';


--
-- Name: COLUMN it_users.surname; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_users.surname IS 'Surname of the user';


--
-- Name: COLUMN it_users.email; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_users.email IS 'Email of the user';


--
-- Name: COLUMN it_users.phone_contact; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_users.phone_contact IS 'Phone contact of the user';


--
-- Name: COLUMN it_users.user_code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_users.user_code IS 'Code of the user (to login)';


--
-- Name: COLUMN it_users.password; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_users.password IS 'Password for the user - md5 encrypted';


--
-- Name: COLUMN it_users.profile_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.it_users.profile_id IS 'Internal identifier for the profile of the user';


--
-- Name: seq_application_menu_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_application_menu_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_application_menu_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_application_menu_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_application_menu_id IS 'sequence for field product_type_id in table mt_application_menu';


--
-- Name: mt_application_menu; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.mt_application_menu (
    application_menu_id integer DEFAULT nextval('public.seq_application_menu_id'::regclass) NOT NULL,
    application_parent_menu_id integer,
    has_children boolean NOT NULL,
    menu_level integer NOT NULL,
    "position" integer NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(500) NOT NULL,
    profile_code character varying(50),
    page character varying(500) NOT NULL
);


ALTER TABLE public.mt_application_menu OWNER TO comasw_admin;

--
-- Name: TABLE mt_application_menu; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.mt_application_menu IS 'Table that stores the application''s menu';


--
-- Name: COLUMN mt_application_menu.application_menu_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.mt_application_menu.application_menu_id IS 'Internal identifier of the menu item';


--
-- Name: COLUMN mt_application_menu.application_parent_menu_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.mt_application_menu.application_parent_menu_id IS 'Internal identifier of the parent menu item, if exists';


--
-- Name: COLUMN mt_application_menu.has_children; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.mt_application_menu.has_children IS 'Flag that indicates if the item menu has children (true or false)';


--
-- Name: COLUMN mt_application_menu.menu_level; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.mt_application_menu.menu_level IS 'Level of the menu item in the menu hierarchy';


--
-- Name: COLUMN mt_application_menu."position"; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.mt_application_menu."position" IS 'Position of the menu item in the menu level';


--
-- Name: COLUMN mt_application_menu.name; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.mt_application_menu.name IS 'Name to shown in the menu application';


--
-- Name: COLUMN mt_application_menu.description; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.mt_application_menu.description IS 'Description of the menu item';


--
-- Name: COLUMN mt_application_menu.profile_code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.mt_application_menu.profile_code IS 'Profiles authoriced to see the menu item';


--
-- Name: COLUMN mt_application_menu.page; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.mt_application_menu.page IS 'JSF to redirect when the menu item is selected';


--
-- Name: seq_application_level_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_application_level_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_application_level_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_application_level_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_application_level_id IS 'sequence for field application_level_id in table pt_application_level';


--
-- Name: pt_application_level; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.pt_application_level (
    application_level_id integer DEFAULT nextval('public.seq_application_level_id'::regclass) NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(500) NOT NULL
);


ALTER TABLE public.pt_application_level OWNER TO comasw_admin;

--
-- Name: TABLE pt_application_level; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.pt_application_level IS 'Table that stores the application level for the application';


--
-- Name: COLUMN pt_application_level.application_level_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_application_level.application_level_id IS 'Internal identifier of the application level';


--
-- Name: COLUMN pt_application_level.code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_application_level.code IS 'Code of the application level';


--
-- Name: COLUMN pt_application_level.name; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_application_level.name IS 'Name of the application level';


--
-- Name: COLUMN pt_application_level.description; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_application_level.description IS 'Description for the application level';


--
-- Name: seq_billing_period_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_billing_period_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_billing_period_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_billing_period_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_billing_period_id IS 'sequence for field billing_period_id in table pt_billing_period';


--
-- Name: pt_billing_period; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.pt_billing_period (
    billing_period_id integer DEFAULT nextval('public.seq_billing_period_id'::regclass) NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(500) NOT NULL,
    billing_period_days numeric(3,0) NOT NULL
);


ALTER TABLE public.pt_billing_period OWNER TO comasw_admin;

--
-- Name: TABLE pt_billing_period; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.pt_billing_period IS 'Table that stores the billing period types for the application';


--
-- Name: COLUMN pt_billing_period.billing_period_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_billing_period.billing_period_id IS 'Internal identifier of the billing period type';


--
-- Name: COLUMN pt_billing_period.code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_billing_period.code IS 'Code of the billing period type';


--
-- Name: COLUMN pt_billing_period.name; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_billing_period.name IS 'Name of the billing period type';


--
-- Name: COLUMN pt_billing_period.description; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_billing_period.description IS 'Description for the billing period type';


--
-- Name: COLUMN pt_billing_period.billing_period_days; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_billing_period.billing_period_days IS 'Number of days that defines the billing period';


--
-- Name: seq_consumption_class_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_consumption_class_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_consumption_class_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_consumption_class_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_consumption_class_id IS 'sequence for field consumption_class_id in table pt_consumption_class';


--
-- Name: pt_consumption_class; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.pt_consumption_class (
    consumption_class_id integer DEFAULT nextval('public.seq_consumption_class_id'::regclass) NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(500) NOT NULL
);


ALTER TABLE public.pt_consumption_class OWNER TO comasw_admin;

--
-- Name: TABLE pt_consumption_class; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.pt_consumption_class IS 'Table that stores the consumtion class of the application';


--
-- Name: COLUMN pt_consumption_class.consumption_class_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_consumption_class.consumption_class_id IS 'Internal identifier of the consumption class';


--
-- Name: COLUMN pt_consumption_class.code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_consumption_class.code IS 'Code of the consumption class';


--
-- Name: COLUMN pt_consumption_class.name; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_consumption_class.name IS 'Name of the consumption class';


--
-- Name: COLUMN pt_consumption_class.description; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_consumption_class.description IS 'Description for the consumption class';


--
-- Name: seq_discount_type_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_discount_type_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_discount_type_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_discount_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_discount_type_id IS 'sequence for field discount_type_id in table pt_discount_type';


--
-- Name: pt_discount_type; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.pt_discount_type (
    discount_type_id integer DEFAULT nextval('public.seq_discount_type_id'::regclass) NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(500) NOT NULL
);


ALTER TABLE public.pt_discount_type OWNER TO comasw_admin;

--
-- Name: TABLE pt_discount_type; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.pt_discount_type IS 'Table that stores the discount types for the application';


--
-- Name: COLUMN pt_discount_type.discount_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_discount_type.discount_type_id IS 'Internal identifier of the discount type';


--
-- Name: COLUMN pt_discount_type.code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_discount_type.code IS 'Code of the discount type';


--
-- Name: COLUMN pt_discount_type.name; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_discount_type.name IS 'Name of the discount type';


--
-- Name: COLUMN pt_discount_type.description; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_discount_type.description IS 'Description for the discount type';


--
-- Name: seq_entity_type_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_entity_type_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_entity_type_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_entity_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_entity_type_id IS 'sequence for field entity_type_id in table pt_entity_type';


--
-- Name: pt_entity_type; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.pt_entity_type (
    entity_type_id integer DEFAULT nextval('public.seq_entity_type_id'::regclass) NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(500) NOT NULL
);


ALTER TABLE public.pt_entity_type OWNER TO comasw_admin;

--
-- Name: TABLE pt_entity_type; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.pt_entity_type IS 'Table that stores the entity type of the application';


--
-- Name: COLUMN pt_entity_type.entity_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_entity_type.entity_type_id IS 'Internal identifier of the entity type';


--
-- Name: COLUMN pt_entity_type.code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_entity_type.code IS 'Code of the entity type';


--
-- Name: COLUMN pt_entity_type.name; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_entity_type.name IS 'Name of the entity type';


--
-- Name: COLUMN pt_entity_type.description; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_entity_type.description IS 'Description for the entity type';


--
-- Name: seq_identity_card_type_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_identity_card_type_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_identity_card_type_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_identity_card_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_identity_card_type_id IS 'sequence for field identity_card_type_id in table identity_card_type';


--
-- Name: pt_identity_card_type; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.pt_identity_card_type (
    identity_card_type_id integer DEFAULT nextval('public.seq_identity_card_type_id'::regclass) NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(500) NOT NULL
);


ALTER TABLE public.pt_identity_card_type OWNER TO comasw_admin;

--
-- Name: TABLE pt_identity_card_type; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.pt_identity_card_type IS 'Table that stores the posible types of the the identity card';


--
-- Name: COLUMN pt_identity_card_type.identity_card_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_identity_card_type.identity_card_type_id IS 'Internal identifier of the identity card type';


--
-- Name: COLUMN pt_identity_card_type.code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_identity_card_type.code IS 'Code of the identity card type';


--
-- Name: COLUMN pt_identity_card_type.name; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_identity_card_type.name IS 'Name of the identity card type';


--
-- Name: COLUMN pt_identity_card_type.description; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_identity_card_type.description IS 'Description of the identity card type';


--
-- Name: seq_payment_method_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_payment_method_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_payment_method_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_payment_method_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_payment_method_id IS 'sequence for field payment_type_id in table pt_payment_method';


--
-- Name: pt_payment_method; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.pt_payment_method (
    payment_method_id integer DEFAULT nextval('public.seq_payment_method_id'::regclass) NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(500) NOT NULL
);


ALTER TABLE public.pt_payment_method OWNER TO comasw_admin;

--
-- Name: TABLE pt_payment_method; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.pt_payment_method IS 'Table that stores the payment types for the application';


--
-- Name: COLUMN pt_payment_method.payment_method_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_payment_method.payment_method_id IS 'Internal identifier of the payment method';


--
-- Name: COLUMN pt_payment_method.code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_payment_method.code IS 'Code of the payment method';


--
-- Name: COLUMN pt_payment_method.name; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_payment_method.name IS 'Name of the payment method';


--
-- Name: COLUMN pt_payment_method.description; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_payment_method.description IS 'Description for the payment method';


--
-- Name: seq_status_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_status_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_status_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_status_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_status_id IS 'sequence for field status_id in table pt_status';


--
-- Name: pt_status; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.pt_status (
    status_id integer DEFAULT nextval('public.seq_status_id'::regclass) NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(500) NOT NULL,
    catalog boolean NOT NULL,
    instance boolean NOT NULL
);


ALTER TABLE public.pt_status OWNER TO comasw_admin;

--
-- Name: TABLE pt_status; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.pt_status IS 'Table that stores the status for the entities of the application';


--
-- Name: COLUMN pt_status.status_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_status.status_id IS 'Internal identifier of the status';


--
-- Name: COLUMN pt_status.code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_status.code IS 'Code of the status';


--
-- Name: COLUMN pt_status.name; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_status.name IS 'Name of the status';


--
-- Name: COLUMN pt_status.description; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_status.description IS 'Description for the status';


--
-- Name: COLUMN pt_status.catalog; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_status.catalog IS 'Indicates if the status applies to catalog entities';


--
-- Name: COLUMN pt_status.instance; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_status.instance IS 'Indicates if the status applies to instance entities';


--
-- Name: seq_tax_type_id; Type: SEQUENCE; Schema: public; Owner: comasw_admin
--

CREATE SEQUENCE public.seq_tax_type_id
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_tax_type_id OWNER TO comasw_admin;

--
-- Name: SEQUENCE seq_tax_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON SEQUENCE public.seq_tax_type_id IS 'sequence for field tax_type_id in table pt_tax_type';


--
-- Name: pt_tax_type; Type: TABLE; Schema: public; Owner: comasw_admin
--

CREATE TABLE public.pt_tax_type (
    tax_type_id integer DEFAULT nextval('public.seq_tax_type_id'::regclass) NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(500) NOT NULL,
    percent_value numeric(10,4) NOT NULL
);


ALTER TABLE public.pt_tax_type OWNER TO comasw_admin;

--
-- Name: TABLE pt_tax_type; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON TABLE public.pt_tax_type IS 'Table that stores the tax type of the application';


--
-- Name: COLUMN pt_tax_type.tax_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_tax_type.tax_type_id IS 'Internal identifier of the tax type';


--
-- Name: COLUMN pt_tax_type.code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_tax_type.code IS 'Code of the tax type';


--
-- Name: COLUMN pt_tax_type.name; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_tax_type.name IS 'Name of the tax type';


--
-- Name: COLUMN pt_tax_type.description; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_tax_type.description IS 'Description for the tax type';


--
-- Name: COLUMN pt_tax_type.percent_value; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.pt_tax_type.percent_value IS 'Percent value for the tax type';


--
-- Name: vw_customer_instance; Type: VIEW; Schema: public; Owner: comasw_admin
--

CREATE VIEW public.vw_customer_instance AS
 SELECT c.customer_id,
    c.start_date AS customer_start_date,
    c.end_date AS customer_end_date,
    c.customer_type_id,
    ct.code AS customer_type_code,
    ct.name AS customer_type_name,
    ct.description AS customer_type_description,
    c.status_id AS customer_status_id,
    s.code AS customer_status_code,
    c.given_name AS customer_given_name,
    c.first_surname AS customer_first_surname,
    c.second_surname AS customer_second_surname,
    c.identity_card_type_id AS customer_identity_card_type_id,
    ic.code AS customer_identity_card_type_code,
    c.identity_card AS customer_identity_card,
    c.contact_phone AS customer_contact_phone,
    c.e_mail AS customer_e_mail,
    c.address AS customer_address,
    c.city AS customer_city,
    c.state AS customer_state,
    c.country AS customer_country,
    c.post_code AS customer_post_code,
    c.iban AS customer_iban,
    c.bank_entity AS customer_bank_entity,
    c.bank_branch AS customer_bank_branch,
    c.bank_control_digit AS customer_bank_control_digit,
    c.bank_account_number AS customer_bank_account_number,
    c.active_date AS customer_active_date,
    c.cancelled_date AS customer_cancelled_date
   FROM (((public.it_customer c
     JOIN public.ct_customer_type ct ON ((c.customer_type_id = ct.customer_type_id)))
     JOIN public.pt_status s ON ((c.status_id = s.status_id)))
     JOIN public.pt_identity_card_type ic ON ((c.identity_card_type_id = ic.identity_card_type_id)));


ALTER TABLE public.vw_customer_instance OWNER TO comasw_admin;

--
-- Name: vw_account_instance; Type: VIEW; Schema: public; Owner: comasw_admin
--

CREATE VIEW public.vw_account_instance AS
 WITH bill_cycle AS (
         SELECT bct.bill_cycle_type_id,
            bct.code AS bill_cycle_code,
            bct.name AS bill_cycle_name,
            bct.description AS bill_cycle_description,
            bct.billing_period_id,
            bct.bill_cycle_day,
            bct.bill_cycle_codenum,
            bp.code AS billing_period_code,
            bp.name AS billing_period_name,
            bp.description AS billing_period_description,
            bp.billing_period_days,
            bct.status_id AS bill_cycle_status_id,
            s_1.code AS bill_cycle_status_code
           FROM ((public.ct_bill_cycle_type bct
             JOIN public.pt_billing_period bp ON ((bct.billing_period_id = bp.billing_period_id)))
             JOIN public.pt_status s_1 ON ((bct.status_id = s_1.status_id)))
        )
 SELECT a.account_id,
    a.start_date AS account_start_date,
    a.end_date AS account_end_date,
    a.code AS account_code,
    a.account_type_id,
    at.code AS account_type_code,
    a.status_id AS account_status_id,
    s.code AS account_status_code,
    ic.contract_id,
    a.contract_number,
    ic.send_date AS contract_send_date,
    ic.signed_date AS contract_signed_date,
    ic.actived_date AS contract_actived_date,
    a.given_name AS account_given_name,
    a.first_surname AS account_first_surname,
    a.second_surname AS account_second_surname,
    a.identity_card_type_id AS account_identity_card_type_id,
    at.code AS account_identity_card_type_code,
    a.identity_card AS account_identity_card,
    a.contact_phone AS account_contact_phone,
    a.e_mail AS account_e_mail,
    a.address AS account_address,
    a.city AS account_city,
    a.state AS account_state,
    a.country AS account_country,
    a.post_code AS account_post_code,
    a.iban AS account_iban,
    a.bank_entity AS account_bank_entity,
    a.bank_branch AS account_bank_branch,
    a.bank_control_digit AS account_bank_control_digit,
    a.bank_account_number AS account_bank_account_number,
    a.active_date AS account_active_date,
    a.cancelled_date AS account_cancelled_date,
    pm.code AS payment_code,
    pm.name AS payment_name,
    pm.description AS payment_description,
    at.ordinary_bill_cycle_type_id,
    obc.bill_cycle_code AS ordinary_bill_cycle_code,
    obc.bill_cycle_codenum AS ordinary_bill_cycle_codenum,
    obc.billing_period_code AS ordinary_bill_cycle_period_code,
    obc.billing_period_days AS ordinary_bill_cycle_period_days,
    cbc.bill_cycle_code AS corrective_bill_cycle_code,
    cbc.bill_cycle_codenum AS corrective_bill_cycle_codenum,
    cbc.billing_period_code AS corrective_bill_cycle_period_code,
    cbc.billing_period_days AS corrective_bill_cycle_period_days,
    c.customer_id,
    c.customer_start_date,
    c.customer_end_date,
    c.customer_type_id,
    c.customer_type_code,
    c.customer_type_name,
    c.customer_type_description,
    c.customer_status_id,
    c.customer_status_code,
    c.customer_given_name,
    c.customer_first_surname,
    c.customer_second_surname,
    c.customer_identity_card_type_id,
    c.customer_identity_card_type_code,
    c.customer_identity_card,
    c.customer_contact_phone,
    c.customer_e_mail,
    c.customer_address,
    c.customer_city,
    c.customer_state,
    c.customer_country,
    c.customer_post_code,
    c.customer_iban,
    c.customer_bank_entity,
    c.customer_bank_branch,
    c.customer_bank_control_digit,
    c.customer_bank_account_number,
    c.customer_active_date,
    c.customer_cancelled_date
   FROM (((((((public.it_account a
     JOIN public.vw_customer_instance c ON (((c.customer_id = a.customer_id) AND ((a.start_date, a.end_date) OVERLAPS (c.customer_start_date, c.customer_end_date)))))
     JOIN public.ct_account_type at ON ((at.account_type_id = a.account_type_id)))
     JOIN bill_cycle obc ON ((at.ordinary_bill_cycle_type_id = obc.bill_cycle_type_id)))
     JOIN bill_cycle cbc ON ((at.corrective_bill_cycle_type_id = cbc.bill_cycle_type_id)))
     JOIN public.pt_payment_method pm ON ((pm.payment_method_id = at.payment_method_id)))
     JOIN public.pt_status s ON ((s.status_id = a.status_id)))
     JOIN public.it_contract ic ON (((a.contract_number)::text = (ic.contract_number)::text)));


ALTER TABLE public.vw_account_instance OWNER TO comasw_admin;

--
-- Name: vw_product_instance; Type: VIEW; Schema: public; Owner: comasw_admin
--

CREATE VIEW public.vw_product_instance AS
 SELECT p.product_id,
    p.code AS product_code,
    p.product_type_id,
    pt.code AS product_type_code,
    pt.name AS product_type_name,
    pt.description AS product_type_description,
    p.status_id AS product_status_id,
    s.code AS product_status_code,
    p.start_date AS product_start_date,
    p.end_date AS product_end_date,
    p.active_date AS product_active_date,
    p.cancelled_date AS product_cancelled_date,
    av.account_id,
    av.account_type_id,
    av.account_start_date,
    av.account_end_date,
    av.account_code,
    av.account_type_code,
    av.account_status_id,
    av.account_status_code,
    av.contract_id,
    av.contract_number,
    av.contract_send_date,
    av.contract_signed_date,
    av.contract_actived_date,
    av.account_given_name,
    av.account_first_surname,
    av.account_second_surname,
    av.account_identity_card_type_id,
    av.account_identity_card_type_code,
    av.account_identity_card,
    av.account_contact_phone,
    av.account_e_mail,
    av.account_address,
    av.account_city,
    av.account_state,
    av.account_country,
    av.account_post_code,
    av.account_iban,
    av.account_bank_entity,
    av.account_bank_branch,
    av.account_bank_control_digit,
    av.account_bank_account_number,
    av.account_active_date,
    av.account_cancelled_date,
    av.payment_code,
    av.ordinary_bill_cycle_type_id,
    av.ordinary_bill_cycle_code,
    av.ordinary_bill_cycle_codenum,
    av.ordinary_bill_cycle_period_code,
    av.ordinary_bill_cycle_period_days,
    av.corrective_bill_cycle_code,
    av.corrective_bill_cycle_codenum,
    av.corrective_bill_cycle_period_code,
    av.corrective_bill_cycle_period_days,
    av.customer_id,
    av.customer_type_id,
    av.customer_start_date,
    av.customer_end_date,
    av.customer_type_code,
    av.customer_status_id,
    av.customer_status_code,
    av.customer_given_name,
    av.customer_first_surname,
    av.customer_second_surname,
    av.customer_identity_card_type_id,
    av.customer_identity_card_type_code,
    av.customer_identity_card,
    av.customer_contact_phone,
    av.customer_e_mail,
    av.customer_address,
    av.customer_city,
    av.customer_state,
    av.customer_country,
    av.customer_post_code,
    av.customer_iban,
    av.customer_bank_entity,
    av.customer_bank_branch,
    av.customer_bank_control_digit,
    av.customer_bank_account_number,
    av.customer_active_date,
    av.customer_cancelled_date
   FROM (((public.it_product p
     JOIN public.ct_product_type pt ON ((p.product_type_id = pt.product_type_id)))
     JOIN public.pt_status s ON ((p.status_id = s.status_id)))
     JOIN public.vw_account_instance av ON (((p.account_id = av.account_id) AND ((p.start_date, p.end_date) OVERLAPS (av.account_start_date, av.account_end_date)) AND ((p.start_date, p.end_date) OVERLAPS (av.customer_start_date, av.customer_end_date)))));


ALTER TABLE public.vw_product_instance OWNER TO comasw_admin;

--
-- Name: vw_service_instance; Type: VIEW; Schema: public; Owner: comasw_admin
--

CREATE VIEW public.vw_service_instance AS
 SELECT sv.service_id,
    sv.code AS service_code,
    sv.service_type_id,
    pt.code AS service_type_code,
    pt.name AS service_type_name,
    pt.description AS service_type_description,
    sv.status_id AS service_status_id,
    s.code AS service_status_code,
    sv.service_number,
    sv.general_1 AS service_general_1,
    sv.general_2 AS service_general_2,
    sv.general_3 AS service_general_3,
    sv.start_date AS service_start_date,
    sv.end_date AS service_end_date,
    sv.active_date AS service_active_date,
    sv.cancelled_date AS service_cancelled_date,
    pv.product_id,
    pv.product_code,
    pv.product_type_id,
    pv.product_type_code,
    pv.product_type_name,
    pv.product_type_description,
    pv.product_status_id,
    pv.product_status_code,
    pv.product_start_date,
    pv.product_end_date,
    pv.product_active_date,
    pv.product_cancelled_date,
    pv.account_id,
    pv.account_type_id,
    pv.account_start_date,
    pv.account_end_date,
    pv.account_code,
    pv.account_type_code,
    pv.account_status_id,
    pv.account_status_code,
    pv.contract_id,
    pv.contract_number,
    pv.contract_send_date,
    pv.contract_signed_date,
    pv.contract_actived_date,
    pv.account_given_name,
    pv.account_first_surname,
    pv.account_second_surname,
    pv.account_identity_card_type_id,
    pv.account_identity_card_type_code,
    pv.account_identity_card,
    pv.account_contact_phone,
    pv.account_e_mail,
    pv.account_address,
    pv.account_city,
    pv.account_state,
    pv.account_country,
    pv.account_post_code,
    pv.account_iban,
    pv.account_bank_entity,
    pv.account_bank_branch,
    pv.account_bank_control_digit,
    pv.account_bank_account_number,
    pv.account_active_date,
    pv.account_cancelled_date,
    pv.payment_code,
    pv.ordinary_bill_cycle_type_id,
    pv.ordinary_bill_cycle_code,
    pv.ordinary_bill_cycle_codenum,
    pv.ordinary_bill_cycle_period_code,
    pv.ordinary_bill_cycle_period_days,
    pv.corrective_bill_cycle_code,
    pv.corrective_bill_cycle_codenum,
    pv.corrective_bill_cycle_period_code,
    pv.corrective_bill_cycle_period_days,
    pv.customer_id,
    pv.customer_type_id,
    pv.customer_start_date,
    pv.customer_end_date,
    pv.customer_type_code,
    pv.customer_status_id,
    pv.customer_status_code,
    pv.customer_given_name,
    pv.customer_first_surname,
    pv.customer_second_surname,
    pv.customer_identity_card_type_id,
    pv.customer_identity_card_type_code,
    pv.customer_identity_card,
    pv.customer_contact_phone,
    pv.customer_e_mail,
    pv.customer_address,
    pv.customer_city,
    pv.customer_state,
    pv.customer_country,
    pv.customer_post_code,
    pv.customer_iban,
    pv.customer_bank_entity,
    pv.customer_bank_branch,
    pv.customer_bank_control_digit,
    pv.customer_bank_account_number,
    pv.customer_active_date,
    pv.customer_cancelled_date
   FROM (((public.it_service sv
     JOIN public.ct_service_type pt ON ((sv.service_type_id = pt.service_type_id)))
     JOIN public.pt_status s ON ((sv.status_id = s.status_id)))
     JOIN public.vw_product_instance pv ON (((sv.product_id = pv.product_id) AND ((sv.start_date, sv.end_date) OVERLAPS (pv.product_start_date, pv.product_end_date)) AND ((sv.start_date, sv.end_date) OVERLAPS (pv.account_start_date, pv.account_end_date)) AND ((sv.start_date, sv.end_date) OVERLAPS (pv.customer_start_date, pv.customer_end_date)))));


ALTER TABLE public.vw_service_instance OWNER TO comasw_admin;

--
-- Name: vw_fee_instance; Type: VIEW; Schema: public; Owner: comasw_admin
--

CREATE VIEW public.vw_fee_instance AS
 SELECT p.fee_id,
    p.parent_instance_id,
    p.start_date AS fee_start_date,
    p.end_date AS fee_end_date,
    p.fee_type_id,
    p.code AS fee_code,
    pt.code AS fee_type_code,
    pt.name AS fee_type_name,
    pt.description AS fee_type_description,
    pt.status_id AS fee_status_id,
    s.code AS fee_status_code,
    p.application_level_id,
    al.code AS application_level_code,
    al.name AS application_level_name,
    al.description AS application_level_description,
    p.prorate,
    p.price,
    p.active_date AS fee_active_date,
    p.cancelled_date AS fee_cancelled_date,
    NULL::integer AS service_id,
    NULL::character varying AS service_code,
    NULL::character varying AS service_number,
    NULL::character varying AS service_general_1,
    NULL::character varying AS service_general_2,
    NULL::character varying AS service_general_3,
    NULL::integer AS service_type_id,
    NULL::character varying AS service_type_code,
    NULL::character varying AS service_type_name,
    NULL::character varying AS service_type_description,
    NULL::integer AS service_status_id,
    NULL::character varying AS service_status_code,
    NULL::date AS service_start_date,
    NULL::date AS service_end_date,
    NULL::timestamp without time zone AS service_active_date,
    NULL::timestamp without time zone AS service_cancelled_date,
    v.product_id,
    v.product_code,
    v.product_type_id,
    v.product_type_code,
    v.product_type_name,
    v.product_type_description,
    v.product_status_id,
    v.product_status_code,
    v.product_start_date,
    v.product_end_date,
    v.product_active_date,
    v.product_cancelled_date,
    v.account_id,
    v.account_type_id,
    v.account_start_date,
    v.account_end_date,
    v.account_code,
    v.account_type_code,
    v.account_status_id,
    v.account_status_code,
    v.contract_id,
    v.contract_number,
    v.contract_send_date,
    v.contract_signed_date,
    v.contract_actived_date,
    v.account_given_name,
    v.account_first_surname,
    v.account_second_surname,
    v.account_identity_card_type_id,
    v.account_identity_card_type_code,
    v.account_identity_card,
    v.account_contact_phone,
    v.account_e_mail,
    v.account_address,
    v.account_city,
    v.account_state,
    v.account_country,
    v.account_post_code,
    v.account_iban,
    v.account_bank_entity,
    v.account_bank_branch,
    v.account_bank_control_digit,
    v.account_bank_account_number,
    v.account_active_date,
    v.account_cancelled_date,
    v.payment_code,
    v.ordinary_bill_cycle_type_id,
    v.ordinary_bill_cycle_code,
    v.ordinary_bill_cycle_codenum,
    v.ordinary_bill_cycle_period_code,
    v.ordinary_bill_cycle_period_days,
    v.corrective_bill_cycle_code,
    v.corrective_bill_cycle_codenum,
    v.corrective_bill_cycle_period_code,
    v.corrective_bill_cycle_period_days,
    v.customer_id,
    v.customer_type_id,
    v.customer_start_date,
    v.customer_end_date,
    v.customer_type_code,
    v.customer_status_id,
    v.customer_status_code,
    v.customer_given_name,
    v.customer_first_surname,
    v.customer_second_surname,
    v.customer_identity_card_type_id,
    v.customer_identity_card_type_code,
    v.customer_identity_card,
    v.customer_contact_phone,
    v.customer_e_mail,
    v.customer_address,
    v.customer_city,
    v.customer_state,
    v.customer_country,
    v.customer_post_code,
    v.customer_iban,
    v.customer_bank_entity,
    v.customer_bank_branch,
    v.customer_bank_control_digit,
    v.customer_bank_account_number,
    v.customer_active_date,
    v.customer_cancelled_date
   FROM ((((public.it_fee p
     JOIN public.ct_fee_type pt ON (((p.fee_type_id = pt.fee_type_id) AND (p.application_level_id = pt.application_level_id))))
     JOIN public.pt_application_level al ON ((p.application_level_id = al.application_level_id)))
     JOIN public.pt_status s ON ((p.status_id = s.status_id)))
     JOIN public.vw_product_instance v ON (((v.product_id = p.parent_instance_id) AND ((p.start_date, p.end_date) OVERLAPS (v.product_start_date, v.product_end_date)) AND ((p.start_date, p.end_date) OVERLAPS (v.account_start_date, v.account_end_date)) AND ((p.start_date, p.end_date) OVERLAPS (v.customer_start_date, v.customer_end_date)))))
  WHERE ((al.code)::text = 'PROD'::text)
UNION
 SELECT p.fee_id,
    p.parent_instance_id,
    p.start_date AS fee_start_date,
    p.end_date AS fee_end_date,
    p.fee_type_id,
    p.code AS fee_code,
    pt.code AS fee_type_code,
    pt.name AS fee_type_name,
    pt.description AS fee_type_description,
    pt.status_id AS fee_status_id,
    s.code AS fee_status_code,
    p.application_level_id,
    al.code AS application_level_code,
    al.name AS application_level_name,
    al.description AS application_level_description,
    p.prorate,
    p.price,
    p.active_date AS fee_active_date,
    p.cancelled_date AS fee_cancelled_date,
    v.service_id,
    v.service_code,
    v.service_number,
    v.service_general_1,
    v.service_general_2,
    v.service_general_3,
    v.service_type_id,
    v.service_type_code,
    v.service_type_name,
    v.service_type_description,
    v.service_status_id,
    v.service_status_code,
    v.service_start_date,
    v.service_end_date,
    v.service_active_date,
    v.service_cancelled_date,
    v.product_id,
    v.product_code,
    v.product_type_id,
    v.product_type_code,
    v.product_type_name,
    v.product_type_description,
    v.product_status_id,
    v.product_status_code,
    v.product_start_date,
    v.product_end_date,
    v.product_active_date,
    v.product_cancelled_date,
    v.account_id,
    v.account_type_id,
    v.account_start_date,
    v.account_end_date,
    v.account_code,
    v.account_type_code,
    v.account_status_id,
    v.account_status_code,
    v.contract_id,
    v.contract_number,
    v.contract_send_date,
    v.contract_signed_date,
    v.contract_actived_date,
    v.account_given_name,
    v.account_first_surname,
    v.account_second_surname,
    v.account_identity_card_type_id,
    v.account_identity_card_type_code,
    v.account_identity_card,
    v.account_contact_phone,
    v.account_e_mail,
    v.account_address,
    v.account_city,
    v.account_state,
    v.account_country,
    v.account_post_code,
    v.account_iban,
    v.account_bank_entity,
    v.account_bank_branch,
    v.account_bank_control_digit,
    v.account_bank_account_number,
    v.account_active_date,
    v.account_cancelled_date,
    v.payment_code,
    v.ordinary_bill_cycle_type_id,
    v.ordinary_bill_cycle_code,
    v.ordinary_bill_cycle_codenum,
    v.ordinary_bill_cycle_period_code,
    v.ordinary_bill_cycle_period_days,
    v.corrective_bill_cycle_code,
    v.corrective_bill_cycle_codenum,
    v.corrective_bill_cycle_period_code,
    v.corrective_bill_cycle_period_days,
    v.customer_id,
    v.customer_type_id,
    v.customer_start_date,
    v.customer_end_date,
    v.customer_type_code,
    v.customer_status_id,
    v.customer_status_code,
    v.customer_given_name,
    v.customer_first_surname,
    v.customer_second_surname,
    v.customer_identity_card_type_id,
    v.customer_identity_card_type_code,
    v.customer_identity_card,
    v.customer_contact_phone,
    v.customer_e_mail,
    v.customer_address,
    v.customer_city,
    v.customer_state,
    v.customer_country,
    v.customer_post_code,
    v.customer_iban,
    v.customer_bank_entity,
    v.customer_bank_branch,
    v.customer_bank_control_digit,
    v.customer_bank_account_number,
    v.customer_active_date,
    v.customer_cancelled_date
   FROM ((((public.it_fee p
     JOIN public.ct_fee_type pt ON (((p.fee_type_id = pt.fee_type_id) AND (p.application_level_id = pt.application_level_id))))
     JOIN public.pt_application_level al ON ((p.application_level_id = al.application_level_id)))
     JOIN public.pt_status s ON ((p.status_id = s.status_id)))
     JOIN public.vw_service_instance v ON (((v.service_id = p.parent_instance_id) AND ((p.start_date, p.end_date) OVERLAPS (v.service_start_date, v.service_end_date)) AND ((p.start_date, p.end_date) OVERLAPS (v.product_start_date, v.product_end_date)) AND ((p.start_date, p.end_date) OVERLAPS (v.account_start_date, v.account_end_date)) AND ((p.start_date, p.end_date) OVERLAPS (v.customer_start_date, v.customer_end_date)))))
  WHERE ((al.code)::text = 'SERV'::text);


ALTER TABLE public.vw_fee_instance OWNER TO comasw_admin;

--
-- Name: vw_product_fee_type; Type: VIEW; Schema: public; Owner: comasw_admin
--

CREATE VIEW public.vw_product_fee_type AS
 SELECT cpft.prod_fee_type_id,
    cpft.status_id AS prod_fee_type_status_id,
    psr.code AS prod_fee_type_status_code,
    cpt.product_type_id,
    cpt.code AS product_type_code,
    cpt.name AS product_type_name,
    cpt.description AS product_type_description,
    cpt.status_id AS product_type_status_id,
    psp.code AS product_type_status_code,
    cft.fee_type_id,
    cft.start_date AS fee_type_start_date,
    cft.end_date AS fee_type_end_date,
    cft.code AS fee_type_code,
    cft.name AS fee_type_name,
    cft.description AS fee_type_description,
    cft.prorate,
    cft.price,
    cft.status_id AS fee_type_status_id,
    psf.code AS fee_type_status_code
   FROM (((((public.ct_product_type cpt
     JOIN public.pt_status psp ON ((cpt.status_id = psp.status_id)))
     JOIN public.ct_prod_fee_type cpft ON ((cpt.product_type_id = cpft.product_type_id)))
     JOIN public.pt_status psr ON ((cpft.status_id = psr.status_id)))
     JOIN public.ct_fee_type cft ON ((cft.fee_type_id = cpft.fee_type_id)))
     JOIN public.pt_status psf ON ((cpft.status_id = psf.status_id)));


ALTER TABLE public.vw_product_fee_type OWNER TO comasw_admin;

--
-- Name: vw_product_service_type; Type: VIEW; Schema: public; Owner: comasw_admin
--

CREATE VIEW public.vw_product_service_type AS
 SELECT cpst.prod_serv_type_id,
    cpst.status_id AS prod_serv_type_status_id,
    psr.code AS prod_serv_type_status_code,
    cpt.product_type_id,
    cpt.code AS product_type_code,
    cpt.name AS product_type_name,
    cpt.description AS product_type_description,
    cpt.status_id AS product_type_status_id,
    psp.code AS product_type_status_code,
    cst.service_type_id,
    cst.code AS service_type_code,
    cst.name AS service_type_name,
    cst.description AS service_type_description,
    cst.status_id AS service_type_status_id,
    pss.code AS service_type_status_code
   FROM (((((public.ct_product_type cpt
     JOIN public.pt_status psp ON ((cpt.status_id = psp.status_id)))
     JOIN public.ct_prod_serv_type cpst ON ((cpt.product_type_id = cpst.product_type_id)))
     JOIN public.pt_status psr ON ((cpst.status_id = psr.status_id)))
     JOIN public.ct_service_type cst ON ((cst.service_type_id = cpst.service_type_id)))
     JOIN public.pt_status pss ON ((cst.status_id = pss.status_id)));


ALTER TABLE public.vw_product_service_type OWNER TO comasw_admin;

--
-- Name: VIEW vw_product_service_type; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON VIEW public.vw_product_service_type IS 'View showing the relationship between product types and the service types associated with them - related to ct_prod_serv_type';


--
-- Name: COLUMN vw_product_service_type.prod_serv_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.vw_product_service_type.prod_serv_type_id IS 'prod_serv_type_id identifier of the product-service type relation (field prod_serv_type_id from ct_prod_serv_type table)';


--
-- Name: COLUMN vw_product_service_type.prod_serv_type_status_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.vw_product_service_type.prod_serv_type_status_id IS 'Status id of the product-service type relation (field status_id from ct_prod_serv_type table)';


--
-- Name: COLUMN vw_product_service_type.prod_serv_type_status_code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.vw_product_service_type.prod_serv_type_status_code IS 'Status code of the product-service type relation';


--
-- Name: COLUMN vw_product_service_type.product_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.vw_product_service_type.product_type_id IS 'Product_type_id for the product-service type relation (field product_type_id from ct_product_type table)';


--
-- Name: COLUMN vw_product_service_type.product_type_code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.vw_product_service_type.product_type_code IS 'Code for the product type (field code from ct_product_type table)';


--
-- Name: COLUMN vw_product_service_type.product_type_name; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.vw_product_service_type.product_type_name IS 'Name for the product type (field name from ct_product_type table)';


--
-- Name: COLUMN vw_product_service_type.product_type_description; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.vw_product_service_type.product_type_description IS 'Description for the product type (field description from ct_product_type table)';


--
-- Name: COLUMN vw_product_service_type.product_type_status_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.vw_product_service_type.product_type_status_id IS 'Status_id for the product type (field status_id from ct_product_type table)';


--
-- Name: COLUMN vw_product_service_type.product_type_status_code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.vw_product_service_type.product_type_status_code IS 'Status code for the product_type';


--
-- Name: COLUMN vw_product_service_type.service_type_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.vw_product_service_type.service_type_id IS 'Service_type_id for the product-service type relation (field service_type_id from ct_service_type table)';


--
-- Name: COLUMN vw_product_service_type.service_type_code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.vw_product_service_type.service_type_code IS 'Code for the service type (field code from ct_service_type table)';


--
-- Name: COLUMN vw_product_service_type.service_type_name; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.vw_product_service_type.service_type_name IS 'Name for the service type (field name from ct_service_type table)';


--
-- Name: COLUMN vw_product_service_type.service_type_description; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.vw_product_service_type.service_type_description IS 'Description for the service type (field description from ct_service_type table)';


--
-- Name: COLUMN vw_product_service_type.service_type_status_id; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.vw_product_service_type.service_type_status_id IS 'Status_id for the service type (field status_id from ct_service_type table)';


--
-- Name: COLUMN vw_product_service_type.service_type_status_code; Type: COMMENT; Schema: public; Owner: comasw_admin
--

COMMENT ON COLUMN public.vw_product_service_type.service_type_status_code IS 'Status code for the service type';


--
-- Name: vw_promo_consum_type_discount; Type: VIEW; Schema: public; Owner: comasw_admin
--

CREATE VIEW public.vw_promo_consum_type_discount AS
 SELECT cpctd.promo_consum_type_discount_id,
    cpctd.status_id AS promo_consum_type_disc_status_id,
    psr.code AS promo_consum_type_disc_status_code,
    cpctd.promotion_type_id,
    cpt.start_date AS promotion_type_start_date,
    cpt.end_date AS promotion_type_end_date,
    cpt.code AS promotion_type_code,
    cpt.name AS promotion_type_name,
    cpt.description AS promotion_type_description,
    cpt.discount_type_id,
    pdt.code AS discount_type_code,
    pdt.name AS discount_type_name,
    pdt.description AS discount_type_description,
    cpt.discount_value AS promotion_type_discount_value,
    cpt.status_id AS promotion_type_status_id,
    psp.code AS promotion_type_status_code,
    cpctd.consumption_type_id,
    cct.code AS consumption_type_code,
    cct.name AS consumption_type_name,
    cct.description AS consumption_type_description,
    cct.consumption_class_id,
    pcc.code AS consumption_class_code,
    pcc.name AS consumption_class_name,
    pcc.description AS consumption_class_description,
    cct.status_id AS consumption_type_status_id,
    psc.code AS consumption_type_status_code
   FROM (((((((public.ct_promotion_type cpt
     JOIN public.pt_status psp ON ((psp.status_id = cpt.status_id)))
     JOIN public.ct_promo_consum_type_discount cpctd ON ((cpt.promotion_type_id = cpctd.promotion_type_id)))
     JOIN public.pt_status psr ON ((cpctd.status_id = psr.status_id)))
     JOIN public.pt_discount_type pdt ON ((pdt.discount_type_id = cpt.discount_type_id)))
     JOIN public.ct_consumption_type cct ON ((cct.consumption_type_id = cpctd.consumption_type_id)))
     JOIN public.pt_consumption_class pcc ON ((pcc.consumption_class_id = cct.consumption_class_id)))
     JOIN public.pt_status psc ON ((psc.status_id = cct.status_id)))
  WHERE (cpt.application_level_id IN ( SELECT pal2.application_level_id
           FROM public.pt_application_level pal2
          WHERE ((pal2.code)::text = 'SERV'::text)));


ALTER TABLE public.vw_promo_consum_type_discount OWNER TO comasw_admin;

--
-- Name: vw_promotion_fee_type_discount; Type: VIEW; Schema: public; Owner: comasw_admin
--

CREATE VIEW public.vw_promotion_fee_type_discount AS
 SELECT cpfdt.promo_fee_type_discount_id,
    cpfdt.status_id AS promo_fee_type_disc_status_id,
    psr.code AS promo_fee_type_disc_status_code,
    cpt.promotion_type_id,
    cpt.start_date AS promotion_type_start_date,
    cpt.end_date AS promotion_type_end_date,
    cpt.code AS promotion_type_code,
    cpt.name AS promotion_type_name,
    cpt.description AS promotion_type_description,
    cpt.application_level_id,
    pal.code AS application_level_code,
    cpt.discount_type_id,
    pdt.code AS discount_type_code,
    pdt.name AS discount_type_name,
    pdt.description AS discount_type_description,
    pal.description AS application_level_description,
    cpt.discount_value AS promotion_type_discount_value,
    cpt.status_id AS promotion_type_status_id,
    psp.code AS promotion_type_status_code,
    cft.fee_type_id,
    cft.start_date AS fee_type_start_date,
    cft.end_date AS fee_type_end_date,
    cft.code AS fee_type_code,
    cft.name AS fee_type_name,
    cft.description AS fee_type_description,
    cft.prorate,
    cft.price,
    cft.status_id AS fee_type_status_id,
    psf.code AS fee_type_status_code
   FROM (((((((public.ct_promotion_type cpt
     JOIN public.pt_status psp ON ((cpt.status_id = psp.status_id)))
     JOIN public.pt_application_level pal ON ((cpt.application_level_id = pal.application_level_id)))
     JOIN public.pt_discount_type pdt ON ((pdt.discount_type_id = cpt.discount_type_id)))
     JOIN public.ct_promo_fee_type_discount cpfdt ON ((cpt.promotion_type_id = cpfdt.promotion_type_id)))
     JOIN public.pt_status psr ON (((cpfdt.status_id = psr.status_id) AND (cpt.application_level_id = cpfdt.application_level_id))))
     JOIN public.ct_fee_type cft ON (((cft.fee_type_id = cpfdt.fee_type_id) AND (cft.application_level_id = cpfdt.application_level_id) AND ((cpt.start_date <= cft.end_date) AND (cpt.end_date >= cft.start_date)))))
     JOIN public.pt_status psf ON ((cft.status_id = psf.status_id)));


ALTER TABLE public.vw_promotion_fee_type_discount OWNER TO comasw_admin;

--
-- Name: vw_promotion_instance; Type: VIEW; Schema: public; Owner: comasw_admin
--

CREATE VIEW public.vw_promotion_instance AS
 SELECT p.promotion_id,
    p.parent_instance_id,
    p.start_date AS promotion_start_date,
    p.end_date AS promotion_end_date,
    p.promotion_type_id,
    p.code AS promotion_code,
    pt.code AS promotion_type_code,
    pt.name AS promotion_type_name,
    pt.description AS promotion_type_description,
    pt.status_id AS promotion_status_id,
    s.code AS promotion_status_code,
    p.application_level_id,
    al.code AS application_level_code,
    al.name AS application_level_name,
    al.description AS application_level_description,
    p.discount_type_id,
    dt.code AS discount_type_code,
    dt.name AS discount_type_name,
    dt.description AS discount_type_description,
    p.discount_value,
    p.active_date AS promotion_active_date,
    p.cancelled_date AS promotion_cancelled_date,
    NULL::integer AS service_id,
    NULL::character varying AS service_code,
    NULL::character varying AS service_number,
    NULL::character varying AS service_general_1,
    NULL::character varying AS service_general_2,
    NULL::character varying AS service_general_3,
    NULL::integer AS service_type_id,
    NULL::character varying AS service_type_code,
    NULL::character varying AS service_type_name,
    NULL::character varying AS service_type_description,
    NULL::integer AS service_status_id,
    NULL::character varying AS service_status_code,
    NULL::date AS service_start_date,
    NULL::date AS service_end_date,
    NULL::timestamp without time zone AS service_active_date,
    NULL::timestamp without time zone AS service_cancelled_date,
    v.product_id,
    v.product_code,
    v.product_type_id,
    v.product_type_code,
    v.product_type_name,
    v.product_type_description,
    v.product_status_id,
    v.product_status_code,
    v.product_start_date,
    v.product_end_date,
    v.product_active_date,
    v.product_cancelled_date,
    v.account_id,
    v.account_type_id,
    v.account_start_date,
    v.account_end_date,
    v.account_code,
    v.account_type_code,
    v.account_status_id,
    v.account_status_code,
    v.contract_id,
    v.contract_number,
    v.contract_send_date,
    v.contract_signed_date,
    v.contract_actived_date,
    v.account_given_name,
    v.account_first_surname,
    v.account_second_surname,
    v.account_identity_card_type_id,
    v.account_identity_card_type_code,
    v.account_identity_card,
    v.account_contact_phone,
    v.account_e_mail,
    v.account_address,
    v.account_city,
    v.account_state,
    v.account_country,
    v.account_post_code,
    v.account_iban,
    v.account_bank_entity,
    v.account_bank_branch,
    v.account_bank_control_digit,
    v.account_bank_account_number,
    v.account_active_date,
    v.account_cancelled_date,
    v.payment_code,
    v.ordinary_bill_cycle_type_id,
    v.ordinary_bill_cycle_code,
    v.ordinary_bill_cycle_codenum,
    v.ordinary_bill_cycle_period_code,
    v.ordinary_bill_cycle_period_days,
    v.corrective_bill_cycle_code,
    v.corrective_bill_cycle_codenum,
    v.corrective_bill_cycle_period_code,
    v.corrective_bill_cycle_period_days,
    v.customer_id,
    v.customer_type_id,
    v.customer_start_date,
    v.customer_end_date,
    v.customer_type_code,
    v.customer_status_id,
    v.customer_status_code,
    v.customer_given_name,
    v.customer_first_surname,
    v.customer_second_surname,
    v.customer_identity_card_type_id,
    v.customer_identity_card_type_code,
    v.customer_identity_card,
    v.customer_contact_phone,
    v.customer_e_mail,
    v.customer_address,
    v.customer_city,
    v.customer_state,
    v.customer_country,
    v.customer_post_code,
    v.customer_iban,
    v.customer_bank_entity,
    v.customer_bank_branch,
    v.customer_bank_control_digit,
    v.customer_bank_account_number,
    v.customer_active_date,
    v.customer_cancelled_date
   FROM (((((public.it_promotion p
     JOIN public.ct_promotion_type pt ON (((p.promotion_type_id = pt.promotion_type_id) AND (p.application_level_id = pt.application_level_id) AND (p.discount_type_id = pt.discount_type_id))))
     JOIN public.pt_application_level al ON ((p.application_level_id = al.application_level_id)))
     JOIN public.pt_discount_type dt ON ((p.discount_type_id = dt.discount_type_id)))
     JOIN public.pt_status s ON ((p.status_id = s.status_id)))
     JOIN public.vw_product_instance v ON (((v.product_id = p.parent_instance_id) AND ((p.start_date, p.end_date) OVERLAPS (v.product_start_date, v.product_end_date)) AND ((p.start_date, p.end_date) OVERLAPS (v.account_start_date, v.account_end_date)) AND ((p.start_date, p.end_date) OVERLAPS (v.customer_start_date, v.customer_end_date)))))
  WHERE ((al.code)::text = 'PROD'::text)
UNION
 SELECT p.promotion_id,
    p.parent_instance_id,
    p.start_date AS promotion_start_date,
    p.end_date AS promotion_end_date,
    p.promotion_type_id,
    p.code AS promotion_code,
    pt.code AS promotion_type_code,
    pt.name AS promotion_type_name,
    pt.description AS promotion_type_description,
    pt.status_id AS promotion_status_id,
    s.code AS promotion_status_code,
    p.application_level_id,
    al.code AS application_level_code,
    al.name AS application_level_name,
    al.description AS application_level_description,
    p.discount_type_id,
    dt.code AS discount_type_code,
    dt.name AS discount_type_name,
    dt.description AS discount_type_description,
    p.discount_value,
    p.active_date AS promotion_active_date,
    p.cancelled_date AS promotion_cancelled_date,
    v.service_id,
    v.service_code,
    v.service_number,
    v.service_general_1,
    v.service_general_2,
    v.service_general_3,
    v.service_type_id,
    v.service_type_code,
    v.service_type_name,
    v.service_type_description,
    v.service_status_id,
    v.service_status_code,
    v.service_start_date,
    v.service_end_date,
    v.service_active_date,
    v.service_cancelled_date,
    v.product_id,
    v.product_code,
    v.product_type_id,
    v.product_type_code,
    v.product_type_name,
    v.product_type_description,
    v.product_status_id,
    v.product_status_code,
    v.product_start_date,
    v.product_end_date,
    v.product_active_date,
    v.product_cancelled_date,
    v.account_id,
    v.account_type_id,
    v.account_start_date,
    v.account_end_date,
    v.account_code,
    v.account_type_code,
    v.account_status_id,
    v.account_status_code,
    v.contract_id,
    v.contract_number,
    v.contract_send_date,
    v.contract_signed_date,
    v.contract_actived_date,
    v.account_given_name,
    v.account_first_surname,
    v.account_second_surname,
    v.account_identity_card_type_id,
    v.account_identity_card_type_code,
    v.account_identity_card,
    v.account_contact_phone,
    v.account_e_mail,
    v.account_address,
    v.account_city,
    v.account_state,
    v.account_country,
    v.account_post_code,
    v.account_iban,
    v.account_bank_entity,
    v.account_bank_branch,
    v.account_bank_control_digit,
    v.account_bank_account_number,
    v.account_active_date,
    v.account_cancelled_date,
    v.payment_code,
    v.ordinary_bill_cycle_type_id,
    v.ordinary_bill_cycle_code,
    v.ordinary_bill_cycle_codenum,
    v.ordinary_bill_cycle_period_code,
    v.ordinary_bill_cycle_period_days,
    v.corrective_bill_cycle_code,
    v.corrective_bill_cycle_codenum,
    v.corrective_bill_cycle_period_code,
    v.corrective_bill_cycle_period_days,
    v.customer_id,
    v.customer_type_id,
    v.customer_start_date,
    v.customer_end_date,
    v.customer_type_code,
    v.customer_status_id,
    v.customer_status_code,
    v.customer_given_name,
    v.customer_first_surname,
    v.customer_second_surname,
    v.customer_identity_card_type_id,
    v.customer_identity_card_type_code,
    v.customer_identity_card,
    v.customer_contact_phone,
    v.customer_e_mail,
    v.customer_address,
    v.customer_city,
    v.customer_state,
    v.customer_country,
    v.customer_post_code,
    v.customer_iban,
    v.customer_bank_entity,
    v.customer_bank_branch,
    v.customer_bank_control_digit,
    v.customer_bank_account_number,
    v.customer_active_date,
    v.customer_cancelled_date
   FROM (((((public.it_promotion p
     JOIN public.ct_promotion_type pt ON (((p.promotion_type_id = pt.promotion_type_id) AND (p.application_level_id = pt.application_level_id) AND (p.discount_type_id = pt.discount_type_id))))
     JOIN public.pt_application_level al ON ((p.application_level_id = al.application_level_id)))
     JOIN public.pt_discount_type dt ON ((p.discount_type_id = dt.discount_type_id)))
     JOIN public.pt_status s ON ((p.status_id = s.status_id)))
     JOIN public.vw_service_instance v ON (((v.service_id = p.parent_instance_id) AND ((p.start_date, p.end_date) OVERLAPS (v.service_start_date, v.service_end_date)) AND ((p.start_date, p.end_date) OVERLAPS (v.product_start_date, v.product_end_date)) AND ((p.start_date, p.end_date) OVERLAPS (v.account_start_date, v.account_end_date)) AND ((p.start_date, p.end_date) OVERLAPS (v.customer_start_date, v.customer_end_date)))))
  WHERE ((al.code)::text = 'SERV'::text);


ALTER TABLE public.vw_promotion_instance OWNER TO comasw_admin;

--
-- Name: vw_promotion_product_type; Type: VIEW; Schema: public; Owner: comasw_admin
--

CREATE VIEW public.vw_promotion_product_type AS
 SELECT cppt.promo_prod_type_id,
    cppt.status_id AS promo_prod_type_status_id,
    psr.code AS promo_prod_type_status_code,
    cpt.product_type_id,
    cpt.code AS product_type_code,
    cpt.name AS product_type_name,
    cpt.description AS product_type_description,
    cpt.status_id AS product_type_status_id,
    psp.code AS product_type_status_code,
    cpt2.promotion_type_id,
    cpt2.start_date AS promotion_type_start_date,
    cpt2.end_date AS promotion_type_end_date,
    cpt2.code AS promotion_type_code,
    cpt2.name AS promotion_type_name,
    cpt2.description AS promotion_type_description,
    cpt2.discount_type_id,
    pdt.code AS discount_code,
    pdt.name AS discount_name,
    pdt.description AS discount_description,
    cpt2.discount_value,
    cpt2.status_id AS promotion_type_status_id,
    psp2.code AS promotion_type_status_code
   FROM ((((((public.ct_product_type cpt
     JOIN public.pt_status psp ON ((cpt.status_id = psp.status_id)))
     JOIN public.ct_promo_prod_type cppt ON ((cpt.product_type_id = cppt.product_type_id)))
     JOIN public.pt_status psr ON ((cppt.status_id = psr.status_id)))
     JOIN public.ct_promotion_type cpt2 ON ((cppt.promotion_type_id = cpt2.promotion_type_id)))
     JOIN public.pt_status psp2 ON ((cpt2.status_id = psp2.status_id)))
     JOIN public.pt_discount_type pdt ON ((pdt.discount_type_id = cpt2.discount_type_id)));


ALTER TABLE public.vw_promotion_product_type OWNER TO comasw_admin;

--
-- Name: vw_promotion_service_type; Type: VIEW; Schema: public; Owner: comasw_admin
--

CREATE VIEW public.vw_promotion_service_type AS
 SELECT cpst.promo_serv_type_id,
    cpst.status_id AS promo_serv_type_status_id,
    psr.code AS promo_serv_type_status_code,
    cst.service_type_id,
    cst.code AS service_type_code,
    cst.name AS service_type_name,
    cst.description AS service_type_description,
    cst.status_id AS service_type_status_id,
    psp.code AS service_type_status_code,
    cpt.promotion_type_id,
    cpt.start_date AS promotion_type_start_date,
    cpt.end_date AS promotion_type_end_date,
    cpt.code AS promotion_type_code,
    cpt.name AS promotion_type_name,
    cpt.description AS promotion_type_description,
    cpt.discount_type_id,
    pdt.code AS discount_code,
    pdt.name AS discount_name,
    pdt.description AS discount_description,
    cpt.discount_value,
    cpt.status_id AS promotion_type_status_id,
    psp.code AS promotion_type_status_code
   FROM ((((((public.ct_service_type cst
     JOIN public.pt_status pss ON ((cst.status_id = pss.status_id)))
     JOIN public.ct_promo_serv_type cpst ON ((cst.service_type_id = cpst.service_type_id)))
     JOIN public.pt_status psr ON ((cpst.status_id = psr.status_id)))
     JOIN public.ct_promotion_type cpt ON ((cpst.promotion_type_id = cpt.promotion_type_id)))
     JOIN public.pt_status psp ON ((cpt.status_id = psp.status_id)))
     JOIN public.pt_discount_type pdt ON ((pdt.discount_type_id = cpt.discount_type_id)));


ALTER TABLE public.vw_promotion_service_type OWNER TO comasw_admin;

--
-- Name: vw_service_fee_type; Type: VIEW; Schema: public; Owner: comasw_admin
--

CREATE VIEW public.vw_service_fee_type AS
 SELECT csft.serv_fee_type_id,
    csft.status_id AS serv_fee_type_status_id,
    psr.code AS serv_fee_type_status_code,
    cst.service_type_id,
    cst.code AS service_type_code,
    cst.name AS service_type_name,
    cst.description AS service_type_description,
    cst.status_id AS service_type_status_id,
    pss.code AS service_type_status_code,
    cft.fee_type_id,
    cft.start_date AS fee_type_start_date,
    cft.end_date AS fee_type_end_date,
    cft.code AS fee_type_code,
    cft.name AS fee_type_name,
    cft.description AS fee_type_description,
    cft.prorate,
    cft.price,
    cft.status_id AS fee_type_status_id,
    psf.code AS fee_type_status_code
   FROM (((((public.ct_service_type cst
     JOIN public.pt_status pss ON ((cst.status_id = pss.status_id)))
     JOIN public.ct_serv_fee_type csft ON ((cst.service_type_id = csft.service_type_id)))
     JOIN public.pt_status psr ON ((csft.status_id = psr.status_id)))
     JOIN public.ct_fee_type cft ON ((cft.fee_type_id = csft.fee_type_id)))
     JOIN public.pt_status psf ON ((cst.status_id = psf.status_id)));


ALTER TABLE public.vw_service_fee_type OWNER TO comasw_admin;

--
-- Name: vw_users; Type: VIEW; Schema: public; Owner: comasw_admin
--

CREATE VIEW public.vw_users AS
 SELECT u.user_id,
    u.user_code,
    u.password,
    u.profile_id,
    p.profile_code
   FROM (public.it_users u
     JOIN public.it_profiles p ON ((u.profile_id = p.profile_id)))
  WHERE (u.active = true);


ALTER TABLE public.vw_users OWNER TO comasw_admin;

--
-- Name: ct_account_type ct_account_type_code_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_account_type
    ADD CONSTRAINT ct_account_type_code_u UNIQUE (code);


--
-- Name: ct_account_type ct_account_type_name_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_account_type
    ADD CONSTRAINT ct_account_type_name_u UNIQUE (name);


--
-- Name: ct_account_type ct_account_type_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_account_type
    ADD CONSTRAINT ct_account_type_pk PRIMARY KEY (account_type_id);


--
-- Name: ct_bill_cycle_type ct_bill_cycle_type_code_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_bill_cycle_type
    ADD CONSTRAINT ct_bill_cycle_type_code_u UNIQUE (code);


--
-- Name: ct_bill_cycle_type ct_bill_cycle_type_codnum_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_bill_cycle_type
    ADD CONSTRAINT ct_bill_cycle_type_codnum_u UNIQUE (bill_cycle_codenum);


--
-- Name: ct_bill_cycle_type ct_bill_cycle_type_name_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_bill_cycle_type
    ADD CONSTRAINT ct_bill_cycle_type_name_u UNIQUE (name);


--
-- Name: ct_bill_cycle_type ct_bill_cycle_type_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_bill_cycle_type
    ADD CONSTRAINT ct_bill_cycle_type_pk PRIMARY KEY (bill_cycle_type_id);


--
-- Name: ct_consumption_type ct_consumption_type_code_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_consumption_type
    ADD CONSTRAINT ct_consumption_type_code_u UNIQUE (code);


--
-- Name: ct_consumption_type ct_consumption_type_name_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_consumption_type
    ADD CONSTRAINT ct_consumption_type_name_u UNIQUE (name);


--
-- Name: ct_consumption_type ct_consumption_type_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_consumption_type
    ADD CONSTRAINT ct_consumption_type_pk PRIMARY KEY (consumption_type_id);


--
-- Name: ct_customer_type ct_customer_type_code_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_customer_type
    ADD CONSTRAINT ct_customer_type_code_u UNIQUE (code);


--
-- Name: ct_customer_type ct_customer_type_name_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_customer_type
    ADD CONSTRAINT ct_customer_type_name_u UNIQUE (name);


--
-- Name: ct_customer_type ct_customer_type_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_customer_type
    ADD CONSTRAINT ct_customer_type_pk PRIMARY KEY (customer_type_id);


--
-- Name: ct_fee_type ct_fee_type_code_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_fee_type
    ADD CONSTRAINT ct_fee_type_code_u UNIQUE (code, start_date, end_date);


--
-- Name: ct_fee_type ct_fee_type_name_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_fee_type
    ADD CONSTRAINT ct_fee_type_name_u UNIQUE (name, start_date, end_date);


--
-- Name: ct_fee_type ct_fee_type_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_fee_type
    ADD CONSTRAINT ct_fee_type_pk PRIMARY KEY (fee_type_id, start_date, end_date);


--
-- Name: ct_prod_fee_type ct_prod_fee_type_code_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_prod_fee_type
    ADD CONSTRAINT ct_prod_fee_type_code_u UNIQUE (product_type_id, fee_type_id);


--
-- Name: ct_prod_fee_type ct_prod_fee_type_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_prod_fee_type
    ADD CONSTRAINT ct_prod_fee_type_pk PRIMARY KEY (prod_fee_type_id);


--
-- Name: ct_prod_serv_type ct_prod_serv_type_code_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_prod_serv_type
    ADD CONSTRAINT ct_prod_serv_type_code_u UNIQUE (product_type_id, service_type_id);


--
-- Name: ct_prod_serv_type ct_prod_serv_type_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_prod_serv_type
    ADD CONSTRAINT ct_prod_serv_type_pk PRIMARY KEY (prod_serv_type_id);


--
-- Name: ct_product_type ct_product_type_code_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_product_type
    ADD CONSTRAINT ct_product_type_code_u UNIQUE (code);


--
-- Name: ct_product_type ct_product_type_name_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_product_type
    ADD CONSTRAINT ct_product_type_name_u UNIQUE (name);


--
-- Name: ct_product_type ct_product_type_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_product_type
    ADD CONSTRAINT ct_product_type_pk PRIMARY KEY (product_type_id);


--
-- Name: ct_promo_consum_type_discount ct_promo_consum_type_discount_code_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_promo_consum_type_discount
    ADD CONSTRAINT ct_promo_consum_type_discount_code_u UNIQUE (promotion_type_id, consumption_type_id);


--
-- Name: ct_promo_consum_type_discount ct_promo_consum_type_discount_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_promo_consum_type_discount
    ADD CONSTRAINT ct_promo_consum_type_discount_pk PRIMARY KEY (promo_consum_type_discount_id);


--
-- Name: ct_promo_fee_type_discount ct_promo_fee_type_discount_code_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_promo_fee_type_discount
    ADD CONSTRAINT ct_promo_fee_type_discount_code_u UNIQUE (promotion_type_id, fee_type_id);


--
-- Name: ct_promo_fee_type_discount ct_promo_fee_type_discount_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_promo_fee_type_discount
    ADD CONSTRAINT ct_promo_fee_type_discount_pk PRIMARY KEY (promo_fee_type_discount_id);


--
-- Name: ct_promo_prod_type ct_promo_prod_type_code_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_promo_prod_type
    ADD CONSTRAINT ct_promo_prod_type_code_u UNIQUE (promotion_type_id, product_type_id);


--
-- Name: ct_promo_prod_type ct_promo_prod_type_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_promo_prod_type
    ADD CONSTRAINT ct_promo_prod_type_pk PRIMARY KEY (promo_prod_type_id);


--
-- Name: ct_promo_serv_type ct_promo_serv_type_code_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_promo_serv_type
    ADD CONSTRAINT ct_promo_serv_type_code_u UNIQUE (promotion_type_id, service_type_id);


--
-- Name: ct_promo_serv_type ct_promo_serv_type_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_promo_serv_type
    ADD CONSTRAINT ct_promo_serv_type_pk PRIMARY KEY (promo_serv_type_id);


--
-- Name: ct_promotion_type ct_promotion_type_code_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_promotion_type
    ADD CONSTRAINT ct_promotion_type_code_u UNIQUE (code, start_date, end_date);


--
-- Name: ct_promotion_type ct_promotion_type_name_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_promotion_type
    ADD CONSTRAINT ct_promotion_type_name_u UNIQUE (name, start_date, end_date);


--
-- Name: ct_promotion_type ct_promotion_type_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_promotion_type
    ADD CONSTRAINT ct_promotion_type_pk PRIMARY KEY (promotion_type_id, start_date, end_date);


--
-- Name: ct_serv_fee_type ct_serv_fee_type_code_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_serv_fee_type
    ADD CONSTRAINT ct_serv_fee_type_code_u UNIQUE (service_type_id, fee_type_id);


--
-- Name: ct_serv_fee_type ct_serv_fee_type_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_serv_fee_type
    ADD CONSTRAINT ct_serv_fee_type_pk PRIMARY KEY (serv_fee_type_id);


--
-- Name: ct_service_type ct_service_type_code_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_service_type
    ADD CONSTRAINT ct_service_type_code_u UNIQUE (code);


--
-- Name: ct_service_type ct_service_type_name_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_service_type
    ADD CONSTRAINT ct_service_type_name_u UNIQUE (name);


--
-- Name: ct_service_type ct_service_type_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_service_type
    ADD CONSTRAINT ct_service_type_pk PRIMARY KEY (service_type_id);


--
-- Name: idt_account idt_account_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.idt_account
    ADD CONSTRAINT idt_account_pk PRIMARY KEY (account_id);


--
-- Name: idt_customer idt_customer_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.idt_customer
    ADD CONSTRAINT idt_customer_pk PRIMARY KEY (customer_id);


--
-- Name: idt_fee idt_fee_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.idt_fee
    ADD CONSTRAINT idt_fee_pk PRIMARY KEY (fee_id);


--
-- Name: idt_fee_type idt_fee_type_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.idt_fee_type
    ADD CONSTRAINT idt_fee_type_pk PRIMARY KEY (fee_type_id);


--
-- Name: idt_product_fee idt_product_fee_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.idt_product_fee
    ADD CONSTRAINT idt_product_fee_pk PRIMARY KEY (product_fee_id);


--
-- Name: idt_product idt_product_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.idt_product
    ADD CONSTRAINT idt_product_pk PRIMARY KEY (product_id);


--
-- Name: idt_product_promotion idt_product_promotion_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.idt_product_promotion
    ADD CONSTRAINT idt_product_promotion_pk PRIMARY KEY (product_promotion_id);


--
-- Name: idt_product_service idt_product_service_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.idt_product_service
    ADD CONSTRAINT idt_product_service_pk PRIMARY KEY (product_service_id);


--
-- Name: idt_promotion idt_promotion_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.idt_promotion
    ADD CONSTRAINT idt_promotion_pk PRIMARY KEY (promotion_id);


--
-- Name: idt_promotion_type idt_promotion_type_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.idt_promotion_type
    ADD CONSTRAINT idt_promotion_type_pk PRIMARY KEY (promotion_type_id);


--
-- Name: idt_service_fee idt_service_fee_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.idt_service_fee
    ADD CONSTRAINT idt_service_fee_pk PRIMARY KEY (service_fee_id);


--
-- Name: idt_service idt_service_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.idt_service
    ADD CONSTRAINT idt_service_pk PRIMARY KEY (service_id);


--
-- Name: idt_service_promotion idt_service_promotion_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.idt_service_promotion
    ADD CONSTRAINT idt_service_promotion_pk PRIMARY KEY (service_promotion_id);


--
-- Name: it_account it_account_code_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_account
    ADD CONSTRAINT it_account_code_u UNIQUE (code, customer_id, account_id, start_date, end_date);


--
-- Name: it_account it_account_contract_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_account
    ADD CONSTRAINT it_account_contract_u UNIQUE (bank_account_number, account_id, customer_id, contract_number);


--
-- Name: it_account it_account_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_account
    ADD CONSTRAINT it_account_pk PRIMARY KEY (account_id, start_date, end_date);


--
-- Name: it_contract it_contract_code_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_contract
    ADD CONSTRAINT it_contract_code_u UNIQUE (contract_number);


--
-- Name: it_contract it_contract_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_contract
    ADD CONSTRAINT it_contract_pk PRIMARY KEY (contract_id);


--
-- Name: it_customer it_customer_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_customer
    ADD CONSTRAINT it_customer_pk PRIMARY KEY (customer_id, start_date, end_date);


--
-- Name: it_fee it_fee_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_fee
    ADD CONSTRAINT it_fee_pk PRIMARY KEY (fee_type_id, start_date, end_date);


--
-- Name: it_product it_product_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_product
    ADD CONSTRAINT it_product_pk PRIMARY KEY (product_id, start_date, end_date);


--
-- Name: it_profiles it_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_profiles
    ADD CONSTRAINT it_profiles_pkey PRIMARY KEY (profile_id);


--
-- Name: it_profiles it_profiles_profile_code_key; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_profiles
    ADD CONSTRAINT it_profiles_profile_code_key UNIQUE (profile_code);


--
-- Name: it_promotion it_promotion_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_promotion
    ADD CONSTRAINT it_promotion_pk PRIMARY KEY (promotion_type_id, start_date, end_date);


--
-- Name: it_service it_service_code_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_service
    ADD CONSTRAINT it_service_code_u UNIQUE (service_number, product_id, start_date, status_id);


--
-- Name: it_service it_service_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_service
    ADD CONSTRAINT it_service_pk PRIMARY KEY (service_id, start_date, end_date);


--
-- Name: it_users it_users_pkey; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_users
    ADD CONSTRAINT it_users_pkey PRIMARY KEY (user_id);


--
-- Name: it_users it_users_user_code_key; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_users
    ADD CONSTRAINT it_users_user_code_key UNIQUE (user_code);


--
-- Name: mt_application_menu mt_application_menu_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.mt_application_menu
    ADD CONSTRAINT mt_application_menu_pk PRIMARY KEY (application_menu_id);


--
-- Name: pt_application_level pt_application_level_code_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.pt_application_level
    ADD CONSTRAINT pt_application_level_code_u UNIQUE (code);


--
-- Name: pt_application_level pt_application_level_name_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.pt_application_level
    ADD CONSTRAINT pt_application_level_name_u UNIQUE (name);


--
-- Name: pt_application_level pt_application_level_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.pt_application_level
    ADD CONSTRAINT pt_application_level_pk PRIMARY KEY (application_level_id);


--
-- Name: pt_billing_period pt_billing_period_code_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.pt_billing_period
    ADD CONSTRAINT pt_billing_period_code_u UNIQUE (code);


--
-- Name: pt_billing_period pt_billing_period_name_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.pt_billing_period
    ADD CONSTRAINT pt_billing_period_name_u UNIQUE (name);


--
-- Name: pt_billing_period pt_billing_period_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.pt_billing_period
    ADD CONSTRAINT pt_billing_period_pk PRIMARY KEY (billing_period_id);


--
-- Name: pt_consumption_class pt_consumption_class_code_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.pt_consumption_class
    ADD CONSTRAINT pt_consumption_class_code_u UNIQUE (code);


--
-- Name: pt_consumption_class pt_consumption_class_name_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.pt_consumption_class
    ADD CONSTRAINT pt_consumption_class_name_u UNIQUE (name);


--
-- Name: pt_consumption_class pt_consumption_class_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.pt_consumption_class
    ADD CONSTRAINT pt_consumption_class_pk PRIMARY KEY (consumption_class_id);


--
-- Name: pt_discount_type pt_discount_type_code_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.pt_discount_type
    ADD CONSTRAINT pt_discount_type_code_u UNIQUE (code);


--
-- Name: pt_discount_type pt_discount_type_name_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.pt_discount_type
    ADD CONSTRAINT pt_discount_type_name_u UNIQUE (name);


--
-- Name: pt_discount_type pt_discount_type_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.pt_discount_type
    ADD CONSTRAINT pt_discount_type_pk PRIMARY KEY (discount_type_id);


--
-- Name: pt_entity_type pt_entity_type_PK; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.pt_entity_type
    ADD CONSTRAINT "pt_entity_type_PK" PRIMARY KEY (entity_type_id);


--
-- Name: pt_entity_type pt_entity_type_code_U; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.pt_entity_type
    ADD CONSTRAINT "pt_entity_type_code_U" UNIQUE (code);


--
-- Name: pt_entity_type pt_entity_type_name_U; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.pt_entity_type
    ADD CONSTRAINT "pt_entity_type_name_U" UNIQUE (name);


--
-- Name: pt_identity_card_type pt_identity_card_type_code_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.pt_identity_card_type
    ADD CONSTRAINT pt_identity_card_type_code_u UNIQUE (code);


--
-- Name: pt_identity_card_type pt_identity_card_type_name_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.pt_identity_card_type
    ADD CONSTRAINT pt_identity_card_type_name_u UNIQUE (name);


--
-- Name: pt_identity_card_type pt_identity_card_type_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.pt_identity_card_type
    ADD CONSTRAINT pt_identity_card_type_pk PRIMARY KEY (identity_card_type_id);


--
-- Name: pt_payment_method pt_payment_method_code_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.pt_payment_method
    ADD CONSTRAINT pt_payment_method_code_u UNIQUE (code);


--
-- Name: pt_payment_method pt_payment_method_name_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.pt_payment_method
    ADD CONSTRAINT pt_payment_method_name_u UNIQUE (name);


--
-- Name: pt_payment_method pt_payment_method_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.pt_payment_method
    ADD CONSTRAINT pt_payment_method_pk PRIMARY KEY (payment_method_id);


--
-- Name: pt_status pt_status_code_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.pt_status
    ADD CONSTRAINT pt_status_code_u UNIQUE (code);


--
-- Name: pt_status pt_status_name_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.pt_status
    ADD CONSTRAINT pt_status_name_u UNIQUE (name);


--
-- Name: pt_status pt_status_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.pt_status
    ADD CONSTRAINT pt_status_pk PRIMARY KEY (status_id);


--
-- Name: pt_tax_type pt_tax_type_code_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.pt_tax_type
    ADD CONSTRAINT pt_tax_type_code_u UNIQUE (code);


--
-- Name: pt_tax_type pt_tax_type_name_u; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.pt_tax_type
    ADD CONSTRAINT pt_tax_type_name_u UNIQUE (name);


--
-- Name: pt_tax_type pt_tax_type_pk; Type: CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.pt_tax_type
    ADD CONSTRAINT pt_tax_type_pk PRIMARY KEY (tax_type_id);


--
-- Name: it_promotion tf_create_promotion_inherit_data; Type: TRIGGER; Schema: public; Owner: comasw_admin
--

CREATE TRIGGER tf_create_promotion_inherit_data BEFORE INSERT ON public.it_promotion FOR EACH ROW EXECUTE FUNCTION public.tf_create_promotion_inherit_data();


--
-- Name: it_contract trg_create_contract_nr; Type: TRIGGER; Schema: public; Owner: comasw_admin
--

CREATE TRIGGER trg_create_contract_nr BEFORE INSERT ON public.it_contract FOR EACH ROW EXECUTE FUNCTION public.tf_create_contract_nr();


--
-- Name: ct_fee_type trg_ct_fee_type_add_fee_type_validation; Type: TRIGGER; Schema: public; Owner: comasw_admin
--

CREATE TRIGGER trg_ct_fee_type_add_fee_type_validation BEFORE INSERT OR UPDATE ON public.ct_fee_type FOR EACH ROW EXECUTE FUNCTION public.tf_add_fee_type_validation();


--
-- Name: ct_promotion_type trg_ct_promotion_type_add_promo_type_validation; Type: TRIGGER; Schema: public; Owner: comasw_admin
--

CREATE TRIGGER trg_ct_promotion_type_add_promo_type_validation BEFORE INSERT OR UPDATE ON public.ct_promotion_type FOR EACH ROW EXECUTE FUNCTION public.tf_add_promotion_type_validation();


--
-- Name: it_account trg_it_account_validate_parent_status; Type: TRIGGER; Schema: public; Owner: comasw_admin
--

CREATE TRIGGER trg_it_account_validate_parent_status BEFORE INSERT ON public.it_account FOR EACH ROW EXECUTE FUNCTION public.tf_account_validate_parent_status();


--
-- Name: it_customer trg_it_customer_add_customer_validation; Type: TRIGGER; Schema: public; Owner: comasw_admin
--

CREATE TRIGGER trg_it_customer_add_customer_validation BEFORE INSERT OR UPDATE ON public.it_customer FOR EACH ROW EXECUTE FUNCTION public.tf_add_customer_validation();


--
-- Name: it_fee trg_it_fee_inherit_fee_type_data; Type: TRIGGER; Schema: public; Owner: comasw_admin
--

CREATE TRIGGER trg_it_fee_inherit_fee_type_data BEFORE INSERT OR UPDATE ON public.it_fee FOR EACH ROW EXECUTE FUNCTION public.tf_create_fee_inherit_data();


--
-- Name: it_fee trg_it_fee_validate_parent_status; Type: TRIGGER; Schema: public; Owner: comasw_admin
--

CREATE TRIGGER trg_it_fee_validate_parent_status BEFORE INSERT ON public.it_fee FOR EACH ROW EXECUTE FUNCTION public.tf_fee_validate_parent_status();


--
-- Name: it_product trg_it_product_create_product_code; Type: TRIGGER; Schema: public; Owner: comasw_admin
--

CREATE TRIGGER trg_it_product_create_product_code BEFORE INSERT ON public.it_product FOR EACH ROW EXECUTE FUNCTION public.tf_create_product_code();


--
-- Name: it_product trg_it_product_validate_parent_status; Type: TRIGGER; Schema: public; Owner: comasw_admin
--

CREATE TRIGGER trg_it_product_validate_parent_status BEFORE INSERT ON public.it_product FOR EACH ROW EXECUTE FUNCTION public.tf_product_validate_parent_status();


--
-- Name: it_promotion trg_it_promotion_validate_parent_status; Type: TRIGGER; Schema: public; Owner: comasw_admin
--

CREATE TRIGGER trg_it_promotion_validate_parent_status BEFORE INSERT ON public.it_promotion FOR EACH ROW EXECUTE FUNCTION public.tf_promotion_validate_parent_status();


--
-- Name: it_service trg_it_service_create_service_code; Type: TRIGGER; Schema: public; Owner: comasw_admin
--

CREATE TRIGGER trg_it_service_create_service_code BEFORE INSERT ON public.it_service FOR EACH ROW EXECUTE FUNCTION public.tf_create_service_code();


--
-- Name: it_service trg_it_service_validate_parent_status; Type: TRIGGER; Schema: public; Owner: comasw_admin
--

CREATE TRIGGER trg_it_service_validate_parent_status BEFORE INSERT ON public.it_service FOR EACH ROW EXECUTE FUNCTION public.tf_validate_parent_status();


--
-- Name: ct_account_type ct_account_type_cbc_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_account_type
    ADD CONSTRAINT ct_account_type_cbc_fk FOREIGN KEY (corrective_bill_cycle_type_id) REFERENCES public.ct_bill_cycle_type(bill_cycle_type_id);


--
-- Name: ct_account_type ct_account_type_entity_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_account_type
    ADD CONSTRAINT ct_account_type_entity_fk FOREIGN KEY (entity_type_id) REFERENCES public.pt_entity_type(entity_type_id);


--
-- Name: ct_account_type ct_account_type_obc_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_account_type
    ADD CONSTRAINT ct_account_type_obc_fk FOREIGN KEY (ordinary_bill_cycle_type_id) REFERENCES public.ct_bill_cycle_type(bill_cycle_type_id);


--
-- Name: ct_account_type ct_account_type_payment_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_account_type
    ADD CONSTRAINT ct_account_type_payment_fk FOREIGN KEY (payment_method_id) REFERENCES public.pt_payment_method(payment_method_id);


--
-- Name: ct_account_type ct_account_type_status_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_account_type
    ADD CONSTRAINT ct_account_type_status_fk FOREIGN KEY (status_id) REFERENCES public.pt_status(status_id);


--
-- Name: ct_bill_cycle_type ct_bill_cycle_type_period_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_bill_cycle_type
    ADD CONSTRAINT ct_bill_cycle_type_period_fk FOREIGN KEY (billing_period_id) REFERENCES public.pt_billing_period(billing_period_id);


--
-- Name: ct_bill_cycle_type ct_bill_cycle_type_status_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_bill_cycle_type
    ADD CONSTRAINT ct_bill_cycle_type_status_fk FOREIGN KEY (status_id) REFERENCES public.pt_status(status_id);


--
-- Name: ct_consumption_type ct_consumption_type_class_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_consumption_type
    ADD CONSTRAINT ct_consumption_type_class_fk FOREIGN KEY (consumption_class_id) REFERENCES public.pt_consumption_class(consumption_class_id);


--
-- Name: ct_consumption_type ct_consumption_type_entity_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_consumption_type
    ADD CONSTRAINT ct_consumption_type_entity_fk FOREIGN KEY (entity_type_id) REFERENCES public.pt_entity_type(entity_type_id);


--
-- Name: ct_consumption_type ct_consumption_type_status_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_consumption_type
    ADD CONSTRAINT ct_consumption_type_status_fk FOREIGN KEY (status_id) REFERENCES public.pt_status(status_id);


--
-- Name: ct_customer_type ct_customer_type_entity_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_customer_type
    ADD CONSTRAINT ct_customer_type_entity_fk FOREIGN KEY (entity_type_id) REFERENCES public.pt_entity_type(entity_type_id);


--
-- Name: ct_customer_type ct_customer_type_status_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_customer_type
    ADD CONSTRAINT ct_customer_type_status_fk FOREIGN KEY (status_id) REFERENCES public.pt_status(status_id);


--
-- Name: ct_fee_type ct_fee_type_entity_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_fee_type
    ADD CONSTRAINT ct_fee_type_entity_fk FOREIGN KEY (entity_type_id) REFERENCES public.pt_entity_type(entity_type_id);


--
-- Name: ct_fee_type ct_fee_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_fee_type
    ADD CONSTRAINT ct_fee_type_id_fk FOREIGN KEY (fee_type_id) REFERENCES public.idt_fee_type(fee_type_id);


--
-- Name: ct_fee_type ct_fee_type_level_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_fee_type
    ADD CONSTRAINT ct_fee_type_level_fk FOREIGN KEY (application_level_id) REFERENCES public.pt_application_level(application_level_id);


--
-- Name: ct_fee_type ct_fee_type_status_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_fee_type
    ADD CONSTRAINT ct_fee_type_status_fk FOREIGN KEY (status_id) REFERENCES public.pt_status(status_id);


--
-- Name: ct_prod_fee_type ct_prod_fee_type_fee_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_prod_fee_type
    ADD CONSTRAINT ct_prod_fee_type_fee_fk FOREIGN KEY (fee_type_id) REFERENCES public.idt_fee_type(fee_type_id);


--
-- Name: ct_prod_fee_type ct_prod_fee_type_product_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_prod_fee_type
    ADD CONSTRAINT ct_prod_fee_type_product_fk FOREIGN KEY (product_type_id) REFERENCES public.ct_product_type(product_type_id);


--
-- Name: ct_prod_fee_type ct_prod_fee_type_status_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_prod_fee_type
    ADD CONSTRAINT ct_prod_fee_type_status_fk FOREIGN KEY (status_id) REFERENCES public.pt_status(status_id);


--
-- Name: ct_prod_serv_type ct_prod_serv_type_product_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_prod_serv_type
    ADD CONSTRAINT ct_prod_serv_type_product_fk FOREIGN KEY (product_type_id) REFERENCES public.ct_product_type(product_type_id);


--
-- Name: ct_prod_serv_type ct_prod_serv_type_service_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_prod_serv_type
    ADD CONSTRAINT ct_prod_serv_type_service_fk FOREIGN KEY (service_type_id) REFERENCES public.ct_service_type(service_type_id);


--
-- Name: ct_prod_serv_type ct_prod_serv_type_status_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_prod_serv_type
    ADD CONSTRAINT ct_prod_serv_type_status_fk FOREIGN KEY (status_id) REFERENCES public.pt_status(status_id);


--
-- Name: ct_product_type ct_product_type_entity_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_product_type
    ADD CONSTRAINT ct_product_type_entity_fk FOREIGN KEY (entity_type_id) REFERENCES public.pt_entity_type(entity_type_id);


--
-- Name: ct_product_type ct_product_type_status_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_product_type
    ADD CONSTRAINT ct_product_type_status_fk FOREIGN KEY (status_id) REFERENCES public.pt_status(status_id);


--
-- Name: ct_promo_consum_type_discount ct_promo_consum_type_disc_cons_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_promo_consum_type_discount
    ADD CONSTRAINT ct_promo_consum_type_disc_cons_fk FOREIGN KEY (consumption_type_id) REFERENCES public.ct_consumption_type(consumption_type_id);


--
-- Name: ct_promo_consum_type_discount ct_promo_consum_type_disc_promo_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_promo_consum_type_discount
    ADD CONSTRAINT ct_promo_consum_type_disc_promo_fk FOREIGN KEY (promotion_type_id) REFERENCES public.idt_promotion_type(promotion_type_id);


--
-- Name: ct_promo_consum_type_discount ct_promo_consum_type_discount_status_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_promo_consum_type_discount
    ADD CONSTRAINT ct_promo_consum_type_discount_status_fk FOREIGN KEY (status_id) REFERENCES public.pt_status(status_id);


--
-- Name: ct_promo_fee_type_discount ct_promo_fee_type_discount_fee_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_promo_fee_type_discount
    ADD CONSTRAINT ct_promo_fee_type_discount_fee_fk FOREIGN KEY (fee_type_id) REFERENCES public.idt_fee_type(fee_type_id);


--
-- Name: ct_promo_fee_type_discount ct_promo_fee_type_discount_lev_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_promo_fee_type_discount
    ADD CONSTRAINT ct_promo_fee_type_discount_lev_fk FOREIGN KEY (application_level_id) REFERENCES public.pt_application_level(application_level_id);


--
-- Name: ct_promo_fee_type_discount ct_promo_fee_type_discount_promo_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_promo_fee_type_discount
    ADD CONSTRAINT ct_promo_fee_type_discount_promo_fk FOREIGN KEY (promotion_type_id) REFERENCES public.idt_promotion_type(promotion_type_id);


--
-- Name: ct_promo_fee_type_discount ct_promo_fee_type_discount_status_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_promo_fee_type_discount
    ADD CONSTRAINT ct_promo_fee_type_discount_status_fk FOREIGN KEY (status_id) REFERENCES public.pt_status(status_id);


--
-- Name: ct_promo_prod_type ct_promo_prod_type_prod_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_promo_prod_type
    ADD CONSTRAINT ct_promo_prod_type_prod_fk FOREIGN KEY (product_type_id) REFERENCES public.ct_product_type(product_type_id);


--
-- Name: ct_promo_prod_type ct_promo_prod_type_promo_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_promo_prod_type
    ADD CONSTRAINT ct_promo_prod_type_promo_fk FOREIGN KEY (promotion_type_id) REFERENCES public.idt_promotion_type(promotion_type_id);


--
-- Name: ct_promo_prod_type ct_promo_prod_type_status_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_promo_prod_type
    ADD CONSTRAINT ct_promo_prod_type_status_fk FOREIGN KEY (status_id) REFERENCES public.pt_status(status_id);


--
-- Name: ct_promo_serv_type ct_promo_serv_type_promo_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_promo_serv_type
    ADD CONSTRAINT ct_promo_serv_type_promo_fk FOREIGN KEY (promotion_type_id) REFERENCES public.idt_promotion_type(promotion_type_id);


--
-- Name: ct_promo_serv_type ct_promo_serv_type_serv_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_promo_serv_type
    ADD CONSTRAINT ct_promo_serv_type_serv_fk FOREIGN KEY (service_type_id) REFERENCES public.ct_service_type(service_type_id);


--
-- Name: ct_promo_serv_type ct_promo_serv_type_status_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_promo_serv_type
    ADD CONSTRAINT ct_promo_serv_type_status_fk FOREIGN KEY (status_id) REFERENCES public.pt_status(status_id);


--
-- Name: ct_promotion_type ct_promotion_type_discount_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_promotion_type
    ADD CONSTRAINT ct_promotion_type_discount_fk FOREIGN KEY (application_level_id) REFERENCES public.pt_application_level(application_level_id);


--
-- Name: ct_promotion_type ct_promotion_type_entity_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_promotion_type
    ADD CONSTRAINT ct_promotion_type_entity_fk FOREIGN KEY (entity_type_id) REFERENCES public.pt_entity_type(entity_type_id);


--
-- Name: ct_promotion_type ct_promotion_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_promotion_type
    ADD CONSTRAINT ct_promotion_type_id_fk FOREIGN KEY (promotion_type_id) REFERENCES public.idt_promotion_type(promotion_type_id);


--
-- Name: ct_promotion_type ct_promotion_type_level_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_promotion_type
    ADD CONSTRAINT ct_promotion_type_level_fk FOREIGN KEY (discount_type_id) REFERENCES public.pt_discount_type(discount_type_id);


--
-- Name: ct_promotion_type ct_promotion_type_status_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_promotion_type
    ADD CONSTRAINT ct_promotion_type_status_fk FOREIGN KEY (status_id) REFERENCES public.pt_status(status_id);


--
-- Name: ct_serv_fee_type ct_serv_fee_type_fee_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_serv_fee_type
    ADD CONSTRAINT ct_serv_fee_type_fee_fk FOREIGN KEY (fee_type_id) REFERENCES public.idt_fee_type(fee_type_id);


--
-- Name: ct_serv_fee_type ct_serv_fee_type_service_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_serv_fee_type
    ADD CONSTRAINT ct_serv_fee_type_service_fk FOREIGN KEY (service_type_id) REFERENCES public.ct_service_type(service_type_id);


--
-- Name: ct_serv_fee_type ct_serv_fee_type_status_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_serv_fee_type
    ADD CONSTRAINT ct_serv_fee_type_status_fk FOREIGN KEY (status_id) REFERENCES public.pt_status(status_id);


--
-- Name: ct_service_type ct_service_type_entity_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_service_type
    ADD CONSTRAINT ct_service_type_entity_fk FOREIGN KEY (entity_type_id) REFERENCES public.pt_entity_type(entity_type_id);


--
-- Name: ct_service_type ct_service_type_status_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.ct_service_type
    ADD CONSTRAINT ct_service_type_status_fk FOREIGN KEY (status_id) REFERENCES public.pt_status(status_id);


--
-- Name: it_account it_account_contract_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_account
    ADD CONSTRAINT it_account_contract_id_fk FOREIGN KEY (contract_number) REFERENCES public.it_contract(contract_number);


--
-- Name: it_account it_account_customer_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_account
    ADD CONSTRAINT it_account_customer_id_fk FOREIGN KEY (customer_id) REFERENCES public.idt_customer(customer_id);


--
-- Name: it_account it_account_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_account
    ADD CONSTRAINT it_account_id_fk FOREIGN KEY (account_id) REFERENCES public.idt_account(account_id);


--
-- Name: it_account it_account_status_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_account
    ADD CONSTRAINT it_account_status_fk FOREIGN KEY (status_id) REFERENCES public.pt_status(status_id);


--
-- Name: it_account it_account_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_account
    ADD CONSTRAINT it_account_type_id_fk FOREIGN KEY (account_type_id) REFERENCES public.ct_account_type(account_type_id);


--
-- Name: it_customer it_custmoer_card_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_customer
    ADD CONSTRAINT it_custmoer_card_type_id_fk FOREIGN KEY (identity_card_type_id) REFERENCES public.pt_identity_card_type(identity_card_type_id);


--
-- Name: it_customer it_customer_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_customer
    ADD CONSTRAINT it_customer_id_fk FOREIGN KEY (customer_id) REFERENCES public.idt_customer(customer_id);


--
-- Name: it_customer it_customer_status_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_customer
    ADD CONSTRAINT it_customer_status_fk FOREIGN KEY (status_id) REFERENCES public.pt_status(status_id);


--
-- Name: it_customer it_customer_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_customer
    ADD CONSTRAINT it_customer_type_id_fk FOREIGN KEY (customer_type_id) REFERENCES public.ct_customer_type(customer_type_id);


--
-- Name: it_fee it_fee_application_level_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_fee
    ADD CONSTRAINT it_fee_application_level_fk FOREIGN KEY (application_level_id) REFERENCES public.pt_application_level(application_level_id);


--
-- Name: it_fee it_fee_fee_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_fee
    ADD CONSTRAINT it_fee_fee_type_id_fk FOREIGN KEY (fee_type_id) REFERENCES public.idt_fee_type(fee_type_id);


--
-- Name: it_fee it_fee_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_fee
    ADD CONSTRAINT it_fee_id_fk FOREIGN KEY (fee_id) REFERENCES public.idt_fee(fee_id);


--
-- Name: it_fee it_fee_status_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_fee
    ADD CONSTRAINT it_fee_status_fk FOREIGN KEY (status_id) REFERENCES public.pt_status(status_id);


--
-- Name: it_product it_product_account_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_product
    ADD CONSTRAINT it_product_account_id_fk FOREIGN KEY (account_id) REFERENCES public.idt_account(account_id);


--
-- Name: it_product it_product_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_product
    ADD CONSTRAINT it_product_id_fk FOREIGN KEY (product_id) REFERENCES public.idt_product(product_id);


--
-- Name: it_product it_product_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_product
    ADD CONSTRAINT it_product_type_id_fk FOREIGN KEY (product_type_id) REFERENCES public.ct_product_type(product_type_id);


--
-- Name: it_promotion it_promotion_discount_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_promotion
    ADD CONSTRAINT it_promotion_discount_fk FOREIGN KEY (application_level_id) REFERENCES public.pt_application_level(application_level_id);


--
-- Name: it_promotion it_promotion_discount_type_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_promotion
    ADD CONSTRAINT it_promotion_discount_type_fk FOREIGN KEY (discount_type_id) REFERENCES public.pt_discount_type(discount_type_id);


--
-- Name: it_promotion it_promotion_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_promotion
    ADD CONSTRAINT it_promotion_id_fk FOREIGN KEY (promotion_id) REFERENCES public.idt_promotion(promotion_id);


--
-- Name: it_promotion it_promotion_promotion_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_promotion
    ADD CONSTRAINT it_promotion_promotion_type_id_fk FOREIGN KEY (promotion_type_id) REFERENCES public.idt_promotion_type(promotion_type_id);


--
-- Name: it_promotion it_promotion_status_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_promotion
    ADD CONSTRAINT it_promotion_status_fk FOREIGN KEY (status_id) REFERENCES public.pt_status(status_id);


--
-- Name: it_service it_service_product_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_service
    ADD CONSTRAINT it_service_product_id_fk FOREIGN KEY (product_id) REFERENCES public.idt_product(product_id);


--
-- Name: it_service it_service_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_service
    ADD CONSTRAINT it_service_type_id_fk FOREIGN KEY (service_type_id) REFERENCES public.ct_service_type(service_type_id);


--
-- Name: it_users it_users_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.it_users
    ADD CONSTRAINT it_users_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.it_profiles(profile_id);


--
-- Name: mt_application_menu mt_application_menu_fk; Type: FK CONSTRAINT; Schema: public; Owner: comasw_admin
--

ALTER TABLE ONLY public.mt_application_menu
    ADD CONSTRAINT mt_application_menu_fk FOREIGN KEY (application_parent_menu_id) REFERENCES public.mt_application_menu(application_menu_id);


--
-- Name: FUNCTION tf_add_fee_type_validation(); Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON FUNCTION public.tf_add_fee_type_validation() TO comasw_app;


--
-- Name: FUNCTION tf_add_product_validation(); Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON FUNCTION public.tf_add_product_validation() TO comasw_app;


--
-- Name: FUNCTION tf_add_promotion_type_validation(); Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON FUNCTION public.tf_add_promotion_type_validation() TO comasw_app;


--
-- Name: FUNCTION tf_add_service_validation(); Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON FUNCTION public.tf_add_service_validation() TO comasw_app;


--
-- Name: FUNCTION tf_create_contract_nr(); Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON FUNCTION public.tf_create_contract_nr() TO comasw_app;


--
-- Name: FUNCTION tf_create_fee_inherit_data(); Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON FUNCTION public.tf_create_fee_inherit_data() TO comasw_app;


--
-- Name: FUNCTION tf_create_product_code(); Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON FUNCTION public.tf_create_product_code() TO comasw_app;


--
-- Name: FUNCTION tf_create_promotion_inherit_data(); Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON FUNCTION public.tf_create_promotion_inherit_data() TO comasw_app;


--
-- Name: FUNCTION tf_create_service_code(); Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON FUNCTION public.tf_create_service_code() TO comasw_app;


--
-- Name: FUNCTION tf_fee_validate_parent_status(); Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON FUNCTION public.tf_fee_validate_parent_status() TO comasw_app;


--
-- Name: FUNCTION tf_product_active_date_changed(); Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON FUNCTION public.tf_product_active_date_changed() TO comasw_app;


--
-- Name: FUNCTION tf_product_cancelled_date_changed(); Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON FUNCTION public.tf_product_cancelled_date_changed() TO comasw_app;


--
-- Name: FUNCTION tf_product_cancelled_row(); Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON FUNCTION public.tf_product_cancelled_row() TO comasw_app;


--
-- Name: FUNCTION tf_product_validate_parent_status(); Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON FUNCTION public.tf_product_validate_parent_status() TO comasw_app;


--
-- Name: FUNCTION tf_promotion_validate_parent_status(); Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON FUNCTION public.tf_promotion_validate_parent_status() TO comasw_app;


--
-- Name: FUNCTION tf_validate_parent_product_status(); Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON FUNCTION public.tf_validate_parent_product_status() TO comasw_app;


--
-- Name: FUNCTION tf_validate_parent_service_status(); Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON FUNCTION public.tf_validate_parent_service_status() TO comasw_app;


--
-- Name: FUNCTION tf_validate_parent_status(); Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON FUNCTION public.tf_validate_parent_status() TO comasw_app;


--
-- Name: SEQUENCE seq_account_type_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_account_type_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_account_type_id TO postgres;


--
-- Name: TABLE ct_account_type; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON TABLE public.ct_account_type TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ct_account_type TO comasw_app;


--
-- Name: SEQUENCE seq_bill_cycle_type_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_bill_cycle_type_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_bill_cycle_type_id TO postgres;


--
-- Name: TABLE ct_bill_cycle_type; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON TABLE public.ct_bill_cycle_type TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ct_bill_cycle_type TO comasw_app;


--
-- Name: SEQUENCE seq_consumption_type; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_consumption_type TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_consumption_type TO postgres;


--
-- Name: TABLE ct_consumption_type; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON TABLE public.ct_consumption_type TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ct_consumption_type TO comasw_app;


--
-- Name: SEQUENCE seq_customer_type_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_customer_type_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_customer_type_id TO postgres;


--
-- Name: TABLE ct_customer_type; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON TABLE public.ct_customer_type TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ct_customer_type TO comasw_app;


--
-- Name: TABLE ct_fee_type; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON TABLE public.ct_fee_type TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ct_fee_type TO comasw_app;


--
-- Name: SEQUENCE seq_prod_fee_type_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_prod_fee_type_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_prod_fee_type_id TO postgres;


--
-- Name: TABLE ct_prod_fee_type; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON TABLE public.ct_prod_fee_type TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ct_prod_fee_type TO comasw_app;


--
-- Name: SEQUENCE seq_prod_serv_type_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_prod_serv_type_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_prod_serv_type_id TO postgres;


--
-- Name: TABLE ct_prod_serv_type; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON TABLE public.ct_prod_serv_type TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ct_prod_serv_type TO comasw_app;


--
-- Name: SEQUENCE seq_product_type_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_product_type_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_product_type_id TO postgres;


--
-- Name: TABLE ct_product_type; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON TABLE public.ct_product_type TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ct_product_type TO comasw_app;


--
-- Name: SEQUENCE seq_promo_consum_type_disc_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_promo_consum_type_disc_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_promo_consum_type_disc_id TO postgres;


--
-- Name: TABLE ct_promo_consum_type_discount; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON TABLE public.ct_promo_consum_type_discount TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ct_promo_consum_type_discount TO comasw_app;


--
-- Name: SEQUENCE seq_promo_fee_type_disc_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_promo_fee_type_disc_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_promo_fee_type_disc_id TO postgres;


--
-- Name: TABLE ct_promo_fee_type_discount; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON TABLE public.ct_promo_fee_type_discount TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ct_promo_fee_type_discount TO comasw_app;


--
-- Name: SEQUENCE seq_promo_prod_type_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_promo_prod_type_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_promo_prod_type_id TO postgres;


--
-- Name: TABLE ct_promo_prod_type; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON TABLE public.ct_promo_prod_type TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ct_promo_prod_type TO comasw_app;


--
-- Name: SEQUENCE seq_promo_serv_type_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_promo_serv_type_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_promo_serv_type_id TO postgres;


--
-- Name: TABLE ct_promo_serv_type; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON TABLE public.ct_promo_serv_type TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ct_promo_serv_type TO comasw_app;


--
-- Name: TABLE ct_promotion_type; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ct_promotion_type TO comasw_app;
GRANT ALL ON TABLE public.ct_promotion_type TO postgres;


--
-- Name: SEQUENCE seq_serv_fee_type_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_serv_fee_type_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_serv_fee_type_id TO postgres;


--
-- Name: TABLE ct_serv_fee_type; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON TABLE public.ct_serv_fee_type TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ct_serv_fee_type TO comasw_app;


--
-- Name: SEQUENCE seq_service_type_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_service_type_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_service_type_id TO postgres;


--
-- Name: TABLE ct_service_type; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON TABLE public.ct_service_type TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ct_service_type TO comasw_app;


--
-- Name: SEQUENCE seq_account_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_account_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_account_id TO postgres;


--
-- Name: TABLE idt_account; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.idt_account TO comasw_app;
GRANT ALL ON TABLE public.idt_account TO postgres;


--
-- Name: SEQUENCE seq_customer_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_customer_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_customer_id TO postgres;


--
-- Name: TABLE idt_customer; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.idt_customer TO comasw_app;
GRANT ALL ON TABLE public.idt_customer TO postgres;


--
-- Name: SEQUENCE seq_fee_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_fee_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_fee_id TO postgres;


--
-- Name: TABLE idt_fee; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.idt_fee TO comasw_app;
GRANT ALL ON TABLE public.idt_fee TO postgres;


--
-- Name: SEQUENCE seq_fee_type_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_fee_type_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_fee_type_id TO postgres;


--
-- Name: TABLE idt_fee_type; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON TABLE public.idt_fee_type TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.idt_fee_type TO comasw_app;


--
-- Name: SEQUENCE seq_product_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_product_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_product_id TO postgres;


--
-- Name: TABLE idt_product; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.idt_product TO comasw_app;
GRANT ALL ON TABLE public.idt_product TO postgres;


--
-- Name: SEQUENCE seq_product_fee_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_product_fee_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_product_fee_id TO postgres;


--
-- Name: TABLE idt_product_fee; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.idt_product_fee TO comasw_app;
GRANT ALL ON TABLE public.idt_product_fee TO postgres;


--
-- Name: SEQUENCE seq_product_promotion_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_product_promotion_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_product_promotion_id TO postgres;


--
-- Name: TABLE idt_product_promotion; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.idt_product_promotion TO comasw_app;
GRANT ALL ON TABLE public.idt_product_promotion TO postgres;


--
-- Name: SEQUENCE seq_product_service_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_product_service_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_product_service_id TO postgres;


--
-- Name: TABLE idt_product_service; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.idt_product_service TO comasw_app;
GRANT ALL ON TABLE public.idt_product_service TO postgres;


--
-- Name: SEQUENCE seq_promotion_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_promotion_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_promotion_id TO postgres;


--
-- Name: TABLE idt_promotion; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.idt_promotion TO comasw_app;
GRANT ALL ON TABLE public.idt_promotion TO postgres;


--
-- Name: SEQUENCE seq_promotion_type_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_promotion_type_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_promotion_type_id TO postgres;


--
-- Name: TABLE idt_promotion_type; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.idt_promotion_type TO comasw_app;


--
-- Name: SEQUENCE seq_service_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_service_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_service_id TO postgres;


--
-- Name: TABLE idt_service; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.idt_service TO comasw_app;
GRANT ALL ON TABLE public.idt_service TO postgres;


--
-- Name: SEQUENCE seq_service_fee_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_service_fee_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_service_fee_id TO postgres;


--
-- Name: TABLE idt_service_fee; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.idt_service_fee TO comasw_app;
GRANT ALL ON TABLE public.idt_service_fee TO postgres;


--
-- Name: SEQUENCE seq_service_promotion_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_service_promotion_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_service_promotion_id TO postgres;


--
-- Name: TABLE idt_service_promotion; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.idt_service_promotion TO comasw_app;
GRANT ALL ON TABLE public.idt_service_promotion TO postgres;


--
-- Name: TABLE it_account; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.it_account TO comasw_app;
GRANT ALL ON TABLE public.it_account TO postgres;


--
-- Name: SEQUENCE seq_contract_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_contract_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_contract_id TO postgres;


--
-- Name: TABLE it_contract; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.it_contract TO comasw_app;
GRANT ALL ON TABLE public.it_contract TO postgres;


--
-- Name: TABLE it_customer; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.it_customer TO comasw_app;
GRANT ALL ON TABLE public.it_customer TO postgres;


--
-- Name: TABLE it_fee; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.it_fee TO comasw_app;
GRANT ALL ON TABLE public.it_fee TO postgres;


--
-- Name: TABLE it_product; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.it_product TO comasw_app;
GRANT ALL ON TABLE public.it_product TO postgres;


--
-- Name: SEQUENCE seq_profile_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_profile_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_profile_id TO postgres;


--
-- Name: TABLE it_profiles; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON TABLE public.it_profiles TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.it_profiles TO comasw_app;


--
-- Name: TABLE it_promotion; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.it_promotion TO comasw_app;
GRANT ALL ON TABLE public.it_promotion TO postgres;


--
-- Name: TABLE it_service; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.it_service TO comasw_app;
GRANT ALL ON TABLE public.it_service TO postgres;


--
-- Name: SEQUENCE seq_user_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_user_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_user_id TO postgres;


--
-- Name: TABLE it_users; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON TABLE public.it_users TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.it_users TO comasw_app;


--
-- Name: SEQUENCE seq_application_menu_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_application_menu_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_application_menu_id TO postgres;


--
-- Name: TABLE mt_application_menu; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON TABLE public.mt_application_menu TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.mt_application_menu TO comasw_app;


--
-- Name: SEQUENCE seq_application_level_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_application_level_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_application_level_id TO postgres;


--
-- Name: TABLE pt_application_level; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON TABLE public.pt_application_level TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.pt_application_level TO comasw_app;


--
-- Name: SEQUENCE seq_billing_period_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_billing_period_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_billing_period_id TO postgres;


--
-- Name: TABLE pt_billing_period; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON TABLE public.pt_billing_period TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.pt_billing_period TO comasw_app;


--
-- Name: SEQUENCE seq_consumption_class_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_consumption_class_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_consumption_class_id TO postgres;


--
-- Name: TABLE pt_consumption_class; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON TABLE public.pt_consumption_class TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.pt_consumption_class TO comasw_app;


--
-- Name: SEQUENCE seq_discount_type_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_discount_type_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_discount_type_id TO postgres;


--
-- Name: TABLE pt_discount_type; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON TABLE public.pt_discount_type TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.pt_discount_type TO comasw_app;


--
-- Name: SEQUENCE seq_entity_type_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_entity_type_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_entity_type_id TO postgres;


--
-- Name: TABLE pt_entity_type; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON TABLE public.pt_entity_type TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.pt_entity_type TO comasw_app;


--
-- Name: SEQUENCE seq_identity_card_type_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_identity_card_type_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_identity_card_type_id TO postgres;


--
-- Name: TABLE pt_identity_card_type; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.pt_identity_card_type TO comasw_app;
GRANT ALL ON TABLE public.pt_identity_card_type TO postgres;


--
-- Name: SEQUENCE seq_payment_method_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_payment_method_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_payment_method_id TO postgres;


--
-- Name: TABLE pt_payment_method; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON TABLE public.pt_payment_method TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.pt_payment_method TO comasw_app;


--
-- Name: SEQUENCE seq_status_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_status_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_status_id TO postgres;


--
-- Name: TABLE pt_status; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON TABLE public.pt_status TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.pt_status TO comasw_app;


--
-- Name: SEQUENCE seq_tax_type_id; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON SEQUENCE public.seq_tax_type_id TO comasw_app;
GRANT ALL ON SEQUENCE public.seq_tax_type_id TO postgres;


--
-- Name: TABLE pt_tax_type; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT ALL ON TABLE public.pt_tax_type TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.pt_tax_type TO comasw_app;


--
-- Name: TABLE vw_customer_instance; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.vw_customer_instance TO comasw_app;


--
-- Name: TABLE vw_account_instance; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.vw_account_instance TO comasw_app;


--
-- Name: TABLE vw_product_instance; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.vw_product_instance TO comasw_app;


--
-- Name: TABLE vw_service_instance; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.vw_service_instance TO comasw_app;


--
-- Name: TABLE vw_fee_instance; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.vw_fee_instance TO comasw_app;


--
-- Name: TABLE vw_product_fee_type; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.vw_product_fee_type TO comasw_app;


--
-- Name: TABLE vw_product_service_type; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.vw_product_service_type TO comasw_app;


--
-- Name: TABLE vw_promo_consum_type_discount; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.vw_promo_consum_type_discount TO comasw_app;


--
-- Name: TABLE vw_promotion_fee_type_discount; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.vw_promotion_fee_type_discount TO comasw_app;


--
-- Name: TABLE vw_promotion_instance; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.vw_promotion_instance TO comasw_app;


--
-- Name: TABLE vw_promotion_product_type; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.vw_promotion_product_type TO comasw_app;


--
-- Name: TABLE vw_promotion_service_type; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.vw_promotion_service_type TO comasw_app;


--
-- Name: TABLE vw_service_fee_type; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.vw_service_fee_type TO comasw_app;


--
-- Name: TABLE vw_users; Type: ACL; Schema: public; Owner: comasw_admin
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.vw_users TO comasw_app;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: comasw_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE comasw_admin IN SCHEMA public GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES  TO comasw_app;


--
-- PostgreSQL database dump complete
--

