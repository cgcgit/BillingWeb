-- crear usuarios

CREATE USER comasw_admin WITH PASSWORD 'comasw_admin';

ALTER ROLE comasw_admin WITH CREATEDB;

ALTER ROLE comasw_admin WITH CREATEROLE;

ALTER ROLE comasw_admin WITH SUPERUSER;

CREATE USER comasw_app WITH PASSWORD 'comasw_app';

-- crear bbdd:

CREATE DATABASE db_comasw OWNER comasw_admin;
